# LAST FOUR: Chapter 03

**Aftermath** transforms the existing aboveground city six months after evacuation. **Enter city** starts real-time exploration. Choose a surface district in the location directory or switch to the Bunker map layer for the original settlement. The explorer's cinematic previews are presentation artwork; gameplay uses actual geometry, collisions, and floor surfaces.

## Explore

- Choose a location to preview it, then enter at its floor-level deployment point.
- The **World map** has separate surface, bunker, and academy layers. Select a city arrival, one of ten underground sectors, or a particular school doorway.
- Enable the speaker control for environmental audio. Volume and atmospheric effects are adjustable in Settings.
- All sectors also connect on foot. Sector bulkheads open automatically on approach.
- The original ramp connects the plaza to the underground floor at `Y = -12 m`.
- The concourse stairs and passenger lift reach the gallery at `Y = -7.58 m`.

Desktop controls: WASD or arrow keys to move, drag to look, Q/R to turn, Shift to sprint, Space to jump, E to operate the hatch, lift, or nearby terminal, F for the headlamp, M for the map, H for the manual, and Escape for settings. The school reception terminal opens the academy directory; the generator console starts or stops a local test.

Touch controls: move with the left stick and drag the scene with a separate finger. Run, jump, headlamp, and contextual interaction controls are on screen. First-person inspection is the default; the existing third-person survivor is available in settings. No new characters or NPCs are included.

## Environment

The 208 by 208 metre underground footprint contains the central concourse, hospital, education wing, four-RV settlement, command centre, cafeteria, power generation, water treatment, maintenance workshops, and supply storage.

`src/facility.ts` is the spatial directory used by the renderer, interactive floor plan, and deployment system. `src/game/bunkerBuilder.ts` assembles the shared physical world. The architectural kit, furnishings, sector interiors, and service fittings are maintained in separate modules.

The interior uses scanned albedo, normal, and roughness textures, shared print atlases, instanced components, room-aware visibility, and distance-based detail culling. Balanced and High use PBR materials, prefiltered reflections, and cached directional shadows. Performance mode uses the same geometry with lighter shading, baked fixture illumination and contact shadows, and adaptive pixel density. Settings are stored locally.

The city generator, exterior hatch and ramp model, and original shared texture generator are unchanged. Their pre-upgrade SHA-256 checksums are recorded in `tests/protected.sha256`.

## Aftermath

`src/game/surface/` is an additive, surface-only layer. It reads the approved tower transforms without moving, resizing, deleting, or regenerating buildings. No new underground geometry, actors, NPCs, zombies, bodies, or creature sounds are generated.

- Four damage grades range from intact architecture to localized broken window clusters. Interior-view glazing and physical shards, mullions, and warped canopy parts supplement the retained exterior models.
- Ten staged vehicles of seven types supplement the original fifteen sedans and three buses. Custom profiled shells have wheel arches, tyres, rims, seats, dashboard, mirrors, weathered panels, and glazing. Open door leaves and cargo interiors appear only where the scene calls for them.
- Road fractures, distressed paint, abandoned transit stops, fallen signs, loose cabling, and checkpoint furniture follow existing streets. Grass, saplings, and hanging ivy use spatially instanced cutout geometry and wind deformation.
- A neutral overcast sky drives surface reflections. Moving haze and localized falling dust complement the original pooled wind debris, smoke, spark, and lamp effects. A maximum of three extra positional sound sources play near damaged signage, vegetation, and electrical infrastructure. Their independent bus is silenced before entering the bunker.
- The dressing is built on the first **surface** visit. Underground-only sessions do not build or load the new surface kit. Quality presets control detail distance, occlusion culling, particle budgets, and shading cost. The existing first-person/third-person selector and independent mobile thumb controls are unchanged.
- A 50 by 50 metre exclusion area keeps new colliders away from the original central hatch. The additions have no below-grade collision extents.

`tests/aftermath-preserved.sha256` records the pre-update hashes of the bunker and hatch modules, approved city generators, original lighting/audio modules, shared materials, and bunker imagery. All new surface maps are under `public/materials/aftermath/`.

## Previous Polish

**School.** `src/schoolPlan.ts` is the source for the academy's room boundaries, doorway positions, map, and arrival points. `src/game/academy.ts` builds the school within the existing education-sector boundary. A reception lobby leads to a continuous double-loaded teaching corridor. The 12 rooms are three classrooms, two laboratories, library, assembly hall, staff room, principal's office, administration, washrooms, and stores. Shared partitions and open doors leave navigable aisles. The school retains all existing external sector connections.

**City.** `src/game/cityPolish.ts` reads the original instance matrices rather than generating another city. It mounts facade finishes, fins, hotel balconies, crown equipment, storefronts, and canopies on those buildings. Crosswalks, drains, kerbs, bridge details, manholes, and parking markings follow the existing avenues. Localized contact shadows and photographed sky reflections complement the existing lighting. Nearby details use spatial instance batches; distant detail is culled.

**Atmosphere.** `src/game/atmosphere.ts` reuses particle buffers, leaf instances, and sprite pools. Dust budgets are 20, 48, and 78 for Performance, Balanced, and High. Localized smoke, steam, electrical sparks, subtle light shafts, fixture glows, and a shared vehicle headlight are conditioned on distance and sector. Schools and clinical spaces have no damage effects. Glows use local sprites rather than an expensive full-screen bloom chain.

**Sound.** `src/ambience.ts` synthesizes continuous wind, room tone, ventilation, and machine layers with slow modulation and smoothly changing profiles. A single Web Audio listener follows camera heading. Positioned emitters use distance attenuation. Transients include door motors and latches, lift travel and arrival, switches, terminals, generator tests, and footsteps chosen by surface material. Audio is opt-in, capped at 16 concurrent one-shots, and fades out when the document is hidden. No music, remote audio service, or audio downloads are required.

## Run

```sh
npm install
npm run dev
```

Production: `npm run build`. Serve the entire `dist/` directory, including local fonts, images, and material maps. The live scene requires WebGL 2. No service credentials or external runtime assets are needed.

## Verify

With the development server running, use:

```sh
npx playwright install --with-deps chromium
node tests/verify-facility.mjs
node tests/verify-touch.mjs
node tests/verify-polish.mjs
node tests/verify-aftermath.mjs
sha256sum -c tests/aftermath-preserved.sha256
sha256sum -c tests/protected.sha256
sha256sum -c tests/polish-preserved.sha256
npx tsc --noEmit
```

The checks exercise all ten spawn points, collision-aware sector connectivity, the nine clinical subrooms, all fifteen automatic portals, both directions of hatch traversal, stairs, lift travel and landing, preferences, map deployment, and renderer cleanup. The touch test sends simultaneous touch contacts, checks movement while turning, and verifies that releasing the joystick stops movement.

`tests/verify-polish.mjs` checks all 36 primary tower footprints against the original colliders, all 12 school entry points, spatial audio output, material footsteps, mechanical cues, particle budgets, school cleanliness, and terminal interaction. The navigation test also checks access on both sides of every school doorway from the concourse.

Results are written to `artifacts/navigation-report.json`, `artifacts/environment-polish-report.json`, and `artifacts/touch-report.json`. Touch emulation verifies input behaviour, not frame rate on physical phones. Actual performance depends on hardware, browser, resolution, and quality preset. An audio signal check is not a subjective listening evaluation.

Material and typeface licenses are included under `public/materials/` and `public/fonts/`.
