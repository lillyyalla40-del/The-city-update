import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, Box, RotateCcw } from 'lucide-react';
import { Explorer } from './components/Explorer';
import { GameHUD } from './components/GameHUD';
import { Dialog, FieldManual, Settings } from './components/Overlays';
import { WorldMap, type MapTab } from './components/WorldMap';
import { Identity } from './components/Identity';
import { SECTORS, readPreferences, sectorImage, type Preferences } from './facility';
import type { MegaCityGameEngine } from './game/engine';
import type { FastTravelPoint, HudTelemetry } from './game/types';
import { setAmbience, worldAudio } from './ambience';
import { DESTINATIONS, type Destination } from './world';

export function App() {
  const [selected, setSelected] = useState(0),
    [modal, setModal] = useState<'map' | 'manual' | 'settings' | null>(null);
  const [prefs, setPrefs] = useState<Preferences>(readPreferences),
    prefsRef = useRef(prefs);
  const [session, setSession] = useState<FastTravelPoint | null>(null),
    [ready, setReady] = useState(false),
    [error, setError] = useState('');
  const [telemetry, setTelemetry] = useState<HudTelemetry | null>(null);
  const [mapTab, setMapTab] = useState<MapTab>('surface');
  const host = useRef<HTMLDivElement>(null),
    engine = useRef<MegaCityGameEngine | null>(null);
  const close = useCallback(() => setModal(null), []);
  const openMap = (tab: MapTab) => {
    setMapTab(tab);
    setModal('map');
  };
  const mapForLocation = (): MapTab =>
    telemetry
      ? telemetry.currentZone.id === 'education'
        ? 'school'
        : telemetry.isUnderground
          ? 'bunker'
          : 'surface'
      : DESTINATIONS[selected].id === 'education'
        ? 'school'
        : DESTINATIONS[selected].sectorIndex >= 0
          ? 'bunker'
          : 'surface';
  const leave = useCallback(() => {
    setSession(null);
    setReady(false);
    setError('');
    setTelemetry(null);
    setModal(null);
  }, []);
  const update = useCallback((patch: Partial<Preferences>) => {
    setPrefs((old) => ({ ...old, ...patch }));
    if (patch.sound !== undefined) setAmbience(patch.sound);
  }, []);
  useEffect(() => {
    prefsRef.current = prefs;
    try {
      localStorage.setItem('lf3-preferences', JSON.stringify(prefs));
    } catch {
      /* Storage is optional in private browsing. */
    }
  }, [prefs]);
  useEffect(() => {
    engine.current?.applyQualityPreset(prefs.quality);
  }, [prefs.quality]);
  useEffect(() => {
    engine.current?.setPerspective(prefs.firstPerson);
  }, [prefs.firstPerson]);
  useEffect(() => {
    engine.current?.setEffects(prefs.effects);
  }, [prefs.effects]);
  useEffect(() => {
    worldAudio.setVolume(prefs.volume);
  }, [prefs.volume]);
  useEffect(() => {
    if (!session)
      worldAudio.setZone(DESTINATIONS[selected].sectorIndex < 0 ? 'surface' : DESTINATIONS[selected].id);
  }, [selected, session]);
  useEffect(() => {
    engine.current?.setPaused(!!modal || !ready || !!error);
  }, [modal, ready, error]);
  useEffect(() => {
    const resume = () => {
      if (prefsRef.current.sound) setAmbience(true);
    };
    window.addEventListener('pointerdown', resume, { once: true });
    return () => window.removeEventListener('pointerdown', resume);
  }, []);
  useEffect(() => {
    const change = () => setAmbience(!document.hidden && prefsRef.current.sound);
    document.addEventListener('visibilitychange', change);
    return () => document.removeEventListener('visibilitychange', change);
  }, []);
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (modal || error || (session && !ready) || e.repeat || e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.code === 'KeyM') {
        e.preventDefault();
        openMap(mapForLocation());
      }
      if (e.code === 'KeyH') setModal('manual');
      if (e.code === 'Escape' && session) setModal('settings');
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [modal, session, ready, error, selected, telemetry?.currentZone.id]);
  useEffect(() => {
    if (!session || !host.current) return;
    let cancelled = false;
    const el = host.current;
    let instance: MegaCityGameEngine | null = null;
    const onContextLost = (event: Event) => {
      event.preventDefault();
      if (cancelled) return;
      instance?.setPaused(true);
      setReady(false);
      setError(
        'Your device released the graphics context. Retry to reload this sector in Performance mode, or return to the explorer.',
      );
    };
    el.addEventListener('webglcontextlost', onContextLost, true);
    const init = window.setTimeout(async () => {
      try {
        const { MegaCityGameEngine: Engine } = await import('./game/engine');
        if (cancelled) return;
        instance = new Engine(
          el,
          setTelemetry,
          prefsRef.current.quality,
          session,
          prefsRef.current.firstPerson,
          prefsRef.current.effects,
          (tab) => {
            setMapTab(tab);
            setModal('map');
          },
        );
        engine.current = instance;
        if (!cancelled) setReady(true);
      } catch (err) {
        if (!cancelled) {
          console.error('Facility renderer initialization failed:', err);
          setError(
            'This browser could not start the 3D renderer. Enable hardware acceleration or try a WebGL 2 compatible browser. The sector previews and facility map are still available.',
          );
        }
      }
    }, 80);
    return () => {
      cancelled = true;
      clearTimeout(init);
      el.removeEventListener('webglcontextlost', onContextLost, true);
      instance?.dispose();
      el.replaceChildren();
      engine.current = null;
    };
  }, [session]);
  const deploy = (point: FastTravelPoint) => {
    setModal(null);
    setError('');
    if (engine.current) {
      engine.current.fastTravel(point);
      engine.current.setPaused(false);
    } else {
      setReady(false);
      setSession({ ...point });
    }
    if (prefs.sound) setAmbience(true);
  };
  const current = SECTORS.findIndex((s) => s.id === telemetry?.currentZone.id);
  return (
    <>
      {!session ? (
        <Explorer
          selected={selected}
          onSelect={setSelected}
          onEnter={(d: Destination) => deploy(d.point)}
          onMap={() => openMap(mapForLocation())}
          onManual={() => setModal('manual')}
          onSettings={() => setModal('settings')}
          sound={prefs.sound}
          onSound={() => update({ sound: !prefs.sound })}
        />
      ) : (
        <div className="play-session">
          <div className="renderer-host" ref={host} />
          {!ready && !error && (
            <div
              className="loading-scene"
              style={{
                backgroundImage: `linear-gradient(0deg,#090c0be6,#090c0b70),url(${session.group === 'Surface City' ? DESTINATIONS.find((d) => d.id === session.id)?.image || DESTINATIONS[0].image : sectorImage(SECTORS.find((s) => s.id === session.id) || SECTORS[0])})`,
              }}
            >
              <Identity />
              <div className="loading-track">
                <i />
              </div>
              <span className="micro">INITIALIZING 3D ENVIRONMENT</span>
              <p>{session.label}</p>
            </div>
          )}
          {ready && engine.current && (
            <GameHUD
              engine={engine.current}
              telemetry={telemetry}
              sensitivity={prefs.sensitivity}
              blocked={!!modal}
              onExit={leave}
              onMap={() => openMap(mapForLocation())}
              onSettings={() => setModal('settings')}
              onManual={() => setModal('manual')}
            />
          )}
        </div>
      )}
      {error && (
        <Dialog title="Renderer unavailable" eyebrow="EXPLORER DIAGNOSTICS" icon={<Box />} close={leave}>
          <div className="dialog-body">
            <p className="dialog-intro">{error}</p>
            <div className="error-actions">
              <button className="outline-button" onClick={leave}>
                <ArrowLeft size={15} />
                Return to explorer
              </button>
              <button
                className="primary-button"
                onClick={() => {
                  update({ quality: 'mobile' });
                  setError('');
                  setReady(false);
                  setSession((s) => (s ? { ...s } : null));
                }}
              >
                <RotateCcw size={14} />
                Retry
              </button>
            </div>
          </div>
        </Dialog>
      )}
      {modal === 'map' && (
        <WorldMap
          initialTab={mapTab}
          initialDestination={session?.id || DESTINATIONS[selected].id}
          initialSector={current >= 0 ? current : Math.max(0, DESTINATIONS[selected].sectorIndex)}
          close={close}
          deploy={(p) => {
            const i = DESTINATIONS.findIndex((d) => d.id === p.id);
            if (i >= 0) setSelected(i);
            deploy(p);
          }}
        />
      )}
      {modal === 'manual' && <FieldManual close={close} />}
      {modal === 'settings' && <Settings prefs={prefs} update={update} close={close} />}
    </>
  );
}
export default App;
