export function Identity() {
  return (
    <span className="identity">
      <svg
        className="identity-symbol"
        width="42"
        height="44"
        viewBox="0 0 42 44"
        fill="currentColor"
        aria-hidden="true"
      >
        <path d="M9 4h8L9 33h11l-2 7H0L9 4Zm12 0h21l-2 7H27l-2 8h11l-2 7H23l-4 14h-8l10-36Z" />
      </svg>
      <span className="identity-type">
        <strong>LAST FOUR</strong>
        <small>CHAPTER 03</small>
      </span>
    </span>
  );
}
