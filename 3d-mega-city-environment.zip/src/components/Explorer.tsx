import { useEffect, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  AudioLines,
  BookOpen,
  Check,
  ChevronLeft,
  ChevronRight,
  Compass,
  Radio,
  Globe2,
  Layers3,
  Map,
  Play,
  Settings2,
  VolumeX,
} from 'lucide-react';
import { Identity } from './Identity';
import { DESTINATIONS, type Destination } from '../world';
import './explorer.css';

interface Props {
  selected: number;
  onSelect: (n: number) => void;
  onEnter: (d: Destination) => void;
  onMap: () => void;
  onManual: () => void;
  onSettings: () => void;
  sound: boolean;
  onSound: () => void;
}
export function Explorer({
  selected,
  onSelect,
  onEnter,
  onMap,
  onManual,
  onSettings,
  sound,
  onSound,
}: Props) {
  const d = DESTINATIONS[selected],
    rail = useRef<HTMLDivElement>(null);
  const [start, setStart] = useState(0),
    [atEnd, setAtEnd] = useState(false);
  const measure = () => {
    const r = rail.current;
    if (!r || !r.firstElementChild) return;
    const width = r.firstElementChild.getBoundingClientRect().width + parseFloat(getComputedStyle(r).gap);
    setStart(Math.round(r.scrollLeft / width));
    setAtEnd(r.scrollLeft + r.clientWidth >= r.scrollWidth - 3);
  };
  useEffect(() => {
    const o = new ResizeObserver(measure);
    if (rail.current) o.observe(rail.current);
    return () => o.disconnect();
  }, []);
  const choose = (n: number) => {
    onSelect(n);
    if (window.innerWidth < 700) window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const home = () => {
    choose(0);
    rail.current?.scrollTo({ left: 0, behavior: 'smooth' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const scroll = (dir: number) => {
    const r = rail.current;
    if (!r?.firstElementChild) return;
    r.scrollBy({
      left:
        (r.firstElementChild.getBoundingClientRect().width + parseFloat(getComputedStyle(r).gap)) *
        dir *
        (window.innerWidth < 650 ? 1 : 4),
      behavior: 'smooth',
    });
  };
  return (
    <main className="explorer-shell expedition aftermath-explorer">
      <header className="masthead">
        <button className="brand-button" aria-label="Last Four explorer home" onClick={home}>
          <Identity />
        </button>
        <nav className="primary-nav" aria-label="Main navigation">
          <button className="active" onClick={home}>
            <Compass size={15} />
            World explorer
          </button>
          <button onClick={onMap}>
            <Map size={15} />
            World map
          </button>
          <button onClick={onManual}>
            <BookOpen size={15} />
            Field manual
          </button>
        </nav>
        <div className="head-tools">
          <span className="system-status">
            <Radio size={13} />
            Link online
          </span>
          <span className="tool-divider" />
          <button
            className={`icon-button ${sound ? 'audio-enabled' : ''}`}
            aria-label={sound ? 'Mute world ambience' : 'Enable world ambience'}
            aria-pressed={sound}
            title={sound ? 'Mute ambience' : 'Enable ambience'}
            onClick={onSound}
          >
            {sound ? <AudioLines size={17} /> : <VolumeX size={17} />}
          </button>
          <button
            className="icon-button"
            aria-label="Explorer settings"
            title="Explorer settings"
            onClick={onSettings}
          >
            <Settings2 size={17} />
          </button>
        </div>
      </header>
      <section className="hero atlas-hero" aria-label={`${d.name} environment preview`}>
        <div className="hero-image" key={d.id}>
          <img src={d.image} alt={`${d.name} architectural preview`} fetchPriority="high" />
        </div>
        <div className="hero-shade" />
        <div className="hero-content" key={'title-' + d.id}>
          <div className="eyebrow hero-eyebrow">
            <span className="orange-rule" />
            LAST FOUR <span className="eyebrow-slash">/</span>{' '}
            {d.sectorIndex < 0 ? 'AFTERMATH' : 'CHAPTER 03'}
          </div>
          <h1>
            {d.title[0] && (
              <>
                {d.title[0]}
                <br />
              </>
            )}
            {d.title[1]}
            <span className="title-period">.</span>
          </h1>
          <p>{d.description}</p>
          <div className="hero-actions">
            <button className="primary-button" onClick={() => onEnter(d)}>
              <Play size={13} fill="currentColor" />
              {d.id === 'education'
                ? 'Enter academy'
                : d.id === 'concourse'
                  ? 'Enter bunker'
                  : d.sectorIndex < 0
                    ? 'Enter city'
                    : 'Enter sector'}
              <ArrowRight size={16} />
            </button>
            <button className="outline-button" onClick={onMap}>
              <Map size={16} />
              View world map
            </button>
          </div>
        </div>
      </section>
      <section className="directory world-directory" aria-labelledby="directory-title">
        <div className="directory-head">
          <div className="section-title">
            <Layers3 size={22} />
            <h2 id="directory-title">Location directory</h2>
            <span className="directory-count">{String(DESTINATIONS.length).padStart(2, '0')}</span>
          </div>
          <div className="rail-tools">
            <span className="micro rail-counter">
              {String(start + 1).padStart(2, '0')}
              <b>/</b>
              {DESTINATIONS.length}
            </span>
            <button
              className="square-button"
              disabled={start === 0}
              onClick={() => scroll(-1)}
              aria-label="Previous locations"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              className="square-button"
              disabled={atEnd}
              onClick={() => scroll(1)}
              aria-label="Next locations"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
        <div className="sector-rail destination-rail" ref={rail} onScroll={measure}>
          {DESTINATIONS.map((v, i) => (
            <button
              key={v.id}
              className={'destination' + (selected === i ? ' selected' : '')}
              aria-label={`Preview ${v.name}`}
              aria-pressed={selected === i}
              onClick={() => choose(i)}
            >
              <span className="destination-image">
                <img
                  src={v.sectorIndex < 0 ? v.image.replace('.jpg', '-thumb.webp') : v.image}
                  alt=""
                  draggable="false"
                  loading={i < 4 ? 'eager' : 'lazy'}
                />
                <span className="destination-index">{String(i + 1).padStart(2, '0')}</span>
                {selected === i && (
                  <span className="selection-check">
                    <Check size={12} strokeWidth={3} />
                  </span>
                )}
              </span>
              <span className="destination-caption">
                <span>
                  <small>
                    {v.code} <i /> {v.sectorIndex < 0 ? 'SURFACE' : 'SUBLEVEL 01'}
                  </small>
                  <strong>{v.name}</strong>
                </span>
                <ArrowUpRight size={18} />
              </span>
            </button>
          ))}
        </div>
      </section>
      <footer className="shell-footer">
        <span>
          <Globe2 size={12} /> LAST FOUR <b>/</b> WORLD EXPLORER
        </span>
        <span className="footer-line" />
        <span>
          <ArrowDown size={10} /> ENVIRONMENT BUILD 03.12
        </span>
      </footer>
    </main>
  );
}
