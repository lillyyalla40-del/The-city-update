import { useEffect, useRef, useState, type ReactNode } from 'react';
import {
  BookOpen,
  Check,
  ChevronDown,
  Keyboard,
  MousePointer2,
  Settings2,
  SlidersHorizontal,
  Smartphone,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import type { Preferences } from '../facility';

export function Dialog({
  title,
  eyebrow,
  icon,
  close,
  children,
  wide = false,
}: {
  title: string;
  eyebrow: string;
  icon: ReactNode;
  close: () => void;
  children: ReactNode;
  wide?: boolean;
}) {
  const panel = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    const scroll = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    panel.current?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        close();
      }
      if (e.key === 'Tab') {
        const els = panel.current?.querySelectorAll<HTMLElement>(
          'button:not([disabled]),input,select,[tabindex="0"]',
        );
        if (!els?.length) return;
        if (e.shiftKey && (document.activeElement === els[0] || document.activeElement === panel.current)) {
          e.preventDefault();
          els[els.length - 1].focus();
        } else if (!e.shiftKey && document.activeElement === els[els.length - 1]) {
          e.preventDefault();
          els[0].focus();
        }
      }
    };
    window.addEventListener('keydown', key, true);
    return () => {
      window.removeEventListener('keydown', key, true);
      document.body.style.overflow = scroll;
      prev?.focus();
    };
  }, [close]);
  return (
    <div
      className="dialog-backdrop"
      onMouseDown={(e) => {
        if (e.currentTarget === e.target) close();
      }}
    >
      <div
        tabIndex={-1}
        ref={panel}
        className={`dialog ${wide ? 'wide' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <div className="dialog-title">
          <div className="dialog-heading-icon">{icon}</div>
          <div>
            <span className="micro orange">{eyebrow}</span>
            <h2>{title}</h2>
          </div>
          <button onClick={close} className="square-button close-dialog" aria-label="Close dialog">
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function FieldManual({ close }: { close: () => void }) {
  const [mode, setMode] = useState<'desktop' | 'touch'>(navigator.maxTouchPoints ? 'touch' : 'desktop');
  return (
    <Dialog title="Field manual" eyebrow="EXPLORER REFERENCE / 03" icon={<BookOpen />} close={close}>
      <div className="dialog-body">
        <p className="dialog-intro">
          Explore Meridian City and its ten underground sectors on foot. The central hatch connects both
          levels. Use the academy directory to find individual classrooms and facilities.
        </p>
        <div className="segmented">
          <button className={mode === 'desktop' ? 'chosen' : ''} onClick={() => setMode('desktop')}>
            <Keyboard size={15} />
            Desktop
          </button>
          <button className={mode === 'touch' ? 'chosen' : ''} onClick={() => setMode('touch')}>
            <Smartphone size={15} />
            Touch controls
          </button>
        </div>
        <div className="key-list">
          {(mode === 'desktop'
            ? [
                ['Move', 'W A S D'],
                ['Look around', 'Drag'],
                ['Turn left / right', 'Q / R'],
                ['Sprint', 'Shift'],
                ['Jump', 'Space'],
                ['Use hatch, lift, or terminal', 'E'],
                ['Toggle headlamp', 'F'],
                ['World map', 'M'],
                ['Pause / settings', 'Esc'],
              ]
            : [
                ['Move in any direction', 'Left joystick'],
                ['Look around', 'Drag the scene'],
                ['Move and turn', 'Use both thumbs'],
                ['Toggle sprint', 'Run button'],
                ['Jump', 'Jump button'],
                ['Use hatch or lift', 'Interaction prompt'],
                ['Travel to a sector', 'Map button'],
              ]
          ).map(([action, key]) => (
            <div key={action}>
              <span>{action}</span>
              <kbd>{key}</kbd>
            </div>
          ))}
        </div>
        <div className="info-note">
          <MousePointer2 size={17} />
          <p>
            Use the map to deploy directly into a sector. Camera and rendering preferences are saved on this
            device.
          </p>
        </div>
      </div>
    </Dialog>
  );
}

export function Settings({
  prefs,
  update,
  close,
}: {
  prefs: Preferences;
  update: (p: Partial<Preferences>) => void;
  close: () => void;
}) {
  return (
    <Dialog title="Explorer settings" eyebrow="LOCAL CONFIGURATION" icon={<Settings2 />} close={close}>
      <div className="dialog-body">
        <div className="setting-label">
          <SlidersHorizontal size={16} />
          <h3>Render quality</h3>
        </div>
        <p className="setting-help">Balance surface detail and resolution for your device.</p>
        <div className="segmented">
          {(['mobile', 'balanced', 'high'] as const).map((q) => (
            <button
              key={q}
              className={q === prefs.quality ? 'chosen' : ''}
              onClick={() => update({ quality: q })}
            >
              {q === prefs.quality && <Check size={13} />}
              {{ mobile: 'Performance', balanced: 'Balanced', high: 'High' }[q]}
            </button>
          ))}
        </div>
        <div className="setting-row">
          <div>
            <h3>Look sensitivity</h3>
            <p>Camera rotation speed</p>
          </div>
          <span className="micro">{prefs.sensitivity.toFixed(1)}x</span>
        </div>
        <input
          aria-label="Look sensitivity"
          className="range"
          type="range"
          min="0.4"
          max="2"
          step="0.1"
          value={prefs.sensitivity}
          onChange={(e) => update({ sensitivity: Number(e.target.value) })}
        />
        <div className="setting-row">
          <div>
            <h3>Camera perspective</h3>
            <p>Explore at eye level or follow the survivor.</p>
          </div>
          <div className="select-wrap">
            <select
              aria-label="Camera perspective"
              value={prefs.firstPerson ? 'first' : 'third'}
              onChange={(e) => update({ firstPerson: e.target.value === 'first' })}
            >
              <option value="first">First person</option>
              <option value="third">Third person</option>
            </select>
            <ChevronDown size={13} />
          </div>
        </div>
        <div className="setting-row">
          <div>
            <h3>World audio</h3>
            <p>Spatial ambience, footsteps, and interaction sounds</p>
          </div>
          <button
            role="switch"
            aria-label="World audio"
            aria-checked={prefs.sound}
            className={`sound-switch ${prefs.sound ? 'on' : ''}`}
            onClick={() => update({ sound: !prefs.sound })}
          >
            {prefs.sound ? <Volume2 size={15} /> : <VolumeX size={15} />} {prefs.sound ? 'On' : 'Off'}
          </button>
        </div>
        {prefs.sound && (
          <>
            <div className="setting-row">
              <div>
                <h3>Audio level</h3>
                <p>Master environment volume</p>
              </div>
              <span className="micro">{Math.round(prefs.volume * 100)}%</span>
            </div>
            <input
              aria-label="Audio level"
              className="range"
              type="range"
              min="0"
              max="100"
              step="1"
              value={Math.round(prefs.volume * 100)}
              onChange={(e) => update({ volume: Number(e.target.value) / 100 })}
            />
          </>
        )}
        <div className="setting-row">
          <div>
            <h3>Atmospheric effects</h3>
            <p>Dust, light shafts, steam, and local glows</p>
          </div>
          <button
            className={`sound-switch ${prefs.effects ? 'on' : ''}`}
            role="switch"
            aria-label="Atmospheric effects"
            aria-checked={prefs.effects}
            onClick={() => update({ effects: !prefs.effects })}
          >
            {prefs.effects ? 'On' : 'Off'}
          </button>
        </div>
        <p className="save-note">
          <Check size={13} />
          Preferences are saved automatically.
        </p>
      </div>
    </Dialog>
  );
}
