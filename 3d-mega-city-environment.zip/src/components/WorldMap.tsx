import { useState } from 'react';
import { ArrowRight, BookOpen, Building2, Layers3, Map, Navigation } from 'lucide-react';
import { Dialog } from './Overlays';
import { SECTORS, sectorImage, sectorPoint } from '../facility';
import { DESTINATIONS, destinationById } from '../world';
import { SCHOOL_ROOMS } from '../schoolPlan';
import type { FastTravelPoint } from '../game/types';
export type MapTab = 'surface' | 'bunker' | 'school';
const arrivals: { name: string; point: FastTravelPoint; bounds: number[] }[] = [
  { name: 'Meridian City', point: DESTINATIONS[0].point, bounds: [-55, -55, 110, 110] },
  { name: 'Financial District', point: destinationById('financial').point, bounds: [-174, -174, 112, 112] },
  {
    name: 'Northgate Commons',
    point: {
      id: 'park',
      label: 'Northgate Civic Park',
      group: 'Surface City',
      x: 98,
      y: 0.15,
      z: -87,
      yaw: 0,
    },
    bounds: [62, -174, 112, 112],
  },
  {
    name: 'Metro Galleria',
    point: { id: 'mall', label: 'Metro Galleria', group: 'Surface City', x: -84, y: 0.15, z: 72, yaw: 2.6 },
    bounds: [-174, 62, 112, 112],
  },
  {
    name: 'Meridian Hotel',
    point: {
      id: 'hotel',
      label: 'Grand Meridian Hotel',
      group: 'Surface City',
      x: 68,
      y: 0,
      z: 74,
      yaw: -2.2,
    },
    bounds: [62, 62, 112, 112],
  },
  {
    name: 'Central hatch',
    point: {
      id: 'plaza',
      label: 'Central Meridian Plaza',
      group: 'Surface City',
      x: 0,
      y: 0.15,
      z: -24,
      yaw: Math.PI,
    },
    bounds: [-11, -11, 22, 22],
  },
];
interface Props {
  initialTab: MapTab;
  initialSector: number;
  initialDestination?: string;
  close: () => void;
  deploy: (p: FastTravelPoint) => void;
}
export function WorldMap({ initialTab, initialSector, initialDestination, close, deploy }: Props) {
  const [tab, setTab] = useState<MapTab>(initialTab),
    [sector, setSector] = useState(initialSector),
    [surface, setSurface] = useState(
      Math.max(
        0,
        arrivals.findIndex((a) => a.point.id === initialDestination),
      ),
    ),
    [room, setRoom] = useState(-1);
  const s = SECTORS[sector],
    area = arrivals[surface],
    r = SCHOOL_ROOMS[room];
  const title = tab === 'bunker' ? s.name : tab === 'surface' ? area.name : r?.name || 'Meridian Academy';
  const img =
    tab === 'bunker'
      ? sectorImage(s)
      : tab === 'school'
        ? destinationById('education').image
        : destinationById(area.point.id).image;
  const enter = () => {
    if (tab === 'bunker') deploy(sectorPoint(s));
    else if (tab === 'surface') deploy(area.point);
    else if (!r) deploy(sectorPoint(SECTORS[2]));
    else {
      const door = r.x1 + Math.min(3.2, (r.x2 - r.x1) * 0.21),
        front = r.entry === 'south' ? r.z2 : r.z1;
      deploy({
        id: 'education',
        label: r.name,
        group: 'Underground Bunker',
        x: door,
        y: -12,
        z: front + (r.entry === 'south' ? 1.7 : -1.7),
        yaw: r.entry === 'south' ? 0 : Math.PI,
      });
    }
  };
  const handleKey = (e: React.KeyboardEvent, fn: () => void) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      fn();
    }
  };
  const regions =
    tab === 'surface'
      ? arrivals.map((v) => ({ box: v.bounds, name: v.name, number: '', color: '#a7b3a0' }))
      : tab === 'bunker'
        ? SECTORS.map((v) => ({
            box: [v.bounds[0], v.bounds[2], v.bounds[1] - v.bounds[0], v.bounds[3] - v.bounds[2]],
            name: v.name,
            number: v.number,
            color: v.color,
          }))
        : SCHOOL_ROOMS.map((v) => ({
            box: [v.x1, v.z1, v.x2 - v.x1, v.z2 - v.z1],
            name: v.name,
            number: v.code,
            color: '#a2b89e',
          }));
  const selected = tab === 'surface' ? surface : tab === 'bunker' ? sector : room;
  const select = tab === 'surface' ? setSurface : tab === 'bunker' ? setSector : setRoom;
  return (
    <Dialog title="World map" eyebrow="SPATIAL DIRECTORY / LF-03" close={close} icon={<Map />} wide>
      <div className="world-map-tabs" role="tablist" aria-label="Map layer">
        {(['surface', 'bunker', 'school'] as const).map((v, i) => (
          <button key={v} role="tab" aria-selected={v === tab} onClick={() => setTab(v)}>
            {i === 0 ? <Building2 size={14} /> : i === 1 ? <Layers3 size={14} /> : <BookOpen size={14} />}{' '}
            {['Surface city', 'Underground bunker', 'Academy'][i]}
          </button>
        ))}
      </div>
      <div className="map-layout">
        <div className="map-canvas">
          <span className="micro map-top">
            {tab === 'surface' ? 'GROUND LEVEL' : tab === 'school' ? 'ACADEMY / B-03' : 'SUBLEVEL 01'}{' '}
            <b>/</b> PLAN VIEW
          </span>
          <span className="map-north">
            <Navigation size={12} />N
          </span>
          <svg
            viewBox={
              tab === 'surface'
                ? '-192 -199 384 398'
                : tab === 'school'
                  ? '-111 -119 145 113'
                  : '-120 -123 240 246'
            }
            role="group"
            aria-label={`${tab} interactive plan`}
          >
            <defs>
              <pattern id="atlas-grid" width="6" height="6" patternUnits="userSpaceOnUse">
                <path d="M6 0H0V6" fill="none" stroke="#76857135" strokeWidth=".16" />
              </pattern>
            </defs>
            <rect x="-220" y="-220" width="440" height="440" fill="url(#atlas-grid)" />
            {tab === 'surface' && (
              <>
                {[-128, -68, 0, 68, 128].map((a) => (
                  <g key={a} stroke="#a1ab9947" strokeWidth="5">
                    <path d={`M${a} -177v354`} />
                    <path d={`M-177 ${a}h354`} />
                  </g>
                ))}
                {[-153, -98, -38, 38, 98, 153].flatMap((x, i) =>
                  [-153, -98, -38, 38, 98, 153].map((z, j) => (
                    <g key={`${i}${j}`} fill="#6e7a6644">
                      <rect x={x - 12} y={z - 13} width="12" height="22" />
                      <rect x={x + 3} y={z - 5} width="11" height="17" />
                    </g>
                  )),
                )}
              </>
            )}
            {tab === 'school' && (
              <>
                <rect
                  x="-104"
                  y="-104"
                  width="128"
                  height="80"
                  fill="#d0cfad0e"
                  stroke="#8b9f87"
                  strokeWidth=".4"
                />
                <path
                  d="M16 -25v-30H-100"
                  stroke="#c8b784"
                  strokeWidth="2"
                  fill="none"
                  strokeDasharray="1.4 1.1"
                />
                <text x="-52" y="-52.1" fill="#a5b39b" fontSize="1.9" textAnchor="middle" letterSpacing=".8">
                  ACADEMIC WALK
                </text>
                <circle cx="15.1" cy="-29.8" r="1.3" fill="#eead6b" />
                <text x="16" y="-19.5" textAnchor="middle" fontSize="2.2" fill="#cad6c0">
                  RECEPTION
                </text>
              </>
            )}
            {regions.map((v, i) => {
              const [x, z, w, h] = v.box;
              const on = i === selected;
              return (
                <g
                  key={v.name}
                  className="map-region"
                  role="button"
                  tabIndex={0}
                  aria-label={`Select ${v.name}`}
                  onClick={() => select(i)}
                  onKeyDown={(e) => handleKey(e, () => select(i))}
                >
                  <rect
                    x={x + 0.45}
                    y={z + 0.45}
                    width={w - 0.9}
                    height={h - 0.9}
                    fill={on ? '#e9a4673e' : v.color + '21'}
                    stroke={on ? '#edaf79' : v.color}
                    strokeWidth={on ? (tab === 'school' ? 0.7 : 1.5) : tab === 'school' ? 0.34 : 0.6}
                  />
                  <text
                    x={x + w / 2}
                    y={z + h / 2 + (tab === 'surface' && i === 0 ? 31 : 0)}
                    textAnchor="middle"
                    fill={on ? '#f2c79c' : '#d0d7c9'}
                    fontSize={tab === 'school' ? 3.9 : tab === 'surface' && i === 5 ? 5 : 9}
                    fontFamily="Barlow Condensed"
                  >
                    {v.number || v.name.toUpperCase()}
                  </text>
                  {tab === 'bunker' && (
                    <text x={x + w / 2} y={z + h / 2 + 7} textAnchor="middle" fill="#b8c5b2" fontSize="3.7">
                      {v.name.split(' ')[0].toUpperCase()}
                    </text>
                  )}
                </g>
              );
            })}
          </svg>
        </div>
        <div className="map-info">
          <img src={img} alt={`${title} environment preview`} />
          <div className="map-info-body">
            <span className="micro orange">
              {tab === 'bunker'
                ? `SECTOR ${s.number} / 10`
                : tab === 'school'
                  ? r
                    ? `ROOM ${r.code} / B-03`
                    : 'SCHOOL ENTRANCE'
                  : 'SURFACE / MERIDIAN'}
            </span>
            <h3>{title}</h3>
            <p>
              {tab === 'bunker'
                ? s.description
                : tab === 'surface'
                  ? `Deploy at ${area.name} and explore the city on foot. The central plaza connects to the underground settlement.`
                  : r
                    ? `Arrive at the ${r.name.toLowerCase()} doorway. Follow the academic walk to return to reception.`
                    : SECTORS[2].description}
            </p>
            {tab === 'school' ? (
              <label className="room-select">
                ROOM DIRECTORY
                <select
                  aria-label="Choose school room"
                  value={room}
                  onChange={(e) => setRoom(Number(e.target.value))}
                >
                  <option value="-1">Main reception</option>
                  {SCHOOL_ROOMS.map((v, i) => (
                    <option value={i} key={v.code}>
                      {v.code} / {v.name}
                    </option>
                  ))}
                </select>
              </label>
            ) : tab === 'surface' ? (
              <label className="room-select">
                ARRIVAL POINT
                <select
                  aria-label="Choose city arrival"
                  value={surface}
                  onChange={(e) => setSurface(Number(e.target.value))}
                >
                  {arrivals.map((v, i) => (
                    <option value={i} key={v.name}>
                      {v.name}
                    </option>
                  ))}
                </select>
              </label>
            ) : (
              <div className="map-rooms">
                {s.rooms.slice(0, 6).map((v) => (
                  <span key={v}>{v}</span>
                ))}
              </div>
            )}
            <button className="primary-button" onClick={enter}>
              {tab === 'bunker' ? 'Explore sector' : tab === 'school' ? 'Enter academy' : 'Enter city'}
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </div>
      <div className="dialog-foot">
        <span>
          <Layers3 size={13} />
          One connected world
        </span>
        <span>MERIDIAN / CHAPTER 03</span>
      </div>
    </Dialog>
  );
}
