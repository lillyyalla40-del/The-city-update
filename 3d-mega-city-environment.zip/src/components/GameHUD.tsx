import { useEffect, useRef, useState, type PointerEvent as PEvent } from 'react';
import {
  ArrowLeft,
  ArrowUp,
  BookOpen,
  ChevronUp,
  Compass,
  Flashlight,
  Footprints,
  Hand,
  Map,
  Maximize2,
  MousePointer2,
  Settings2,
} from 'lucide-react';
import type { MegaCityGameEngine } from '../game/engine';
import type { HudTelemetry } from '../game/types';
import { SECTORS } from '../facility';

interface Props {
  engine: MegaCityGameEngine;
  telemetry: HudTelemetry | null;
  sensitivity: number;
  blocked: boolean;
  onExit: () => void;
  onMap: () => void;
  onSettings: () => void;
  onManual: () => void;
}
export function GameHUD({
  engine,
  telemetry: t,
  sensitivity,
  blocked,
  onExit,
  onMap,
  onSettings,
  onManual,
}: Props) {
  const look = useRef<{ id: number; x: number; y: number } | null>(null);
  const joy = useRef<{ id: number; x: number; y: number; r: number } | null>(null);
  const knob = useRef<HTMLSpanElement>(null);
  const [run, setRun] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [hint, setHint] = useState(true);
  const zone = SECTORS.find((s) => s.id === t?.currentZone.id);
  const release = () => {
    look.current = joy.current = null;
    engine.setTouchMove(0, 0);
    if (knob.current) knob.current.style.transform = 'translate(0,0)';
  };
  useEffect(() => {
    if (blocked) {
      release();
      setRun(false);
    }
    const reset = () => {
      release();
      engine.setTouchSprint(false);
      setRun(false);
    };
    window.addEventListener('blur', reset);
    return () => window.removeEventListener('blur', reset);
  }, [blocked, engine]);
  useEffect(() => {
    const timer = window.setTimeout(() => setHint(false), 7800);
    const sync = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', sync);
    return () => {
      clearTimeout(timer);
      document.removeEventListener('fullscreenchange', sync);
    };
  }, []);
  const lookDown = (e: PEvent<HTMLDivElement>) => {
    if (blocked || look.current) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    look.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
  };
  const lookMove = (e: PEvent<HTMLDivElement>) => {
    const p = look.current;
    if (!p || p.id !== e.pointerId || blocked) return;
    engine.addLookDelta((e.clientX - p.x) * 0.0048 * sensitivity, (e.clientY - p.y) * 0.0042 * sensitivity);
    p.x = e.clientX;
    p.y = e.clientY;
  };
  const lookEnd = (e: PEvent<HTMLDivElement>) => {
    if (look.current?.id === e.pointerId) look.current = null;
  };
  const joyMove = (e: PEvent<HTMLDivElement>) => {
    const p = joy.current;
    if (!p || e.pointerId !== p.id || blocked) return;
    const x = e.clientX - p.x,
      y = e.clientY - p.y;
    const l = Math.hypot(x, y),
      m = Math.min(p.r, l) / Math.max(0.01, l);
    if (knob.current) knob.current.style.transform = `translate(${x * m}px,${y * m}px)`;
    engine.setTouchMove(l < 3 ? 0 : (x * m) / p.r, l < 3 ? 0 : (-y * m) / p.r);
  };
  const joyDown = (e: PEvent<HTMLDivElement>) => {
    if (joy.current || blocked) return;
    const rect = e.currentTarget.getBoundingClientRect();
    joy.current = {
      id: e.pointerId,
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2,
      r: rect.width * 0.31,
    };
    e.currentTarget.setPointerCapture(e.pointerId);
    joyMove(e);
  };
  const joyEnd = (e: PEvent<HTMLDivElement>) => {
    if (joy.current?.id !== e.pointerId) return;
    joy.current = null;
    engine.setTouchMove(0, 0);
    if (knob.current) knob.current.style.transform = 'translate(0,0)';
  };
  const toggleRun = () => {
    engine.setTouchSprint(!run);
    setRun(!run);
  };
  return (
    <div
      className="game-hud"
      aria-label="Live 3D exploration"
      data-position={
        t ? `${t.position.x.toFixed(3)},${t.position.y.toFixed(3)},${t.position.z.toFixed(3)}` : undefined
      }
      data-heading={t?.yawDeg}
      data-draw-calls={t?.drawCalls}
      data-triangles={t?.triangles}
    >
      <div
        className="look-surface"
        aria-label="Drag to look around"
        onPointerDown={lookDown}
        onPointerMove={lookMove}
        onPointerUp={lookEnd}
        onPointerCancel={lookEnd}
        onLostPointerCapture={lookEnd}
      />
      <div className="hud-top">
        <button onClick={onExit} className="hud-back" aria-label="Explorer">
          <ArrowLeft size={16} />
          <span>Explorer</span>
        </button>
        <div className="hud-location">
          <span className="micro">
            {t?.isUnderground
              ? `SUBLEVEL 01 / ${t.room?.toUpperCase() || 'SECTOR ' + (zone?.number || '00')}`
              : 'SURFACE / MERIDIAN CITY'}
          </span>
          <strong>{t?.currentZone.name || 'Central concourse'}</strong>
        </div>
        <div className="hud-compass">
          <Compass size={13} />
          {['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round((t?.yawDeg || 0) / 45) % 8]}{' '}
          <span>{String(t?.yawDeg || 0).padStart(3, '0')}&deg;</span>
        </div>
        <div className="hud-tools">
          <button className="hud-map" onClick={onMap} aria-label="World map">
            <Map size={15} />
            <span>World map</span>
            <kbd>M</kbd>
          </button>
          <button className="square-button" aria-label="Field manual" onClick={onManual}>
            <BookOpen size={16} />
          </button>
          <button className="square-button" aria-label="Pause and settings" onClick={onSettings}>
            <Settings2 size={16} />
          </button>
        </div>
      </div>
      <span className="aim-dot" />
      {hint && !t?.nearPrompt && (
        <div className="entry-hint">
          <MousePointer2 size={14} />
          <span className="desktop-only">WASD to move. Drag the scene to look around.</span>
          <span className="mobile-only">Left thumb to move. Drag with your right thumb to look.</span>
          <button onClick={() => setHint(false)} aria-label="Dismiss movement hint">
            Got it
          </button>
        </div>
      )}
      {t?.nearPrompt && (
        <button className="interact-prompt" onClick={() => engine.interact()}>
          <Hand size={16} />
          {t.nearPrompt.id !== 'hatch_toggle'
            ? t.nearPrompt.label
            : t.hatchState === 'open' || t.hatchState === 'opening'
              ? 'Close surface hatch'
              : 'Open surface hatch'}
          <kbd>E</kbd>
        </button>
      )}
      <div
        className="joystick"
        aria-label="Movement joystick"
        onPointerDown={joyDown}
        onPointerMove={joyMove}
        onPointerUp={joyEnd}
        onPointerCancel={joyEnd}
        onLostPointerCapture={joyEnd}
      >
        <i />
        <span ref={knob} />
        <small>MOVE</small>
      </div>
      <div className="hud-bottom">
        <div className="desktop-hints">
          <kbd>W A S D</kbd>Move <i />
          <kbd>DRAG</kbd>Look <i />
          <kbd>SHIFT</kbd>Sprint
        </div>
        <div className="runtime-status">
          <i />
          {t?.fps || 0} FPS <b>/</b> {t?.position.y.toFixed(1) || '-12.0'} M
        </div>
      </div>
      <div className="game-actions">
        <button
          aria-label="Toggle headlamp"
          aria-pressed={t?.flashlightOn}
          className={t?.flashlightOn ? 'enabled' : ''}
          onClick={() => engine.toggleFlashlight()}
        >
          <Flashlight size={18} />
          <span>Light</span>
        </button>
        <button
          aria-label="Toggle sprint"
          aria-pressed={run}
          className={run ? 'enabled' : ''}
          onClick={toggleRun}
        >
          <Footprints size={18} />
          <span>Run</span>
        </button>
        <button aria-label="Jump" onClick={() => engine.requestJump()}>
          <ArrowUp size={18} />
          <span>Jump</span>
        </button>
        {document.fullscreenEnabled && (
          <button
            className="fs-button"
            aria-label={fullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
            onClick={() => {
              if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
              else document.documentElement.requestFullscreen().catch(() => {});
            }}
          >
            <Maximize2 size={16} />
          </button>
        )}
      </div>
      <ChevronUp className="joy-guidance" size={15} />
    </div>
  );
}
