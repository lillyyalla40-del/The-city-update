type RoomName =
  | 'class'
  | 'library'
  | 'science'
  | 'computing'
  | 'assembly'
  | 'staff'
  | 'principal'
  | 'admin'
  | 'wash'
  | 'store';
export interface SchoolRoom {
  code: string;
  name: string;
  kind: RoomName;
  x1: number;
  x2: number;
  z1: number;
  z2: number;
  entry: 'south' | 'north';
}
// These shared boundaries, rather than isolated room modules, define the school.
export const SCHOOL_ROOMS: SchoolRoom[] = [
  { code: '101', name: 'Mathematics', kind: 'class', x1: -100, x2: -85, z1: -49, z2: -32, entry: 'north' },
  { code: '102', name: 'Languages', kind: 'class', x1: -73, x2: -57, z1: -49, z2: -32, entry: 'north' },
  { code: '103', name: 'Earth science', kind: 'class', x1: -57, x2: -40, z1: -49, z2: -32, entry: 'north' },
  {
    code: '104',
    name: 'Science laboratory',
    kind: 'science',
    x1: -40,
    x2: -14,
    z1: -49,
    z2: -32,
    entry: 'north',
  },
  {
    code: '105',
    name: 'Computer laboratory',
    kind: 'computing',
    x1: -14,
    x2: 7,
    z1: -49,
    z2: -32,
    entry: 'north',
  },
  {
    code: '110',
    name: 'Assembly hall',
    kind: 'assembly',
    x1: -100,
    x2: -68,
    z1: -97,
    z2: -61,
    entry: 'south',
  },
  {
    code: '111',
    name: 'School library',
    kind: 'library',
    x1: -68,
    x2: -37,
    z1: -97,
    z2: -61,
    entry: 'south',
  },
  { code: '112', name: 'Teachers lounge', kind: 'staff', x1: -37, x2: -20, z1: -85, z2: -61, entry: 'south' },
  {
    code: '113',
    name: "Principal's office",
    kind: 'principal',
    x1: -20,
    x2: -7,
    z1: -80,
    z2: -61,
    entry: 'south',
  },
  { code: '114', name: 'Administration', kind: 'admin', x1: -7, x2: 7, z1: -80, z2: -61, entry: 'south' },
  {
    code: '115',
    name: 'Student washrooms',
    kind: 'wash',
    x1: -37,
    x2: -14,
    z1: -97,
    z2: -88,
    entry: 'south',
  },
  { code: '116', name: 'School stores', kind: 'store', x1: -14, x2: 7, z1: -97, z2: -88, entry: 'south' },
];
