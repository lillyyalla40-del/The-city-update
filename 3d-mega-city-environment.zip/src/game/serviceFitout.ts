import * as T from 'three';
import { FacilityKit as K } from './facilityKit';
import { cabinet, lightBar, monitor, shelf, table } from './furnishings';

export function serviceFitout(k: K) {
  const pi = Math.PI;
  k.sector = 'medical';
  for (const [x, z] of [
    [-89, -10],
    [-89, 50],
    [-64, 50],
  ])
    for (const dx of [-5.8, 0, 5.8])
      for (const dz of [-3.7, 3.6]) {
        const xx = x + dx,
          zz = z + dz - 1.57;
        k.box(xx, 0.82, zz, 2.33, 1.64, 0.12, 'paint', '#b8c7bb', true);
        k.box(xx, 0.31, zz - 0.068, 2.07, 0.44, 0.035, 'vent', '#8ba197');
        k.box(xx, 1.55, zz + 0.073, 1.67, 0.1, 0.029, 'steel', '#afbeb2');
        k.solid(xx, 0.82, zz, 2.33, 1.64, 0.15);
      }
  k.at(-38.2, 0, -19.2, 0, () => {
    for (const s of [-1, 1]) {
      cabinet(k, s * 1.55, 0, 2.3, 2.28, 0.85, '#b8c6ba', 0, 1);
      k.label(
        s * 1.55,
        1.57,
        0.455,
        1.8,
        0.42,
        s < 0 ? 'Chilled stock' : 'Dispensary',
        'MEDICAL SUPPLIES',
        '#8fb9a8',
      );
    }
  });
  for (const x of [-99.3, -96.1, -92.9]) {
    k.box(x, 0.62, 36.2, 1.25, 1.24, 0.94, 'paint', '#c1cbc3', true);
    k.cyl(x, 0.59, 36.69, 0.41, 0.057, 'steel', '#8f9d92', [pi / 2, 0, 0]);
    k.cyl(x, 0.59, 36.73, 0.32, 0.029, 'graphite', '#6c827b', [pi / 2, 0, 0]);
    k.box(x, 1.04, 36.684, 0.87, 0.15, 0.025, 'vent', '#9fb2a4');
    k.solid(x, 0.62, 36.2, 1.25, 1.24, 0.94);
  }
  k.label(-96.1, 1.58, 35.68, 6.8, 0.48, 'Clean utility', 'LINEN PROCESSING  /  WARD SUPPORT', '#90b2a1', pi);
  k.box(-96.1, 1.58, 35.73, 6.95, 0.56, 0.085, 'steel', '#8e9c90');
  for (const x of [-99, -93.2]) k.cyl(x, 0.8, 35.72, 0.037, 1.6);
  k.sector = 'power';
  for (const z of [-98, -89, -71.1]) {
    k.at(68.1, 0, z, 0, () => {
      k.box(0, 0.18, 0, 3.65, 0.36, 3.49, 'stone', '#969e8e');
      k.box(0, 1.01, 0, 2.55, 1.37, 2.29, 'graphite', '#778773', true);
      for (const f of [-1, 1])
        for (let j = 0; j < 11; j++)
          k.box(f * 1.36, 1.01, -0.97 + j * 0.19, 0.32, 1.29, 0.07, 'steel', '#8b9c87');
      for (const xx of [-0.73, 0, 0.73]) {
        k.cyl(xx, 2.07, 0, 0.11, 0.76, 'paint', '#a29474');
        for (let i = 0; i < 5; i++) k.cyl(xx, 1.82 + i * 0.11, 0, 0.2 - i * 0.015, 0.065, 'paint', '#aba18a');
      }
      k.label(0, 0.99, 1.164, 1.93, 0.4, 'Distribution', 'TRANSFORMER  /  LF GRID', '#c5ad71');
      k.solid(0, 1.15, 0, 3.65, 2.3, 3.49);
      k.shadow(0, 0, 5.1, 5.2);
    });
  }
  k.sector = 'water';
  for (const x of [31.4, 38.2, 50.8, 57.9]) {
    k.at(x, 0, -100.3, 0, () => {
      k.box(0, 0.14, 0, 3.76, 0.28, 2.04, 'stone', '#8ea49a');
      k.cyl(-0.44, 0.81, 0, 0.53, 1.59, 'paint', '#6b928a', [0, 0, pi / 2]);
      for (let t = 0; t < 8; t++)
        k.cyl(-1.04 + t * 0.17, 0.81, 0, 0.574, 0.052, 'steel', '#839d92', [0, 0, pi / 2]);
      k.cyl(0.83, 0.82, 0, 0.72, 0.72, 'paint', '#72958b', [0, 0, pi / 2]);
      k.rod([0.83, 1.28, 0], [0.83, 2.99, 0], 0.19, 'paint', '#71998d');
      k.cyl(0.83, 1.61, 0, 0.27, 0.09, 'steel', '#9dad9e');
      k.rod([0.83, 2.99, 0], [0.83, 2.99, 2.3], 0.19, 'paint', '#749a8c');
      k.box(-0.52, 1.46, 0, 0.64, 0.23, 0.49, 'paint', '#7c9180', true);
      k.solid(0, 0.83, 0, 3.76, 1.67, 2.04);
      k.shadow(0, 0, 4.9, 3.06);
    });
  }
  k.rod([32.23, 2.99, -98], [58.73, 2.99, -98], 0.2, 'paint', '#739b8f');
  k.sector = 'storage';
  for (const x of [43, 55, 67, 79, 91])
    for (const z of [77.6, 90.5])
      for (const dx of [-2.95, 0, 2.95])
        for (const h of [0.5, 1.76, 3.01])
          k.label(
            x + 0.57,
            h,
            z + dx,
            0.52,
            0.19,
            x < 50 ? 'MED-04' : x < 70 ? 'SUP-16' : 'ENG-02',
            'LF INVENTORY',
            '#b9c0a3',
            pi / 2,
          );
  k.sector = 'workshop';
  const shape = new T.Shape();
  shape.moveTo(-0.028, -0.19);
  shape.lineTo(0.028, -0.19);
  shape.lineTo(0.029, 0.105);
  shape.lineTo(0.075, 0.155);
  shape.lineTo(0.064, 0.226);
  shape.lineTo(0.03, 0.173);
  shape.lineTo(-0.02, 0.178);
  shape.lineTo(-0.038, 0.232);
  shape.lineTo(-0.078, 0.172);
  shape.lineTo(-0.029, 0.1);
  shape.closePath();
  const spanner = new T.ExtrudeGeometry(shape, {
    depth: 0.019,
    bevelEnabled: true,
    bevelSegments: 1,
    bevelSize: 0.006,
    bevelThickness: 0.003,
    steps: 1,
  });
  for (const x of [36, 54, 74, 93])
    for (let i = 0; i < 9; i++)
      k.emit(
        spanner,
        'steel',
        x - 2.4 + i * 0.58,
        1.47,
        -48.635,
        0.8 + i * 0.07,
        0.8 + i * 0.07,
        1,
        '#bdc5b5',
      );
  k.sector = 'command';
  for (const z of [77.4, 83.5, 89.7]) {
    k.box(22.23, 3.72, z, 1.25, 0.62, 4.14, 'steel', '#8a9a90', true);
    k.box(21.6, 3.7, z, 0.044, 0.46, 3.76, 'vent', '#647a6c');
  }
  k.sector = 'habitat';
  for (const [x, z] of [
    [45, -2],
    [81, -2],
    [45, 32],
    [81, 32],
  ]) {
    const signX = x - 6.84,
      signZ = z - 5.39;
    k.box(signX, 1.33, signZ, 0.071, 2.66, 0.071, 'steel', '#9aa794');
    k.box(signX, 2.54, signZ, 1.58, 0.68, 0.085, 'graphite', '#566653', true);
    k.label(
      signX,
      2.54,
      signZ + 0.047,
      1.49,
      0.6,
      'RV ' + (x < 60 ? (z < 0 ? '01' : '03') : z < 0 ? '02' : '04'),
      'SERVICED BAY',
      '#d5b683',
    );
  }
  k.sector = 'cafeteria';
  table(k, -99, 69.05, 4.1, 0.91, 'steel');
  monitor(k, -98.5, 0.87, 69.1, 3, 0.74);
  shelf(k, -87, 101.25, 5.5, 0.86, 'medical');
  k.sector = 'concourse';
  for (const x of [-21.95, 21.95]) {
    lightBar(k, x, 9.5, 47, 28.7, 0, true);
    k.box(x, 9.78, 47, 0.78, 0.5, 29.6, 'vent', '#61685c');
  }
  k.at(-5.9, 0, 50.9, pi - 0.15, () => {
    k.box(0, 0.085, 0, 3.66, 0.17, 1.05, 'stone', '#a4aa9d', true);
    k.box(0, 0.78, 0, 1.14, 1.45, 0.43, 'graphite', '#687568', true);
    k.box(0, 2.63, 0, 3.61, 2.71, 0.22, 'graphite', '#4c584e', true);
    k.box(0, 2.63, 0.119, 3.45, 2.54, 0.014, 'directory', '#ffffff');
    k.box(0, 1.27, 0.16, 3.24, 0.03, 0.03, 'light', '#dbc39e');
    k.solid(0, 1.94, 0, 3.62, 3.89, 0.52);
    k.shadow(0, 0, 4.75, 1.89);
  });
  for (const s of [-1, 1]) {
    const x = s * 8.5,
      z = 39.35;
    k.box(x, 4.85, z, 5.49, 0.91, 0.16, 'graphite', '#3d473e', true);
    k.label(
      x,
      4.85,
      z - 0.085,
      5.37,
      0.84,
      s < 0 ? '02  /  MEDICAL' : '04  /  RV SETTLEMENT',
      s < 0 ? 'WEST WING' : 'EAST WING',
      s < 0 ? '#91b8a5' : '#d3b58b',
      pi,
    );
    for (const xx of [-1.99, 1.99]) k.cyl(x + xx, 8.09, z, 0.023, 5.57, 'steel', '#838f7c');
  }
}
