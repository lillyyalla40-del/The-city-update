import * as T from 'three';
import { FacilityKit as K } from './facilityKit';
import { bench, cabinet, chair, dispenser, lightBar, monitor, planter, shelf, table } from './furnishings';

const PI = Math.PI,
  OAK = '#c5ae8b',
  IVORY = '#e3e1d3',
  SAGE = '#7c9c8b';
import { SCHOOL_ROOMS, type SchoolRoom as Room } from '../schoolPlan';
export { SCHOOL_ROOMS } from '../schoolPlan';
const plane = new T.PlaneGeometry(1, 1);

function print(k: K, id: string, w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) {
  if (k.materials[id]) return id;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const c = canvas.getContext('2d')!;
  draw(c);
  const map = new T.CanvasTexture(canvas);
  map.colorSpace = T.SRGBColorSpace;
  map.anisotropy = 4;
  k.materials[id] = new T.MeshStandardMaterial({ color: 0xffffff, map, roughness: 0.8, metalness: 0.02 });
  return id;
}
function picture(k: K, x: number, y: number, z: number, w: number, h: number, mat: string, yaw = 0) {
  k.at(x, y, z, yaw, () => {
    k.box(0, 0, 0, w + 0.09, h + 0.09, 0.07, 'wood', OAK);
    k.emit(plane, mat, 0, 0, 0.039, w, h, 1);
  });
}
function schoolGraphics(k: K) {
  print(k, 'academy-terrazzo', 512, 512, (c) => {
    c.fillStyle = '#e6e3d4';
    c.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 6800; i++) {
      const x = (i * 131.17) % 512,
        y = (i * 71.33) % 512;
      c.fillStyle = ['#c4c5b6', '#d4cec0', '#babaaa', '#eeeadd'][i % 4];
      c.fillRect(x, y, 1 + (i % 3), 0.8 + (i % 2));
    }
    c.strokeStyle = '#a8afa145';
    c.lineWidth = 2;
    c.strokeRect(0.5, 0.5, 511, 511);
  });
  const terrazzo = k.materials['academy-terrazzo'] as T.MeshStandardMaterial;
  terrazzo.map!.wrapS = terrazzo.map!.wrapT = T.RepeatWrapping;
  terrazzo.roughness = 0.46;
  terrazzo.metalness = 0.09;
  terrazzo.onBeforeCompile = (s) => {
    s.vertexShader = s.vertexShader.replace(
      '#include <uv_vertex>',
      '#include <uv_vertex>\n#ifdef USE_INSTANCING\nvMapUv=(instanceMatrix*vec4(position,1.0)).xz*.46;\n#endif',
    );
  };
  terrazzo.customProgramCacheKey = () => 'academy-terrazzo';
  print(k, 'academy-wordmark', 1024, 320, (c) => {
    c.fillStyle = '#e1ddc9';
    c.fillRect(0, 0, 1024, 320);
    c.fillStyle = '#37574b';
    c.textAlign = 'center';
    c.font = '54px Georgia';
    c.fillText('M E R I D I A N', 512, 130);
    c.fillText('A C A D E M Y', 512, 198);
    c.fillRect(432, 228, 160, 2);
    c.font = '16px monospace';
    c.fillText('EST. 2048  /  B-03', 512, 269);
  });
  print(k, 'academy-clock', 256, 256, (c) => {
    c.clearRect(0, 0, 256, 256);
    c.fillStyle = '#ebeadd';
    c.beginPath();
    c.arc(128, 128, 125, 0, 2 * PI);
    c.fill();
    c.translate(128, 128);
    for (let i = 0; i < 60; i++) {
      c.save();
      c.rotate((i * PI) / 30);
      c.fillStyle = '#49554b';
      c.fillRect(-1.3, -112, i % 5 === 0 ? 3.9 : 1.6, i % 5 === 0 ? 10 : 4);
      c.restore();
    }
    c.font = 'bold 23px sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    for (let i = 1; i <= 12; i++)
      c.fillText('' + i, 86 * Math.sin((i * PI) / 6), -86 * Math.cos((i * PI) / 6));
    c.strokeStyle = '#384940';
    c.lineCap = 'round';
    c.lineWidth = 7;
    c.beginPath();
    c.moveTo(-39, -27);
    c.lineTo(0, 0);
    c.lineTo(51, -58);
    c.stroke();
    c.fillStyle = '#af8053';
    c.beginPath();
    c.arc(0, 0, 6, 0, 2 * PI);
    c.fill();
  });
  k.materials['academy-clock'].transparent = true;
  for (let i = 0; i < 6; i++)
    print(k, 'academy-art' + i, 256, 340, (c) => {
      const colors = ['#63886d', '#aec0ab', '#d38f66', '#647b99', '#d7af65', '#b5a3b2'];
      c.fillStyle = ['#e6ddc9', '#e1e4d4', '#e4dcc8'][i % 3];
      c.fillRect(0, 0, 256, 340);
      c.fillStyle = colors[i];
      c.fillRect(17, 17, 222, 220);
      c.fillStyle = '#ece1b9';
      c.beginPath();
      c.arc(173, 76, 28, 0, PI * 2);
      c.fill();
      for (let j = 0; j < 3; j++) {
        c.fillStyle = colors[(i + j + 1) % 6];
        c.beginPath();
        c.moveTo(17, 233 - j * 22);
        c.lineTo(73 + j * 23, 95 + j * 22);
        c.lineTo(168, 172 + j * 10);
        c.lineTo(239, 99 + j * 31);
        c.lineTo(239, 237);
        c.lineTo(17, 237);
        c.fill();
      }
      c.fillStyle = '#36473b';
      c.font = 'bold 21px Barlow, sans-serif';
      c.fillText(
        ['Landforms', 'Colour studies', 'Urban rhythms', 'Blue planet', 'Light & shadow', 'Natural systems'][
          i
        ],
        17,
        276,
      );
      c.font = '12px monospace';
      c.fillText('ACADEMY ART STUDIO', 17, 310);
    });
  print(k, 'academy-notice', 768, 400, (c) => {
    c.fillStyle = '#a5906b';
    c.fillRect(0, 0, 768, 400);
    const titles = [
      'THIS WEEK',
      'SCIENCE CLUB',
      'LIBRARY HOURS',
      'STUDENT EXHIBITION',
      'ASSEMBLY',
      'READING GROUP',
    ];
    for (let i = 0; i < 6; i++) {
      const x = 17 + (i % 3) * 250,
        y = 17 + Math.floor(i / 3) * 190;
      c.save();
      c.translate(x + 116, y + 82);
      c.rotate(((i % 3) - 1) * 0.023);
      c.fillStyle = ['#ede9da', '#cfdbc9', '#e6d2ab'][i % 3];
      c.fillRect(-110, -76, 220, 160);
      c.fillStyle = '#456554';
      c.fillRect(-95, -56, 184, 5);
      c.font = 'bold 16px sans-serif';
      c.fillText(titles[i], -94, -20, 184);
      for (let j = 0; j < 4; j++) {
        c.fillStyle = '#8b9382';
        c.fillRect(-94, 4 + j * 15, 154 - ((j * 17 + i * 9) % 62), 3);
      }
      c.fillStyle = '#6b7768';
      c.beginPath();
      c.arc(0, -68, 4, 0, 2 * PI);
      c.fill();
      c.restore();
    }
  });
  for (let i = 0; i < 4; i++)
    print(k, 'teaching' + i, 512, 274, (c) => {
      c.fillStyle = i === 0 ? '#294b3f' : '#e4e6dc';
      c.fillRect(0, 0, 512, 274);
      c.fillStyle = i === 0 ? '#d4dfc9' : '#395d4b';
      c.font = 'bold 28px sans-serif';
      c.fillText(
        ['Geometry / Triangles', 'Language & literature', 'The solar system', 'Digital systems'][i],
        20,
        40,
      );
      c.fillRect(20, 52, 468, 2);
      c.strokeStyle = i === 0 ? '#d3daba' : '#708c76';
      c.lineWidth = 2;
      if (i === 0) {
        c.beginPath();
        c.moveTo(50, 224);
        c.lineTo(50, 94);
        c.lineTo(252, 224);
        c.closePath();
        c.stroke();
        c.font = '24px Georgia';
        c.fillText('a² + b² = c²', 290, 155);
        c.fillText('A', 28, 101);
        c.fillText('B', 25, 242);
        c.fillText('C', 254, 241);
      } else if (i === 2) {
        for (let n = 0; n < 7; n++) {
          c.beginPath();
          c.arc(40 + n * 66, 156, 8 + (n % 4) * 5, 0, 2 * PI);
          c.fillStyle = ['#bb9869', '#708b96', '#a08064'][n % 3];
          c.fill();
        }
        c.font = '15px monospace';
        c.fillText('ORBITAL SYSTEMS / LESSON 03', 24, 234);
      } else {
        c.font = '18px Georgia';
        ['Observe and describe', 'Compare the evidence', 'Discuss your conclusions'].forEach((s, j) =>
          c.fillText(j + 1 + '.  ' + s, 29, 105 + j * 49),
        );
      }
    });
  print(k, 'academy-certificate', 384, 256, (c) => {
    c.fillStyle = '#eee6c8';
    c.fillRect(0, 0, 384, 256);
    c.strokeStyle = '#b1a17b';
    c.lineWidth = 3;
    c.strokeRect(12, 12, 360, 232);
    c.textAlign = 'center';
    c.fillStyle = '#394f43';
    c.font = '22px Georgia';
    c.fillText('Meridian Academy', 192, 62);
    c.font = 'bold 26px Georgia';
    c.fillText('Certificate of Merit', 192, 109);
    c.font = '15px Georgia';
    c.fillText('Excellence in education', 192, 147);
    c.fillStyle = '#a58d4c';
    c.beginPath();
    c.arc(192, 196, 19, 0, PI * 2);
    c.fill();
  });
}
function clock(k: K, x: number, y: number, z: number, size = 0.63, yaw = 0) {
  k.at(x, y, z, yaw, () => {
    k.cyl(0, 0, 0, size * 0.52, 0.075, 'steel', '#7f8b7f', [PI / 2, 0, 0]);
    k.emit(plane, 'academy-clock', 0, 0, 0.041, size, size, 1);
  });
}
function partition(k: K, x: number, z: number, w: number, d: number, h = 3.86) {
  k.box(x, h / 2, z, w, h, d, 'paint', IVORY);
  k.solid(x, h / 2, z, w, h, d);
  k.box(x, 0.105, z, w + 0.009, 0.21, d + 0.009, 'wood', '#9fa796');
}
function frontage(k: K, r: Room) {
  const w = r.x2 - r.x1,
    front = r.entry === 'south' ? r.z2 : r.z1,
    door = r.x1 + Math.min(3.2, w * 0.21),
    gap = r.kind === 'assembly' ? 3.4 : 2.18;
  const left = door - gap / 2,
    right = door + gap / 2;
  for (const [a, b] of [
    [r.x1, left],
    [right, r.x2],
  ]) {
    if (b - a < 0.15) continue;
    const mid = (a + b) / 2;
    k.box(mid, 0.52, front, b - a, 1.04, 0.19, 'paint', IVORY);
    k.box(mid, 0.16, front, b - a, 0.32, 0.207, 'wood', OAK);
    k.box(mid, 1.06, front, b - a, 0.09, 0.26, 'wood', OAK);
    k.box(mid, 2, front, b - a - 0.03, 1.82, 0.045, 'glass', '#e0e8d9');
    k.box(mid, 3.39, front, b - a, 1.01, 0.19, 'paint', IVORY);
    k.solid(mid, 1.95, front, b - a, 3.9, 0.19);
    for (let p = a + 0.1; p <= b; p += 2.05) k.box(p, 1.99, front, 0.09, 1.86, 0.13, 'wood', OAK);
    k.box(mid, 2.94, front, b - a, 0.085, 0.21, 'wood', OAK);
  }
  const facing = r.entry === 'south' ? 1 : -1,
    yaw = facing > 0 ? 0 : PI;
  k.box(door, 3.36, front, gap + 0.16, 1.07, 0.24, 'paint', IVORY);
  k.solid(door, 3.36, front, gap + 0.16, 1.07, 0.24);
  for (const side of [-1, 1])
    k.box(door + side * (gap / 2 + 0.035), 1.42, front, 0.105, 2.84, 0.27, 'wood', '#9f805f');
  k.box(door, 2.82, front, gap + 0.21, 0.12, 0.27, 'wood', '#9f805f');
  k.label(
    door,
    3.24,
    front + facing * 0.135,
    gap + 1.06,
    0.54,
    r.code + ' / ' + r.name,
    'MERIDIAN ACADEMY',
    '#a9c2ac',
    yaw,
  );
  // Park the hinged wood-and-glass leaf against the reveal, outside the walking line.
  k.at(left + 0.08, 0, front - facing * 0.57, PI / 2, () => {
    k.box(0, 1.33, 0, 1.12, 2.66, 0.07, 'wood', '#b49972');
    k.box(0, 1.78, 0.046, 0.76, 1.25, 0.012, 'glazing', '#e3e9db');
    k.box(0.38, 1.01, 0.082, 0.14, 0.028, 0.08, 'steel', '#b4baab');
    k.solid(0, 1.33, 0, 1.12, 2.66, 0.07);
  });
  const d = r.z2 - r.z1,
    cx = (r.x1 + r.x2) / 2,
    cz = (r.z1 + r.z2) / 2;
  k.box(cx, 3.97, cz, w, 0.19, d, 'paint', '#deded0');
  k.solid(cx, 3.97, cz, w, 0.19, d);
  for (let x = r.x1 + 2.4; x < r.x2 - 1; x += 5.3) {
    for (let z = r.z1 + 3; z < r.z2 - 1; z += 7) {
      lightBar(k, x, 3.78, z, 3.3, 0);
      k.box(x + 0.54, 3.866, z, 0.48, 0.025, 1.4, 'vent', '#a5b1a4');
    }
  }
  return { door, front, facing, cx, cz };
}
function work(k: K, x: number, z: number, yaw = 0, w = 2.2) {
  k.at(x, 0, z, yaw, () => {
    table(k, 0, 0, w, 0.97);
    monitor(k, -0.17, 0.871, -0.13, 4, 0.84);
    k.oval(0.4, 0.89, 0.26, 0.056, 0.029, 0.09, 'rubber', '#738479');
    k.box(w * 0.33, 0.42, -0.09, 0.35, 0.69, 0.47, 'graphite', '#566759', true);
    k.box(w * 0.33, 0.56, 0.151, 0.25, 0.06, 0.01, 'vent', '#859384');
    chair(k, -0.12, 1.03, PI, 'office', '#6f8474');
  });
}
function paper(k: K, x: number, y: number, z: number) {
  k.box(x, y, z, 0.31, 0.018, 0.23, 'paint', '#e9e5d6', false, [0, 0.14, 0]);
  k.box(x + 0.03, y + 0.013, z + 0.035, 0.18, 0.014, 0.025, 'paint', '#b8c4b0');
}
function frontBoard(k: K, r: Room, kind: number) {
  const cx = (r.x1 + r.x2) / 2;
  picture(k, cx, 1.92, r.z2 - 0.15, 5.1, 1.86, 'teaching' + kind, PI);
  k.box(cx, 1.01, r.z2 - 0.22, 5.3, 0.06, 0.22, 'steel', '#a7b6a7');
  picture(k, r.x1 + 2.1, 1.93, r.z2 - 0.15, 1.37, 1.76, 'academy-art' + kind, PI);
  clock(k, r.x2 - 2.4, 2.75, r.z2 - 0.15, 0.62, PI);
  work(k, cx + 3.7, r.z2 - 3.2, PI, 1.85);
}
function classroom(k: K, r: Room, i: number) {
  const cx = (r.x1 + r.x2) / 2;
  frontBoard(k, r, i);
  for (const a of [-4.4, -1.65, 1.65, 4.4])
    for (const z of [-45.1, -42.1, -39.1]) {
      table(k, cx + a, z, 1.39, 0.72);
      chair(k, cx + a, z - 0.79, 0, 'student', i === 1 ? '#a99475' : SAGE);
      if ((a > 0 && z === -42.1) || (a < 0 && z === -45.1)) paper(k, cx + a, 0.873, z);
    }
  k.box(r.x2 - 2.31, 1.93, r.z2 - 0.17, 2.35, 1.31, 0.12, 'graphite', '#354b42', true);
  k.box(r.x2 - 2.31, 1.93, r.z2 - 0.239, 2.22, 1.17, 0.012, 'screen4', '#d2d7c8');
  cabinet(k, r.x2 - 0.65, -36.8, 3.5, 1.85, 0.63, '#a3b39e', -PI / 2, 2);
  shelf(k, r.x1 + 0.58, -37.4, 3.4, 0.54, 'books', PI / 2);
  picture(k, r.x1 + 0.13, 2.05, -42.5, 1.32, 1.68, 'academy-art' + (i + 3), PI / 2);
}
function labSink(k: K, x: number, z: number) {
  cabinet(k, x, z, 1.6, 0.89, 0.83, '#a3b6a5');
  k.oval(x, 0.939, z, 0.49, 0.019, 0.28, 'steel', '#73877c');
  k.rod([x, 1, z - 0.28], [x, 1.32, z - 0.28], 0.026);
  k.rod([x, 1.32, z - 0.28], [x, 1.32, z - 0.04], 0.025);
}
function stool(k: K, x: number, z: number) {
  k.cyl(x, 0.63, z, 0.243, 0.09, 'wood', '#b59e79');
  for (const j of [0, 1, 2, 3]) {
    const a = (PI / 2) * j + 0.75;
    k.rod(
      [x + Math.cos(a) * 0.16, 0.59, z + Math.sin(a) * 0.16],
      [x + Math.cos(a) * 0.26, 0.025, z + Math.sin(a) * 0.26],
      0.023,
    );
  }
  k.cyl(x, 0.255, z, 0.17, 0.026, 'steel', '#8d9b90');
  k.solid(x, 0.32, z, 0.47, 0.63, 0.47);
}
function labs(k: K, r: Room, pc: boolean) {
  frontBoard(k, r, pc ? 3 : 2);
  const cx = (r.x1 + r.x2) / 2;
  for (const z of [-44.9, -40.9])
    for (const offs of [-5.2, 2.9]) {
      const x = cx + offs;
      table(k, x, z, 4.9, 1.39, pc ? 'wood' : 'steel');
      for (const side of [-1.25, 1.25]) {
        if (pc) {
          monitor(k, x + side, 0.87, z + 0.19, 4, 0.83, PI);
          k.oval(x + side - 0.41, 0.893, z - 0.27, 0.055, 0.026, 0.082, 'rubber', '#66766d');
          chair(k, x + side, z - 1.06, 0, 'student', SAGE);
          k.box(x + side - 0.48, 0.44, z + 0.12, 0.29, 0.63, 0.5, 'graphite', '#56655b', true);
          k.rod([x + side, 0.7, z + 0.45], [x + side - 0.46, 0.64, z + 0.38], 0.018, 'rubber', '#4a544b');
        } else {
          stool(k, x + side, z - 1.2);
          k.cyl(x + side + 0.3, 1.04, z, 0.095, 0.34, 'glass', '#daebe0');
          k.cyl(x + side + 0.3, 0.939, z, 0.089, 0.12, 'paint', '#a9c4b1');
          k.box(x + side - 0.25, 0.89, z, 0.43, 0.06, 0.29, 'steel', '#899c90');
          k.rod([x + side - 0.38, 0.9, z], [x + side - 0.38, 1.52, z], 0.026);
          k.cyl(x + side - 0.1, 1.31, z, 0.074, 0.22, 'glazing', '#b4caba', [0, 0, -0.32]);
        }
      }
      k.box(x, 0.69, z + 0.54, 4.48, 0.095, 0.15, 'graphite', '#718174');
    }
  cabinet(k, r.x2 - 0.57, -41, 5.4, 1.96, 0.69, '#9cae9b', -PI / 2, 3);
  if (!pc) {
    labSink(k, r.x1 + 1.4, -34.5);
    labSink(k, r.x1 + 3.22, -34.5);
  }
}
function library(k: K, r: Room) {
  for (const x of [-63.4, -59.6, -55.8])
    for (const z of [-86.4, -74.7]) shelf(k, x, z, 6.8, 0.77, 'books', PI / 2);
  for (const x of [-47, -40.7])
    for (const z of [-88.7, -78.8]) {
      table(k, x, z, 3.2, 1.37);
      for (const j of [-0.8, 0.8])
        for (const side of [-1, 1])
          chair(k, x + j, z + side * 1.13, side === 1 ? PI : 0, 'lounge', '#94a18b');
      k.cyl(x, 1.24, z, 0.025, 0.76);
      k.box(x, 1.54, z, 0.84, 0.09, 0.31, 'light', '#fff2d0', true);
      paper(k, x - 0.94, 0.873, z);
    }
  cabinet(k, -56, -65.3, 4.7, 1.04, 0.92, '#abbb9b');
  monitor(k, -55, 1.08, -65.3, 4);
  k.label(-56, 0.65, -64.82, 2.45, 0.38, 'LIBRARY DESK', 'BORROW / RETURN', '#ced3af');
  for (const x of [-62, -58, -54]) work(k, x, -93.5, 0, 2.1);
  picture(k, -49, 2.2, r.z1 + 0.15, 5.8, 1.55, 'academy-wordmark');
  planter(k, -40, -64, 1.03);
}
function assembly(k: K) {
  k.box(-84, 0.32, -91.7, 27, 0.64, 8.5, 'wood', '#bcaa8a');
  k.walk(-84, -91.7, 27, 8.5, 0.64);
  for (let i = 0; i < 3; i++) {
    const y = 0.16 * (i + 1);
    k.box(-84, y / 2, -85.98 - i * 0.49, 4.7, y, 0.5, 'wood', '#c1ac86');
    k.walk(-84, -85.98 - i * 0.49, 4.7, 0.5, y);
  }
  picture(k, -84, 2.51, -96.84, 10.6, 2.65, 'academy-wordmark');
  k.box(-79.8, 1.16, -89.7, 0.89, 1.04, 0.64, 'wood', '#927c60', true);
  k.box(-79.8, 1.72, -89.7, 1.16, 0.11, 0.81, 'wood', '#b3a07a', true, [-0.13, 0, 0]);
  k.rod([-80, 1.79, -89.56], [-80, 2.11, -89.73], 0.012, 'graphite', '#425045');
  k.solid(-79.8, 1.13, -89.7, 1.13, 1.06, 0.81);
  for (const x of [-94, -92, -90, -88, -80, -78, -76, -74])
    for (const z of [-83, -79.7, -76.4, -73.1, -69.8, -66.5]) chair(k, x, z, PI, 'student', '#95a48d');
  for (let z = -91; z < -63; z += 2.3)
    for (const x of [-99.82, -68.19]) k.box(x, 2.03, z, 0.1, 3.15, 1.88, 'fabric', '#a7ab97');
  picture(k, -72.3, 2.11, -61.15, 3.16, 1.48, 'academy-notice', PI);
}
function offices(k: K) {
  work(k, -14.7, -73.9, PI, 3.3);
  paper(k, -14.1, 0.873, -73.8);
  chair(k, -13.5, -71.7, PI, 'lounge', '#b4a68a');
  chair(k, -15.6, -71.7, PI, 'lounge', '#b4a68a');
  shelf(k, -17.7, -78.8, 3.5, 0.61, 'books');
  cabinet(k, -10.1, -78.8, 3.75, 1.08, 0.7, '#afb7a2');
  picture(k, -13.6, 2.37, -79.85, 1.8, 1.18, 'academy-certificate');
  clock(k, -9.18, 2.72, -79.85);
  for (const xx of [-32.6, -26.9]) work(k, xx, -80.8, 0);
  table(k, -28.2, -70.8, 4.7, 1.49);
  for (const xx of [-29.5, -27])
    for (const f of [-1, 1]) chair(k, xx, -70.8 + f * 1.2, f > 0 ? PI : 0, 'lounge', '#b0a184');
  cabinet(k, -35.9, -74.1, 3.65, 1.02, 0.71, '#a9b8a1', PI / 2);
  dispenser(k, -35.8, -76.8);
  shelf(k, -22, -79.8, 3.5, 0.59, 'books', PI / 2);
  picture(k, -30, 2.06, -84.86, 3.36, 1.7, 'academy-notice');
  for (const x of [-3.4, 3.2]) work(k, x, -74.7, 0, 2.5);
  cabinet(k, 4.3, -66.4, 3.5, 1.39, 0.73, '#acb9a0', -PI / 2);
  picture(k, 0.09, 2.19, -79.85, 2.6, 1.52, 'academy-certificate');
  for (const x of [-33.7, -29.7, -25.7, -21.7]) {
    k.box(x - 1.11, 1.09, -94.4, 0.1, 1.95, 2.23, 'paint', '#a9b8a6', true);
    k.box(x, 0.8, -95.3, 0.61, 0.66, 0.24, 'paint', '#eaddcd', true);
    k.oval(x, 0.43, -94.73, 0.34, 0.23, 0.46, 'paint', '#e7eadb');
    k.oval(x, 0.55, -94.73, 0.237, 0.055, 0.33, 'paint', '#a7b6a8');
    k.cyl(x, 0.24, -94.8, 0.2, 0.43, 'paint', '#e4e9d9');
    k.solid(x, 0.55, -94.87, 0.79, 1.1, 1.0);
    if (x > -33) labSink(k, x, -89.2);
  }
  for (const x of [-9.8, -3.9, 2.6]) shelf(k, x, -92.4, 5.18, 0.89, 'supply', PI / 2);
}

export function buildAcademy(k: K) {
  schoolGraphics(k);
  k.box(-40, 0.003, -64, 127.55, 0.008, 79.54, 'academy-terrazzo', '#f1f1e8');
  const boundaries = new Set<string>();
  const shared = (x: number, z: number, w: number, d: number, h = 3.87) => {
    const key = [x, z, w, d].join(':');
    if (boundaries.has(key)) return;
    boundaries.add(key);
    partition(k, x, z, w, d, h);
  };
  for (const r of SCHOOL_ROOMS) {
    const w = r.x2 - r.x1,
      d = r.z2 - r.z1,
      cz = (r.z1 + r.z2) / 2,
      cx = (r.x1 + r.x2) / 2;
    shared(r.x1, cz, 0.16, d);
    shared(r.x2, cz, 0.16, d);
    shared(cx, r.entry === 'south' ? r.z1 : r.z2, w, 0.16);
    frontage(k, r);
    if (r.kind === 'class') classroom(k, r, Number(r.code) - 101);
    else if (r.kind === 'science' || r.kind === 'computing') labs(k, r, r.kind === 'computing');
    else if (r.kind === 'library') library(k, r);
    else if (r.kind === 'assembly') assembly(k);
  }
  offices(k);
  // A continuous T-shaped circulation spine joins the original four sector portals.
  k.box(-40, 4.34, -55, 128, 0.18, 12, 'paint', '#e9e6db');
  k.solid(-40, 4.34, -55, 128, 0.18, 12);
  k.box(15.4, 4.77, -79.1, 16.9, 0.15, 35.9, 'paint', '#e7e8da');
  k.box(15.4, 4.77, -40.2, 16.9, 0.15, 31.9, 'paint', '#dedfcf');
  k.solid(15.4, 4.77, -40.2, 16.9, 0.15, 31.9);
  for (let z = -45.7; z < -25; z += 4.15) {
    k.box(15.5, 4.678, z, 2.94, 0.019, 3.69, 'light', '#fff3dc');
    for (const f of [-1, 1]) k.box(15.5 + f * 1.55, 4.65, z, 0.085, 0.084, 3.88, 'wood', OAK);
  }
  // Warm perimeter liners stop at the existing emergency and service portals.
  for (const [a, b] of [
    [-103.75, -86.3],
    [-79.7, -58.6],
    [-52.15, -24.4],
  ]) {
    const z = (a + b) / 2;
    k.box(23.57, 1.8, z, 0.16, 3.6, b - a, 'paint', '#dfddcc');
    k.box(23.47, 0.37, z, 0.06, 0.74, b - a, 'wood', OAK);
    k.box(23.452, 0.77, z, 0.05, 0.06, b - a, 'paint', SAGE);
  }
  for (let x = -97; x < 22; x += 6) {
    k.box(x, 4.18, -55, 0.17, 0.25, 11.96, 'wood', '#c5b293');
    k.box(x + 2.72, 4.218, -55, 4.82, 0.041, 2.7, 'light', '#f6efda');
    lightBar(k, x + 2.1, 4.12, -50.6, 3.9, PI / 2, true);
  }
  for (const z of [-60.3, -49.64]) k.box(-42, 0.009, z, 119, 0.019, 0.16, 'paint', '#a6b4a2');
  k.box(15.65, 0.008, -46.1, 0.24, 0.015, 38.2, 'paint', '#a8b6a2');
  for (const r of SCHOOL_ROOMS.slice(0, 5)) {
    const take = Math.min(4, Math.floor((r.x2 - r.x1) / 3));
    for (let i = 0; i < take; i++) {
      const x = r.x2 - 1.15 - i * 0.61;
      k.box(x, 1.04, -49.34, 0.58, 1.96, 0.49, 'paint', i % 2 === 0 ? '#90aa99' : '#9bb19e', true);
      k.box(x, 1.73, -49.596, 0.33, 0.19, 0.014, 'vent', '#819985');
      k.box(x + 0.18, 1.0, -49.615, 0.032, 0.19, 0.047, 'steel', '#cbd5c7');
      k.box(x, 0.19, -49.6, 0.3, 0.028, 0.018, 'graphite', '#879a86');
      k.solid(x, 1.05, -49.34, 0.61, 2.05, 0.5);
    }
  }
  for (const [n, x] of [-97, -66, -50, -29, -6].entries()) {
    picture(k, x, 2.02, -60.875, 1.68, 1.98, 'academy-art' + n);
  }
  for (const x of [-70, -31, 3]) {
    bench(k, x, -59.89, 0, 3.15);
    planter(k, x + 2.58, -59.7, 0.73);
  }
  // The school threshold is recessed inside the existing bunker gate, not a new external entrance.
  for (const x of [10.88, 21.12]) {
    k.box(x, 2.01, -31.9, 0.38, 4.02, 0.9, 'wood', OAK);
    k.solid(x, 2.01, -31.9, 0.38, 4.02, 0.9);
  }
  k.box(16, 3.87, -31.9, 10.6, 0.67, 0.91, 'wood', OAK);
  k.label(16, 3.9, -31.425, 8.75, 0.55, 'MERIDIAN ACADEMY', 'MAIN ENTRANCE  /  B-03', '#beceae');
  k.at(10.5, 0, -41.3, PI / 2, () => {
    cabinet(k, 0, 0, 6.14, 1.09, 1.12, '#bda986');
    monitor(k, -1.62, 1.16, 0, 4);
    paper(k, 1.61, 1.16, 0);
    k.label(0, 0.7, 0.573, 2.84, 0.41, 'RECEPTION', 'STUDENT SERVICES', '#d5cbab');
  });
  picture(k, 7.14, 2.13, -40.3, 5.15, 1.68, 'academy-wordmark', PI / 2);
  clock(k, 7.14, 3.13, -36.3, 0.71, PI / 2);
  picture(k, 23.45, 2.05, -39.3, 3.86, 1.91, 'academy-notice', -PI / 2);
  bench(k, 22.78, -40.8, -PI / 2, 3.5);
  planter(k, 21.94, -46.1, 1.11);
  planter(k, 9.6, -33.7, 0.88);
  k.label(
    15.22,
    3.63,
    -48.73,
    6.41,
    0.61,
    'ACADEMIC WALK',
    'CLASSROOMS 101 - 105  /  LIBRARY  /  ASSEMBLY',
    '#abc5af',
  );
  k.box(15.22, 3.63, -48.81, 6.57, 0.73, 0.12, 'paint', '#4d6456');
  for (const x of [12.7, 17.74]) k.rod([x, 3.99, -48.81], [x, 4.69, -48.81], 0.025);
  for (let z = -97; z < -26; z += 6.6) {
    lightBar(k, 16, 4.54, z, 4.45, 0, true);
    k.box(16, 4.82, z, 15.9, 0.34, 0.2, 'wood', '#c0ac8d');
  }
  k.label(-79.1, 2.71, -31.89, 6.7, 0.66, 'WEST ENTRY', 'MERIDIAN ACADEMY  /  MEDICAL CONNECTION', '#a4bda8');
  k.box(-79.1, 2.71, -31.96, 6.88, 0.79, 0.12, 'paint', '#586d5c');
  for (const x of [-82.3, -75.86]) {
    k.box(x, 1.61, -31.96, 0.11, 3.22, 0.14, 'wood', OAK);
    k.solid(x, 1.61, -31.96, 0.11, 3.22, 0.14);
  }
}
