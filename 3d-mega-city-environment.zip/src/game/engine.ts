import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { SECTORS, sectorPoint } from '../facility';
import { CollisionWorld } from './collision';
import { createTexturePack } from './textures';
import { buildMegaCity } from './cityBuilder';
import { createBunkerHatch, BunkerHatchController } from './bunkerHatch';
import { buildUndergroundBunker } from './bunkerBuilder';
import { ThirdPersonPlayer } from './playerController';
import { FastTravelPoint, HudTelemetry, PlayerInputState, QualityPreset, ZoneDefinition } from './types';
import { polishCity } from './cityPolish';
import { Atmosphere } from './atmosphere';
import { worldAudio } from '../ambience';
import { SCHOOL_ROOMS } from './academy';
import { createAftermath } from './surface/aftermath';

export const FAST_TRAVEL_POINTS: FastTravelPoint[] = [
  {
    id: 'plaza',
    label: 'Central Meridian Plaza (Hatch)',
    group: 'Surface City',
    x: 0,
    y: 0.15,
    z: -24,
    yaw: Math.PI,
  },
  {
    id: 'financial',
    label: 'Apex Financial Towers',
    group: 'Surface City',
    x: -68,
    y: 0.0,
    z: -68,
    yaw: 0.7,
  },
  { id: 'mall', label: 'Metro Galleria Complex', group: 'Surface City', x: -84, y: 0.15, z: 72, yaw: 2.6 },
  { id: 'hotel', label: 'Grand Meridian Twin Hotel', group: 'Surface City', x: 68, y: 0.0, z: 74, yaw: -2.2 },
  {
    id: 'highway',
    label: 'Elevated Expressway Deck',
    group: 'Surface City',
    x: 0,
    y: 6.4,
    z: -128,
    yaw: Math.PI * 0.5,
  },
  { id: 'park', label: 'Northgate Civic Park', group: 'Surface City', x: 98, y: 0.15, z: -98, yaw: 0.4 },
  ...SECTORS.map(sectorPoint),
];

export class MegaCityGameEngine {
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private collision = new CollisionWorld();
  private player: ThirdPersonPlayer;
  private hatch: BunkerHatchController;
  private cityGroup: THREE.Group;
  private bunkerGroup: THREE.Group;
  private zones: ZoneDefinition[] = [];

  private hemiLight: THREE.HemisphereLight;
  private sunLight: THREE.DirectionalLight;
  private bunkerAmbient: THREE.AmbientLight;
  private fog: THREE.FogExp2;
  private interior: ReturnType<typeof buildUndergroundBunker>;
  private interiorEnvironment: THREE.WebGLRenderTarget | null = null;
  private practical: THREE.PointLight;
  private localKey: THREE.DirectionalLight;
  private paused = false;
  private resolutionTimer = 0;
  private shadowCell = '';
  private sky: THREE.Mesh;
  private cityDetail: ReturnType<typeof polishCity>;
  private aftermath: ReturnType<typeof createAftermath> | null = null;
  private atmosphere: Atmosphere;
  private surfaceReflection: THREE.WebGLRenderTarget | null = null;
  private surfaceShadowTimer = 0;
  private machineTest = false;
  private lastHatchState = 'closed';
  private onTerminal: (tab: 'surface' | 'bunker' | 'school') => void;

  private quality: QualityPreset;
  private animId = 0;
  private lastTime = performance.now();
  private elapsed = 0;
  private fpsAccum = 0;
  private fpsFrames = 0;
  private currentFps = 60;
  private hudTimer = 0;

  // Input states
  private keys = new Set<string>();
  private touchMove = { x: 0, y: 0 };
  private touchSprint = false;
  private jumpQueued = false;
  private autoFlashlightApplied = false;

  private onTelemetry: (t: HudTelemetry) => void;
  private resizeObserver: ResizeObserver;

  constructor(
    private readonly container: HTMLElement,
    onTelemetry: (t: HudTelemetry) => void,
    initialQuality: QualityPreset,
    startPoint: FastTravelPoint = sectorPoint(SECTORS[0]),
    firstPerson = true,
    effects = true,
    onTerminal: (tab: 'surface' | 'bunker' | 'school') => void = () => {},
  ) {
    this.onTelemetry = onTelemetry;
    this.quality = initialQuality;
    this.onTerminal = onTerminal;

    // Renderer configured for crisp visuals + smooth mobile FPS
    this.renderer = new THREE.WebGLRenderer({
      antialias: initialQuality !== 'mobile',
      powerPreference: 'high-performance',
      stencil: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.applyQualityPreset(initialQuality);

    this.renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(this.renderer.domElement);

    // Scene & Atmospheric Dusk Sky
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x162233);
    this.fog = new THREE.FogExp2(0x182538, 0.0042);
    this.scene.fog = this.fog;

    // Camera (near = 0.25, far = 420 for crisp depth buffer on mobile)
    this.camera = new THREE.PerspectiveCamera(
      62,
      container.clientWidth / Math.max(1, container.clientHeight),
      0.25,
      420,
    );

    // Lighting: Atmospheric Metropolis Dusk + Practical Subterranean Fill
    this.hemiLight = new THREE.HemisphereLight(0x8bb6e8, 0x2b303a, 1.15);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xffddb3, 1.65);
    this.sunLight.position.set(110, 145, 75);
    this.scene.add(this.sunLight);

    this.bunkerAmbient = new THREE.AmbientLight(0xd4e2f0, 0.45);
    this.scene.add(this.bunkerAmbient);

    // Subtle Atmospheric Sky Dome
    const skyGeo = new THREE.SphereGeometry(360, 16, 12);
    const skyMat = new THREE.MeshBasicMaterial({
      color: 0x22354f,
      side: THREE.BackSide,
      fog: false,
    });
    this.sky = new THREE.Mesh(skyGeo, skyMat);
    this.scene.add(this.sky);

    // Build Procedural Textures & World
    const textures = createTexturePack();

    const city = buildMegaCity(this.collision, textures);
    this.cityGroup = city.group;
    this.cityDetail = polishCity(city.group, textures, this.collision);
    this.cityDetail.setDetail(initialQuality);
    skyMat.map = this.cityDetail.skyDomeMap;
    skyMat.color.set('#ffffff');
    skyMat.needsUpdate = true;
    this.scene.add(this.cityGroup);

    this.hatch = createBunkerHatch(this.collision, textures);
    this.scene.add(this.hatch.group);
    this.scene.add(this.hatch.shaftGroup);

    const bunker = buildUndergroundBunker(this.collision);
    this.interior = bunker;
    bunker.setDetail(initialQuality === 'mobile');
    this.bunkerGroup = bunker.group;
    this.scene.add(this.bunkerGroup);

    this.zones = [...bunker.zones, ...city.zones];

    if (initialQuality !== 'mobile') this.prepareReflections();
    this.practical = new THREE.PointLight(0xffecd0, 72, 32, 2);
    this.localKey = new THREE.DirectionalLight(0xffebce, 1.9);
    this.localKey.castShadow = true;
    this.localKey.shadow.mapSize.set(1024, 1024);
    Object.assign(this.localKey.shadow.camera, {
      left: -21,
      right: 21,
      top: 21,
      bottom: -21,
      near: 0.3,
      far: 72,
    });
    this.localKey.shadow.camera.updateProjectionMatrix();
    this.localKey.shadow.bias = -0.00025;
    this.localKey.shadow.normalBias = 0.025;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.shadowMap.autoUpdate = false;
    this.scene.add(this.practical, this.localKey, this.localKey.target);
    this.scene.add(this.sunLight.target);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.set(1024, 1024);
    Object.assign(this.sunLight.shadow.camera, {
      left: -74,
      right: 74,
      top: 74,
      bottom: -74,
      near: 1,
      far: 265,
    });
    this.sunLight.shadow.camera.updateProjectionMatrix();
    this.sunLight.shadow.bias = -0.0004;
    this.sunLight.shadow.normalBias = 0.09;
    const stack =
      this.cityDetail.towers.find((t) => t.x < 0 && t.z < 0 && t.h > 60) || this.cityDetail.towers[0];
    this.atmosphere = new Atmosphere(
      this.scene,
      this.cityDetail.lamps,
      this.cityDetail.headlamps,
      { x: stack.x + stack.w * 0.19, y: stack.h + 4.55, z: stack.z - stack.d * 0.18 },
      initialQuality,
    );
    this.atmosphere.enabled = effects;

    // Resolve the selected entry position against the existing shared collision world.
    this.player = new ThirdPersonPlayer(this.collision, this.scene);
    this.player.setPerspective(firstPerson, this.camera);
    this.fastTravel(startPoint);

    // Bind Resize & Keyboard Listeners
    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(container);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.clearInput);

    this.lastTime = performance.now();
    this.loop(this.lastTime);
  }

  public applyQualityPreset(preset: QualityPreset) {
    this.quality = preset;
    this.interior?.setDetail(preset === 'mobile');
    this.cityDetail?.setDetail(preset);
    if (this.atmosphere) this.atmosphere.quality = preset;
    if (this.interior && preset !== 'mobile') this.prepareReflections();
    this.shadowCell = '';
    const dpr = window.devicePixelRatio || 1;
    if (preset === 'mobile') {
      this.renderer.setPixelRatio(Math.min(dpr, 1.0) * 0.88);
    } else if (preset === 'balanced') {
      this.renderer.setPixelRatio(Math.min(dpr, 1.45));
    } else {
      this.renderer.setPixelRatio(Math.min(dpr, 2.0));
    }
  }

  private prepareReflections() {
    if (this.interiorEnvironment) return;
    const environment = new RoomEnvironment();
    const prefilter = new THREE.PMREMGenerator(this.renderer);
    this.interiorEnvironment = prefilter.fromScene(environment, 0.04, 0.1, 60, { size: 64 });
    environment.dispose();
    prefilter.dispose();
  }

  public setPerspective(firstPerson: boolean) {
    this.player.setPerspective(firstPerson, this.camera);
  }
  public setEffects(enabled: boolean) {
    this.atmosphere.enabled = enabled;
    this.atmosphere.group.visible = enabled;
  }
  public setPaused(paused: boolean) {
    this.paused = paused;
    if (paused) this.aftermath?.stop();
    worldAudio.setPaused(paused);
    this.clearInput();
    this.lastTime = performance.now();
  }
  private clearInput = () => {
    this.keys.clear();
    this.touchMove.x = 0;
    this.touchMove.y = 0;
    this.touchSprint = false;
    this.jumpQueued = false;
  };
  public interact() {
    const { x, y, z } = this.player.position;
    if (this.interior.useLift(x, y, z)) return;
    const local = this.nearTerminal(x, y, z);
    if (local?.id === 'machine') {
      this.machineTest = !this.machineTest;
      worldAudio.setMachine(this.machineTest);
      this.atmosphere.setMachineRunning(this.machineTest);
      worldAudio.cue(this.machineTest ? 'machine-on' : 'machine-off', 85, -10, -81);
      return;
    }
    if (local) {
      worldAudio.cue('terminal', x, y + 1.2, z);
      this.onTerminal(local.id === 'school-terminal' ? 'school' : 'bunker');
      return;
    }
    if (this.hatch.isNearControl(x, y, z)) this.hatch.toggle();
  }
  private nearTerminal(x: number, y: number, z: number) {
    if (y > -8) return null;
    if (Math.hypot(x - 10.5, z + 41.3) < 3.7)
      return { id: 'school-terminal', label: 'Open academy directory', sublabel: 'School reception' };
    if (Math.hypot(x - 5.1, z - 42.5) < 2.9)
      return {
        id: 'directory',
        label: 'Open facility directory',
        sublabel: 'Concourse information terminal',
      };
    if (Math.hypot(x - 71, z + 86) < 2.8)
      return {
        id: 'machine',
        label: this.machineTest ? 'Finish generator test' : 'Run generator test',
        sublabel: 'Local generator control',
      };
    return null;
  }

  public setTouchMove(x: number, y: number) {
    this.touchMove.x = x;
    this.touchMove.y = y;
  }

  public setTouchSprint(sprint: boolean) {
    this.touchSprint = sprint;
  }

  public requestJump() {
    this.jumpQueued = true;
  }

  public addLookDelta(dx: number, dy: number) {
    this.player.addLookDelta(dx, dy);
  }

  public toggleHatch() {
    this.hatch.toggle();
  }

  public toggleFlashlight() {
    this.player.setFlashlight(!this.player.flashlightOn);
    worldAudio.cue('switch');
  }

  public cycleCameraZoom() {
    if (this.player.cameraDistance < 5.0) this.player.cameraDistance = 6.2;
    else if (this.player.cameraDistance < 7.5) this.player.cameraDistance = 9.0;
    else this.player.cameraDistance = 4.2;
  }

  public fastTravel(point: FastTravelPoint) {
    this.clearInput();
    if (point.group !== 'Surface City') this.aftermath?.stop();
    worldAudio.resetTravel();
    worldAudio.setZone(point.group === 'Surface City' ? 'surface' : point.id);
    this.player.teleport(point.x, point.y, point.z, point.yaw, this.camera);
  }

  private handleResize() {
    const w = this.container.clientWidth;
    const h = Math.max(1, this.container.clientHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  private onKeyDown = (e: KeyboardEvent) => {
    if (
      this.paused ||
      (e.target instanceof HTMLElement && ['INPUT', 'SELECT', 'TEXTAREA'].includes(e.target.tagName))
    )
      return;
    const code = e.code;
    this.keys.add(code);
    if (code === 'Space') {
      e.preventDefault();
      this.jumpQueued = true;
    } else if (code === 'KeyE' && !e.repeat) {
      this.interact();
    } else if (code === 'KeyF' && !e.repeat) {
      this.toggleFlashlight();
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private resolveCurrentZone(): ZoneDefinition {
    const { x, y, z } = this.player.position;
    for (let i = 0; i < this.zones.length; i++) {
      const zn = this.zones[i];
      if (x >= zn.minX && x <= zn.maxX && z >= zn.minZ && z <= zn.maxZ && y >= zn.minY && y <= zn.maxY) {
        return zn;
      }
    }
    return y < -3.0
      ? {
          id: 'bunker_corridor',
          name: 'Subterranean Utility Corridor',
          subtitle: 'Interconnected Bunker Network',
          environment: 'bunker',
          minX: -110,
          maxX: 110,
          minZ: -110,
          maxZ: 110,
          minY: -15,
          maxY: -2,
          color: '#94a3b8',
        }
      : {
          id: 'city_streets',
          name: 'Metropolitan Avenue',
          subtitle: 'Aboveground Urban Grid',
          environment: 'surface',
          minX: -200,
          maxX: 200,
          minZ: -200,
          maxZ: 200,
          minY: -2,
          maxY: 200,
          color: '#64748b',
        };
  }

  private loop = (now: number) => {
    this.animId = requestAnimationFrame(this.loop);
    const rawDt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    if (this.paused || document.hidden) return;
    const dt = Math.min(rawDt, 0.1);
    this.elapsed += dt;

    // Combine keyboard + mobile touch joystick seamlessly
    let kbX = 0;
    let kbY = 0;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) kbX -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) kbX += 1;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) kbY += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) kbY -= 1;

    const input: PlayerInputState = {
      moveX: Math.abs(this.touchMove.x) > 0.05 ? this.touchMove.x : kbX,
      moveY: Math.abs(this.touchMove.y) > 0.05 ? this.touchMove.y : kbY,
      sprint: this.touchSprint || this.keys.has('ShiftLeft') || this.keys.has('ShiftRight'),
      jumpRequested: this.jumpQueued,
    };
    this.jumpQueued = false;

    this.hatch.update(dt, this.elapsed);
    const hatchState = this.hatch.getState();
    if (hatchState !== this.lastHatchState) {
      if (hatchState === 'opening' || hatchState === 'closing')
        worldAudio.cue(hatchState === 'opening' ? 'hatch-open' : 'hatch-close', 0, 0.1, 0);
      this.lastHatchState = hatchState;
    }
    if (this.keys.has('KeyQ')) this.player.addLookDelta(-dt * 1.55, 0);
    if (this.keys.has('KeyR')) this.player.addLookDelta(dt * 1.55, 0);
    if (this.player.position.y < -1.5)
      this.interior.update(
        dt,
        this.player.position.x,
        this.player.position.z,
        this.player.position.y,
        this.quality === 'mobile',
      );
    const substeps = Math.max(1, Math.ceil(dt * 60));
    for (let i = 0; i < substeps; i++) {
      this.player.update(dt / substeps, input, this.camera);
      input.jumpRequested = false;
    }

    const py = this.player.position.y;
    const px = this.player.position.x;
    const pz = this.player.position.z;
    const isUnderground = py < -3.2;
    const currentZone = this.resolveCurrentZone();

    // Dynamic Environment & Lighting Adaptation + Sector Culling for High Mobile FPS
    if (isUnderground) {
      this.aftermath?.stop();
      this.aftermath?.setVisible(false);
      // Only show aboveground city if near the central shaft looking up through open hatch
      const nearShaft = Math.abs(px) < 9 && pz > -10 && pz < 28 && py > -10 && this.hatch.getProgress() > 0.1;
      this.cityGroup.visible = nearShaft;
      this.sky.visible = nearShaft;
      (this.scene.background as THREE.Color).setHex(nearShaft ? 0x162233 : 0x434a42);
      this.bunkerGroup.visible = true;
      this.fog.color.setHex(0x62685f);
      this.fog.density = 0.005;
      this.hemiLight.color.setHex(0xe0e5de);
      this.hemiLight.groundColor.setHex(0x9ba698);
      this.hemiLight.intensity = this.quality === 'mobile' ? 1.8 : 0.82;
      this.sunLight.intensity = nearShaft ? 0.65 : 0.0;
      this.sunLight.castShadow = false;
      this.bunkerAmbient.intensity = this.quality === 'mobile' ? 0.9 : 0.21;
      this.renderer.toneMappingExposure = this.quality === 'mobile' ? 1.2 : 0.98;
      this.scene.environment = this.quality === 'mobile' ? null : this.interiorEnvironment?.texture || null;
      this.scene.environmentIntensity = 0.44;
      this.localKey.visible = this.practical.visible = true;
      const zone = currentZone.id;
      const cx = Math.round(px / 12) * 12,
        cz = Math.round(pz / 12) * 12;
      const key = `${zone}:${cx},${cz}:${this.quality}`;
      if (this.shadowCell !== key) {
        this.shadowCell = key;
        this.renderer.shadowMap.enabled = this.quality !== 'mobile';
        this.renderer.shadowMap.needsUpdate = true;
        const ceiling = zone === 'concourse' ? 9.9 : zone === 'habitat' ? 7.8 : 5.9;
        this.localKey.position.set(cx - 9, -12 + ceiling, cz - 7.5);
        this.localKey.target.position.set(cx + 4, -12, cz + 5);
      }
      this.practical.position.set(cx + 2, -6.9, cz + 1.5);
      this.practical.intensity =
        (zone === 'education' ? 72 : 48) *
        (this.atmosphere.enabled ? 1 + 0.021 * Math.sin(this.elapsed * 0.39 + px * 0.007) : 1);
      this.practical.color.setHex(
        zone === 'medical'
          ? 0xe7f5ef
          : zone === 'command'
            ? 0xc8dfea
            : zone === 'education' || zone === 'cafeteria' || zone === 'habitat'
              ? 0xffd5a1
              : 0xffecd4,
      );

      if (!this.autoFlashlightApplied) {
        this.autoFlashlightApplied = true;
        this.player.setFlashlight(false);
      }
    } else {
      if (!this.aftermath) {
        this.aftermath = createAftermath(this.cityGroup, this.cityDetail, this.collision);
        const skyMaterial = this.sky.material as THREE.MeshBasicMaterial;
        skyMaterial.map = this.aftermath.sky;
        skyMaterial.needsUpdate = true;
      }
      this.aftermath.setVisible(true);
      this.sky.visible = true;
      this.sky.position.set(px, 0, pz);
      (this.scene.background as THREE.Color).setHex(0xb2b9b7);
      if (
        this.quality !== 'mobile' &&
        !this.surfaceReflection &&
        (this.aftermath.reflection.image as HTMLImageElement | undefined)?.width
      ) {
        const gen = new THREE.PMREMGenerator(this.renderer);
        this.surfaceReflection = gen.fromEquirectangular(this.aftermath.reflection);
        gen.dispose();
      }
      this.scene.environment = this.quality === 'mobile' ? null : this.surfaceReflection?.texture || null;
      this.scene.environmentIntensity = 0.57;
      this.practical.visible = this.localKey.visible = false;
      this.renderer.shadowMap.enabled = this.quality !== 'mobile';
      this.sunLight.castShadow = this.quality !== 'mobile';
      this.renderer.toneMappingExposure = 1.04;
      const gx = Math.round(px / 16) * 16,
        gz = Math.round(pz / 16) * 16,
        shadowTile = `surface:${gx}:${gz}:${this.quality}`;
      this.surfaceShadowTimer += dt;
      if (
        this.shadowCell !== shadowTile ||
        (this.surfaceShadowTimer > 0.34 && this.player.isMoving && this.quality === 'high')
      ) {
        this.shadowCell = shadowTile;
        this.surfaceShadowTimer = 0;
        this.sunLight.position.set(gx - 67, 96, gz - 39);
        this.sunLight.target.position.set(gx + 12, 0, gz + 18);
        this.renderer.shadowMap.needsUpdate = true;
      }
      this.cityGroup.visible = true;
      // Only render bunker interior from surface when close to an open central hatch
      const nearOpenHatch = Math.hypot(px, pz) < 42 && this.hatch.getProgress() > 0.05;
      this.bunkerGroup.visible = nearOpenHatch;
      this.fog.color.setHex(0xb5bcb9);
      this.fog.density = this.atmosphere.enabled ? 0.005 + Math.sin(this.elapsed * 0.032) * 0.00024 : 0.0022;
      this.hemiLight.intensity = 1.76;
      this.hemiLight.color.setHex(0xe1e7e5);
      this.hemiLight.groundColor.setHex(0x81867c);
      this.sunLight.color.setHex(0xf5eedf);
      this.sunLight.intensity = 1.37;
      this.bunkerAmbient.intensity = 0.37;
      this.cityDetail.update(px, pz, this.quality);
      this.aftermath.update(dt, this.player.position, this.player.yaw, this.quality, this.atmosphere.enabled);
      this.autoFlashlightApplied = false;
    }

    this.resolutionTimer += rawDt;
    if (this.resolutionTimer > 3) {
      this.resolutionTimer = 0;
      if (this.quality === 'mobile' && this.currentFps < 26 && this.renderer.getPixelRatio() > 0.63)
        this.renderer.setPixelRatio(Math.max(0.62, this.renderer.getPixelRatio() - 0.1));
    }
    this.atmosphere.update(dt, this.player.position, this.camera, isUnderground, currentZone.id);
    worldAudio.update(
      dt,
      this.player.position,
      this.player.yaw,
      this.player.isSprinting,
      Math.abs(py - this.collision.getFloorHeight(px, pz, py, 0.3)) < 0.09,
      currentZone.id,
    );
    this.renderer.render(this.scene, this.camera);

    // FPS & Telemetry Update (~10 Hz to avoid React re-render overhead!)
    this.fpsAccum += rawDt;
    this.fpsFrames++;
    this.hudTimer += rawDt;

    if (this.fpsAccum >= 0.5) {
      this.currentFps = Math.round(this.fpsFrames / this.fpsAccum);
      this.fpsAccum = 0;
      this.fpsFrames = 0;
    }

    if (this.hudTimer >= 0.12) {
      this.hudTimer = 0;
      const nearHatch = this.hatch.isNearControl(px, py, pz);
      const liftPrompt = this.interior.liftPrompt(px, py, pz);
      const hState = this.hatch.getState();
      const yawDeg = ((Math.round((-this.player.yaw * 180) / Math.PI) % 360) + 360) % 360;

      this.onTelemetry({
        fps: this.currentFps,
        drawCalls: this.renderer.info.render.calls,
        triangles: this.renderer.info.render.triangles,
        position: { x: px, y: py, z: pz },
        yawDeg,
        currentZone,
        room:
          currentZone.id === 'education'
            ? SCHOOL_ROOMS.find((r) => px > r.x1 && px < r.x2 && pz > r.z1 && pz < r.z2)?.name ||
              (pz > -49 ? 'Reception' : 'Academic walk')
            : undefined,
        hatchState: hState,
        hatchProgress: this.hatch.getProgress(),
        nearPrompt: liftPrompt
          ? { id: 'lift', label: liftPrompt, sublabel: 'Passenger lift / Gallery 01' }
          : this.nearTerminal(px, py, pz) ||
            (nearHatch
              ? {
                  id: 'hatch_toggle',
                  label:
                    hState === 'open' || hState === 'opening'
                      ? 'CLOSE CENTRAL BUNKER HATCH'
                      : 'OPEN CENTRAL BUNKER HATCH',
                  sublabel: 'Hydraulic Blast Access Door (Tap or Press E)',
                }
              : null),
        flashlightOn: this.player.flashlightOn,
        isUnderground,
        isMoving: this.player.isMoving,
        isSprinting: this.player.isSprinting,
      });
    }
  };

  public dispose() {
    cancelAnimationFrame(this.animId);
    this.resizeObserver.disconnect();
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.clearInput);
    const geometries = new Set<THREE.BufferGeometry>();
    const materials = new Set<THREE.Material>();
    const textures = new Set<THREE.Texture>();
    this.scene.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        geometries.add(obj.geometry);
        (Array.isArray(obj.material) ? obj.material : [obj.material]).forEach((m) => materials.add(m));
        if (obj instanceof THREE.InstancedMesh) obj.dispose();
      }
    });
    geometries.forEach((g) => g.dispose());
    materials.forEach((m) => {
      Object.values(m).forEach((v) => {
        if (v instanceof THREE.Texture) textures.add(v);
      });
      m.dispose();
    });
    textures.forEach((t) => t.dispose());
    this.interiorEnvironment?.dispose();
    this.atmosphere.dispose();
    this.surfaceReflection?.dispose();
    this.cityDetail.dispose();
    this.aftermath?.dispose();
    worldAudio.resetTravel();
    worldAudio.setPaused(false);
    worldAudio.setZone('surface');
    this.interior.dispose();
    this.renderer.dispose();
    this.renderer.forceContextLoss();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
