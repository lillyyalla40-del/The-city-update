import * as T from 'three';
import { FacilityKit as K } from './facilityKit';
import {
  bed,
  bench,
  cabinet,
  chair,
  dispenser,
  kiosk,
  lightBar,
  monitor,
  planter,
  safety,
  shelf,
  table,
} from './furnishings';
import { railing, room } from './architecture';
const pi = Math.PI;

function sink(k: K, x: number, z: number, wide = false) {
  k.at(x, 0, z, 0, () => {
    const w = wide ? 2.55 : 1.22;
    cabinet(k, 0, 0, w, 0.89, 0.72, '#a3afa2');
    k.box(0, 0.93, 0, w + 0.03, 0.04, 0.77, 'steel', '#c0c7b9', true);
    for (const xx of wide ? [-0.64, 0.64] : [0]) {
      k.oval(xx, 0.96, 0, 0.41, 0.035, 0.265, 'steel', '#626f65');
      k.rod([xx, 1, -0.27], [xx, 1.25, -0.27], 0.025);
      k.rod([xx, 1.25, -0.27], [xx, 1.25, -0.04], 0.025);
    }
  });
}
function screenWall(k: K, x: number, y: number, z: number, w: number, h: number, style: number, yaw = 0) {
  k.at(x, y, z, yaw, () => {
    k.box(0, 0, 0, w + 0.09, h + 0.09, 0.12, 'graphite', '#282f2d', true);
    k.box(0, 0, 0.065, w, h, 0.012, 'screen' + style, '#ffffff');
    k.box(0, 0, -0.16, w * 0.38, h * 0.42, 0.24, 'steel', '#687269');
  });
}
function workDesk(k: K, x: number, z: number, w = 2.35, angle = 0, screen = 0) {
  k.at(x, 0, z, angle, () => {
    table(k, 0, 0, w, 0.94, 'wood');
    monitor(k, -0.22, 0.87, -0.1, screen);
    cabinet(k, w * 0.31, 0.03, 0.56, 0.68, 0.66, '#9caa98', 0, 3);
    chair(k, -0.18, 0.95, pi, 'office', '#64726b');
  });
}
function curtain(k: K, x: number, z: number, len = 2.9) {
  k.at(x, 0, z, 0, () => {
    k.rod([0, 2.63, -len / 2], [0, 2.63, len / 2], 0.022);
    for (const s of [-1, 1]) k.rod([0, 2.63, s * len * 0.4], [0, 6.45, s * len * 0.4], 0.011);
    for (let j = 0; j < 12; j++) {
      const zz = -len / 2 + (j * len) / 22;
      k.box(
        Math.sin(j) * 0.055,
        1.58,
        zz,
        0.042,
        1.93,
        len / 21 + 0.02,
        'fabric',
        j % 2 ? '#b2c9bb' : '#a4baad',
        false,
        [0, Math.sin(j) * 0.17, 0],
      );
      k.cyl(0, 2.58, zz, 0.013, 0.105, 'steel', '#89988a');
    }
  });
}

export function medical(k: K) {
  const teal = '#83b3a6';
  const xs = [-89, -64, -38];
  const zs = [-10, 17, 50];
  const names = [
    ['Emergency treatment', 'Medical laboratory', 'Pharmacy'],
    ['Operating theatre', 'Examination suite', 'Consultation'],
    ['Recovery ward', 'Patient ward', 'Medical reception'],
  ];
  for (let j = 0; j < 3; j++)
    for (let i = 0; i < 3; i++) room(k, xs[i], zs[j], 20.6, j === 2 ? 20 : 21, names[j][i], teal, true);
  for (const [x, z] of [
    [-89, -10],
    [-89, 50],
    [-64, 50],
  ]) {
    for (const dx of [-5.8, 0, 5.8])
      for (const dz of [-3.7, 3.6]) {
        bed(k, x + dx, z + dz);
        curtain(k, x + dx - 1.3, z + dz);
        k.box(x + dx, 1.42, z + dz - 1.49, 2.3, 0.17, 0.12, 'steel', '#b4c1b2');
        k.box(x + dx, 1.61, z + dz - 1.49, 1.13, 0.05, 0.14, 'light', '#f0f3dd');
        for (const sx of [-0.66, -0.46, -0.26])
          k.cyl(x + dx + sx, 1.42, z + dz - 1.41, 0.034, 0.032, 'paint', '#749b91', [pi / 2, 0, 0]);
      }
    screenWall(k, x, 2.2, z - 10.31, 2.95, 1.07, 1);
    cabinet(k, x - 7.7, z - 8.2, 2.8, 1.02, 0.66, '#9cb6a4');
  }
  k.at(-89, 0, 17, 0, () => {
    bed(k, 0, 0, true);
    for (const s of [-1, 1]) {
      k.cyl(s * 1.6, 3.29, 0, 0.45, 0.13, 'steel', '#bcc6b9');
      for (let j = 0; j < 7; j++) {
        const a = (j * pi * 2) / 7;
        k.oval(
          s * 1.6 + Math.cos(a) * 0.24,
          3.211,
          Math.sin(a) * 0.24,
          0.099,
          0.029,
          0.099,
          'light',
          '#f1f6e6',
        );
      }
      k.rod([s * 1.6, 3.36, 0], [s * 0.6, 3.9, -1.3], 0.064);
      k.rod([s * 0.6, 3.9, -1.3], [s * 0.6, 6.45, -1.3], 0.072);
      table(k, s * 3, 0, 1.25, 0.67, 'steel');
    }
    cabinet(k, -5, -7.9, 4.1, 1.9, 0.7, '#a8b5a8', 0, 4);
    sink(k, 5, -7.8, true);
    screenWall(k, 0, 2.2, -10.39, 3.9, 1.4, 1);
  });
  for (const x of [-69, -60]) {
    bed(k, x, 17, true);
    cabinet(k, x, 9.7, 2.11, 1.06, 0.65, '#a7bba9');
  }
  sink(k, -57.6, 9.6);
  workDesk(k, -64, 22, 2.1, pi, 1);
  for (const z of [12, 21]) {
    workDesk(k, -41, z, 2.6, 0.4, 1);
    chair(k, -37, z + 1, pi, 'lounge', '#91a99b');
  }
  sink(k, -34, 9.4);
  cabinet(k, -31.5, 16, 2.3, 1.8, 0.67, '#a6baab', -pi / 2);
  for (const z of [-15, -7]) {
    table(k, -64, z, 9.3, 1.5, 'steel');
    for (const dx of [-3, -1, 0.9, 3]) {
      k.cyl(-64 + dx, 1.035, z, 0.084, 0.32, 'glass', '#bfdbce');
      k.cyl(-64 + dx, 1.2, z, 0.075, 0.03, 'paint', '#88a599');
    }
    monitor(k, -66.6, 0.87, z, 1);
  }
  sink(k, -71, -17, true);
  shelf(k, -58, -17, 3.8, 0.75, 'medical');
  for (const dx of [-6, 0, 6])
    for (const dz of [-4, 4]) shelf(k, -38 + dx, -10 + dz, 3.7, 0.8, 'medical', pi / 2);
  k.at(-38, 0, 49, 0, () => {
    cabinet(k, 0, 0, 6.7, 1.09, 1.1, '#a9bfae');
    monitor(k, -1.5, 1.15, 0, 1);
    monitor(k, 1.5, 1.15, 0);
    k.label(0, 0.68, 0.575, 2.8, 0.47, 'RECEPTION', 'MEDICAL SERVICES', teal);
    for (const xx of [-5.8, -3.8, 3.8, 5.8]) chair(k, xx, 4.7, pi, 'lounge', '#91a99d');
    dispenser(k, 7, 5.3);
    planter(k, -7, 4.9, 0.75);
  });
  for (const z of [1.9, 33.2, 63.8]) {
    bench(k, -77, z, 0, 3.8);
    safety(k, -102.7, z, pi / 2);
  }
  k.label(-91, 2.4, -23.65, 10.5, 1.3, '02  /  MEDICAL', 'CLINICAL SERVICES  +  RECOVERY', teal);
  for (const dx of [-5, 0, 5]) {
    cabinet(k, -88 + dx, 63, 2.8, 1.95, 1.0, '#a7baaa', pi);
    k.label(
      -88 + dx,
      1.4,
      62.475,
      2.2,
      0.41,
      dx < 0 ? 'Clean linen' : dx === 0 ? 'Medical supplies' : 'Clean utility',
      'WARD SERVICES',
      teal,
      pi,
    );
  }
}

function motorhome(k: K, x: number, z: number, variant: number) {
  const l = [9.8, 8.5, 10.7, 7.8][variant],
    w = [2.55, 2.42, 2.6, 2.38][variant],
    h = [2.51, 2.44, 2.72, 2.3][variant],
    paint = ['#d8d4bf', '#b4bbaa', '#c9d0c7', '#d3c4a7'][variant],
    stripe = ['#b47850', '#6d8275', '#708b94', '#9b7e59'][variant];
  k.at(x, 0, z, variant % 2 ? pi : 0, () => {
    const shape = new T.Shape();
    shape.moveTo(-l / 2 + 0.18, 0.61);
    shape.lineTo(l / 2 - 0.23, 0.61);
    shape.quadraticCurveTo(l / 2 + 0.04, 0.77, l / 2, 1.15);
    shape.lineTo(l / 2 - 0.13, 1.63);
    shape.lineTo(l / 2 - 0.85, h + 0.48);
    shape.quadraticCurveTo(l / 2 - 0.99, h + 0.66, l / 2 - 1.34, h + 0.67);
    shape.lineTo(-l / 2 + 0.39, h + 0.67);
    shape.quadraticCurveTo(-l / 2, h + 0.66, -l / 2, h + 0.21);
    shape.lineTo(-l / 2, 0.94);
    shape.quadraticCurveTo(-l / 2, 0.68, -l / 2 + 0.18, 0.61);
    const geo = new T.ExtrudeGeometry(shape, {
      depth: w - 0.15,
      bevelEnabled: true,
      bevelSize: 0.075,
      bevelThickness: 0.075,
      bevelSegments: 2,
      steps: 1,
      curveSegments: 5,
    });
    geo.translate(0, 0, -(w - 0.15) / 2);
    k.emit(geo, 'paint', 0, 0, 0, 1, 1, 1, paint);
    k.box(0, 0.57, 0, l * 0.89, 0.26, w * 0.84, 'graphite', '#363e35', true);
    k.shadow(0, 0, l * 1.15, w * 1.85);
    for (const f of [-1, 1]) {
      const bz = f * (w / 2 + 0.01);
      k.box(-0.25, 1.22, bz, l - 0.66, 0.25, 0.026, 'paint', stripe, true);
      k.box(-0.25, 1.04, bz, l - 0.7, 0.047, 0.027, 'steel', '#aaad99');
      for (let j = 0; j < 4; j++) {
        const xx = -l / 2 + 1.25 + (j * (l - 3.2)) / 4;
        if (j === 2 && f === 1) continue;
        k.box(xx, 2.18, bz, 1.49, 0.83, 0.06, 'rubber', '#343b32', true);
        k.box(xx, 2.18, bz + f * 0.033, 1.36, 0.7, 0.018, 'glazing', '#d4ded7', true);
        k.box(xx - 0.17, 2.18, bz + f * 0.05, 0.032, 0.72, 0.022, 'steel', '#7f8a7d');
      }
      for (const ax of [-l * 0.31, l * 0.31]) {
        k.cyl(ax, 0.56, bz, 0.55, 0.24, 'rubber', '#272d28', [pi / 2, 0, 0]);
        k.cyl(ax, 0.56, bz + f * 0.124, 0.32, 0.032, 'steel', '#a6afa0', [pi / 2, 0, 0]);
        k.cyl(ax, 0.56, bz + f * 0.147, 0.16, 0.037, 'graphite', '#748071', [pi / 2, 0, 0]);
        for (let j = 0; j < 6; j++) {
          const a = (j * pi) / 3;
          k.cyl(
            ax + Math.cos(a) * 0.23,
            0.56 + Math.sin(a) * 0.23,
            bz + f * 0.154,
            0.032,
            0.027,
            'steel',
            '#c6cbbb',
            [pi / 2, 0, 0],
          );
        }
      }
      k.rod([l * 0.36, 2.06, bz], [l * 0.38, 2.13, bz + f * 0.29], 0.027);
      k.box(l * 0.38, 2.19, bz + f * 0.32, 0.16, 0.28, 0.09, 'graphite', '#485346', true);
      k.box(-l * 0.31, 1.44, bz + 0.026 * f, 0.72, 0.25, 0.024, 'vent', '#808977');
    }
    const rake = Math.atan(0.72 / (h - 1.15)),
      wy = (h + 0.33 + 1.69) / 2,
      wx = l / 2 - 0.13 - (wy - 1.63) * Math.tan(rake) + 0.12,
      wh = (h + 0.33 - 1.69) / Math.cos(rake);
    k.box(wx, wy, 0, 0.064, wh + 0.08, w * 0.91, 'rubber', '#30382e', true, [0, 0, rake]);
    k.box(wx + 0.042, wy, 0, 0.036, wh, w * 0.86, 'glazing', '#c4d4c9', true, [0, 0, rake]);
    k.box(wx + 0.07, wy, 0, 0.038, wh, 0.032, 'steel', '#78867c', false, [0, 0, rake]);
    k.box(l / 2 - 0.1, 1.55, 0, 0.13, 0.1, w * 0.89, 'paint', stripe, true);
    for (const s of [-1, 1])
      k.rod([l / 2 + 0.012, 1.67, s * 0.24], [l / 2 - 0.12, 1.92, s * 0.79], 0.018, 'rubber', '#353f37');
    k.box(-l / 2 - 0.089, 2.07, 0, 0.05, 0.78, w * 0.65, 'rubber', '#363e33', true);
    k.box(-l / 2 - 0.12, 2.07, 0, 0.019, 0.68, w * 0.6, 'glazing', '#d4ddd0', true);
    for (const a of [0.73, 1.1]) k.rod([-l / 2 - 0.14, 0.59, a], [-l / 2 - 0.14, h + 0.72, a], 0.024);
    for (let y = 0.82; y < h + 0.64; y += 0.29)
      k.rod([-l / 2 - 0.14, y, 0.73], [-l / 2 - 0.14, y, 1.1], 0.022);
    if (variant === 3) {
      k.box(l / 2 - 0.55, h + 0.45, 0, 1.79, 0.65, w + 0.06, 'paint', paint, true);
      k.box(l / 2 + 0.047, h + 0.44, w * 0.505, 0.61, 0.31, 0.035, 'glazing', '#cad9cd', true);
    }
    if (variant === 2) {
      for (const s of [-1, 1]) {
        k.cyl(-l * 0.31 + 1.18, 0.56, s * (w / 2 + 0.016), 0.55, 0.24, 'rubber', '#2b322b', [pi / 2, 0, 0]);
        k.cyl(-l * 0.31 + 1.18, 0.56, s * (w / 2 + 0.15), 0.31, 0.028, 'steel', '#a4b29e', [pi / 2, 0, 0]);
      }
    }
    k.box(l / 2 - 0.015, 1.06, 0, 0.09, 0.3, w * 0.56, 'vent', '#5d6759', true);
    for (const f of [-1, 1]) {
      k.box(l / 2 - 0.02, 1.23, f * w * 0.368, 0.13, 0.21, 0.4, 'light', '#e6ddbe', true);
      k.box(-l / 2 - 0.04, 1.02, f * w * 0.366, 0.09, 0.31, 0.24, 'paint', '#a0523d', true);
    }
    k.box(l / 2 - 0.03, 0.71, 0, 0.2, 0.17, w * 0.94, 'steel', '#8e9686', true);
    k.box(0, 1.73, w / 2 + 0.036, 0.84, 1.98, 0.046, 'rubber', '#687261', true);
    k.box(0, 1.73, w / 2 + 0.066, 0.77, 1.9, 0.03, 'paint', paint, true);
    k.box(0, 2.19, w / 2 + 0.087, 0.59, 0.61, 0.02, 'graphite', '#526965', true);
    k.box(0.24, 1.55, w / 2 + 0.115, 0.15, 0.045, 0.052, 'steel', '#727f71');
    k.box(0, 0.43, w / 2 + 0.22, 0.87, 0.09, 0.49, 'vent', '#7d8777');
    for (const dx of [-1.9, 1.1]) {
      k.box(dx, h + 0.82, 0, 1.07, 0.32, 0.92, 'paint', '#c7cabb', true);
      k.box(dx, h + 0.987, 0, 0.79, 0.021, 0.69, 'vent', '#7b8475');
    }
    if (variant === 0 || variant === 3) {
      k.box(
        -1.2,
        h + 0.38,
        w / 2 + 0.75,
        4.2,
        0.065,
        1.59,
        'fabric',
        variant === 0 ? '#ba9869' : '#8e9a7d',
        false,
        [0.19, 0, 0],
      );
      for (const dx of [-3.12, 0.69]) k.rod([dx, 0.01, w / 2 + 1.47], [dx, h + 0.22, w / 2 + 1.47], 0.022);
    }
    if (variant === 2)
      for (const dx of [-2.9, -1.5])
        k.box(dx, h + 0.714, -0.48, 1.24, 0.068, 0.86, 'graphite', '#576d70', true);
    k.solid(0, 1.73, 0, l, 3.45, w + 0.07);
    k.label(
      -l * 0.27,
      1.6,
      w / 2 + 0.067,
      1.78,
      0.22,
      ['MERIDIAN  /  TOURING', 'NORTHLINE  /  04', 'ATLAS  /  GRAND TOUR', 'CALDER  /  CLASSIC'][variant],
      '',
      stripe,
    );
  });
}
export function habitat(k: K) {
  const cars = [
    [45, -2],
    [81, -2],
    [45, 32],
    [81, 32],
  ];
  cars.forEach(([x, z], i) => {
    motorhome(k, x, z, i);
    for (const f of [-1, 1]) {
      k.box(x, 0.006, z + f * 4.2, 15, 0.009, 0.11, 'paint', '#c7b387');
      k.box(x + f * 7.5, 0.006, z, 0.11, 0.009, 8.5, 'paint', '#c7b387');
    }
    k.label(
      x,
      0.021,
      z + 6.4,
      5.6,
      1.1,
      'BAY 0' + (i + 1),
      'RESIDENTIAL  /  RV SETTLEMENT',
      '#ddbc83',
      0,
      true,
    );
    k.at(x - 7, 0, z - 3.2, 0, () => {
      cabinet(k, 0, 0, 0.89, 1.17, 0.45, '#a4ac95');
      k.label(0, 0.89, 0.25, 0.65, 0.2, 'UTILITY 0' + (i + 1), '240V / WATER', '#cead73');
      for (const f of [-1, 1])
        k.cyl(f * 0.19, 0.52, 0.268, 0.065, 0.097, 'paint', f < 0 ? '#699a9a' : '#ab996b', [pi / 2, 0, 0]);
    });
    k.rod([x - 7, 0.53, z - 2.95], [x - 6.65, 0.045, z - 1.8], 0.028, 'rubber', '#3e483c');
    k.rod([x - 6.65, 0.045, z - 1.8], [x - 3, 0.045, z - 1.4], 0.028, 'rubber', '#3e483c');
    k.rod([x - 3, 0.045, z - 1.4], [x - 3, 0.86, z - 1.25], 0.028, 'rubber', '#3e483c');
    bench(k, x - 1, z + 3.6, pi, 2.4);
    lightBar(k, x, 6.64, z, 9.6, pi / 2, true);
    k.pool(x, z, 17, 14);
  });
  k.label(
    63,
    4.28,
    -23.51,
    16,
    2.1,
    '04  /  RV SETTLEMENT',
    'RESIDENTIAL HALL  +  COMMUNITY LOUNGE',
    '#cdad78',
  );
  for (const x of [46, 62, 78]) {
    table(k, x, 53, 3.3, 1.48);
    for (const dx of [-0.89, 0.89])
      for (const s of [-1, 1]) chair(k, x + dx, 53 + s * 1.22, s > 0 ? pi : 0, 'lounge', '#96977c');
    planter(k, x + 5, 54, 0.9);
  }
  dispenser(k, 35, 54);
  cabinet(k, 87, 58, 3.25, 1.12, 0.8, '#a5ac94', pi);
  k.label(
    89,
    2.6,
    64.95,
    7.8,
    1.23,
    'COMMUNITY BOARD',
    'QUIET HOURS 22:00 - 07:00  /  KEEP AISLES CLEAR',
    '#d1b686',
    pi,
  );
  safety(k, 103.52, 24, -pi / 2);
}

export function command(k: K) {
  const col = '#8caab4';
  k.box(0, 0.2, 84, 24, 0.4, 19, 'graphite', '#64716b');
  k.walk(0, 84, 24, 19, 0.4);
  for (const z of [74.1, 93.9]) k.box(0, 0.23, z, 24, 0.08, 0.09, 'light', '#b7cfd0');
  k.at(0, 0.4, 0, 0, () => {
    k.cyl(0, 0.52, 82, 1.12, 1.04, 'graphite', '#53615a');
    k.box(0, 1.11, 82, 5.5, 0.22, 2.9, 'graphite', '#5c6962', true);
    k.box(0, 1.235, 82, 4.75, 0.035, 2.29, 'screen0', '#d2e6d9');
    k.shadow(0, 82, 6.9, 4.43);
    for (const s of [-1, 1])
      for (const z of [80.7, 87.9])
        k.at(s * 7.75, 0, z, -s * 0.22, () => {
          table(k, 0, 0, 4.1, 1.4, 'steel');
          monitor(k, -0.9, 0.87, -0.19, 2, 1.2);
          monitor(k, 0.78, 0.87, -0.19, 0, 1.19);
          chair(k, 0, 1.2, pi, 'office', '#5c6c69');
        });
  });
  k.solid(0, 0.94, 82, 5.5, 1.5, 2.9);
  for (let i = -2; i <= 2; i++) {
    const x = i * 4.62;
    screenWall(k, x, 3.15, 101.98, 4.46, 2.39, (i + 4) % 5, pi);
    screenWall(k, x, 1.16, 101.98, 4.46, 1.36, (i + 5) % 5, pi);
  }
  k.label(
    0,
    5.21,
    103.62,
    15.1,
    1.2,
    '05  /  OPERATIONS',
    'COMMAND AND CONTROL    /    FACILITY SYSTEMS',
    col,
    pi,
  );
  room(k, -18.3, 81.5, 8.9, 20.6, 'Communications', col, true);
  workDesk(k, -18.2, 77.1, 3.05, pi, 2);
  workDesk(k, -18.3, 83.2, 2.88, pi, 0);
  room(k, 18.4, 84.7, 8.6, 26, 'Technical operations', col, true);
  for (const z of [77, 79.3, 81.6, 83.9, 86.2, 88.5, 90.8]) {
    k.at(18.9, 0, z, -pi / 2, () => {
      k.box(0, 1.34, 0, 1.14, 2.68, 0.88, 'graphite', '#39463e', true);
      k.box(0, 1.35, 0.45, 1.02, 2.46, 0.031, 'vent', '#536357');
      for (let j = 0; j < 13; j++) {
        k.box(0, 0.29 + j * 0.169, 0.476, 0.88, 0.085, 0.023, 'graphite', '#6f7a6e');
        k.box(0.352, 0.29 + j * 0.169, 0.49, 0.045, 0.027, 0.02, 'light', j % 3 ? '#a6bf98' : '#c6b57c');
      }
      k.box(-0.47, 1.4, 0.48, 0.034, 0.33, 0.055, 'steel', '#a5afa1');
      k.solid(0, 1.34, 0, 1.2, 2.7, 0.96);
    });
  }
  room(k, -17.9, 97.9, 9.8, 9.4, 'Planning', col, true);
  table(k, -17.7, 97.2, 3.1, 1.41);
  for (const x of [-18.65, -16.66])
    for (const s of [-1, 1]) chair(k, x, 97.2 + s * 1.16, s > 0 ? pi : 0, 'office', '#75847b');
  cabinet(k, 17.9, 100.8, 5.1, 2.42, 0.9, '#7f8f82', pi);
  k.label(18, 1.74, 100.32, 3.46, 0.59, 'SECURE EQUIPMENT', 'ACCESS CONTROLLED', col, pi);
}

export function cafeteria(k: K) {
  for (const x of [-62, -48, -34])
    for (const z of [77, 89, 98]) {
      const l = x === -48 ? 5.5 : 3.85;
      table(k, x, z, l, 1.32);
      const n = x === -48 ? 3 : 2;
      for (let a = 0; a < n; a++)
        for (const s of [-1, 1])
          chair(
            k,
            x + (a - (n - 1) / 2) * 1.4,
            z + s * 1.2,
            s === 1 ? pi : 0,
            'dining',
            x === -48 ? '#ab8a64' : '#8b9378',
          );
      k.rod([x, 6.4, z], [x, 3.7, z], 0.018, 'graphite', '#586152');
      k.oval(x, 3.61, z, 0.52, 0.22, 0.52, 'steel', '#917e61');
      k.cyl(x, 3.48, z, 0.43, 0.032, 'light', '#ffe2b2');
      k.pool(x, z, 6.2, 5.3);
    }
  room(k, -86, 84.5, 31, 28.7, 'Production kitchen', '#c29a70', true);
  for (const z of [78.4, 88.5]) {
    table(k, -86, z, 8.4, 1.75, 'steel');
    k.box(-86, 2.9, z, 9.15, 0.51, 2.13, 'steel', '#acb4a6', true);
    k.box(-86, 2.63, z, 8.48, 0.035, 1.71, 'vent', '#717f70');
    k.box(-86, 4.8, z, 1.07, 3.38, 0.94, 'steel', '#8b9789');
    for (const xx of [-2.4, 0, 2.4]) {
      k.cyl(-86 + xx, 1.06, z, 0.28, 0.41, 'steel', '#aeb9a9');
      k.cyl(-86 + xx, 1.28, z, 0.29, 0.045, 'steel', '#b1bba9');
      k.box(-86 + xx, 1.323, z, 0.14, 0.065, 0.04, 'graphite', '#485843', true);
    }
  }
  for (const x of [-98, -94.7, -91.4]) {
    cabinet(k, x, 73.2, 2.66, 2.06, 0.84, '#acb8ac', 0, 2);
    k.box(x, 1.03, 73.65, 2.02, 0.66, 0.014, 'graphite', '#4e5d51', true);
    k.box(x, 1.57, 73.71, 1.99, 0.035, 0.07, 'steel', '#bbc3b4');
  }
  sink(k, -77, 73.5, true);
  shelf(k, -96, 92.9, 4.6, 0.81, 'supply');
  cabinet(k, -76.8, 91.4, 2.2, 2.3, 0.93, '#abb9a8');
  k.at(-68.2, 0, 82, pi / 2, () => {
    cabinet(k, 0, 0, 14.6, 1.11, 1.24, '#988873');
    for (const q of [-4.7, 0, 4.7]) {
      k.box(q, 1.43, 0, 3.8, 0.6, 0.91, 'glass', '#c3d9cc', true);
      k.box(q, 1.75, 0, 3.86, 0.055, 0.96, 'steel', '#bcc6b5');
      for (const v of [-1, 0, 1]) k.box(q + v, 1.18, 0, 0.71, 0.09, 0.65, 'steel', '#a8b49f', true);
    }
  });
  k.label(
    -48,
    3.55,
    103.64,
    12.9,
    1.59,
    '06  /  COMMUNAL DINING',
    'MESS HALL  /  WEST GALLERY',
    '#cc9d71',
    pi,
  );
  for (const x of [-54, -47, -40])
    k.label(
      x,
      1.94,
      103.63,
      5.8,
      0.95,
      'DAILY MENU',
      x < -50
        ? 'MORNING  /  06:00 - 09:00'
        : x < -45
          ? 'LUNCH  /  12:00 - 14:00'
          : 'EVENING  /  18:00 - 20:00',
      '#d2b28a',
      pi,
    );
  for (const x of [-100, -96, -92]) {
    cabinet(k, x, 100.8, 2.8, 2.33, 0.94, '#a6b3a2', pi);
    k.label(x, 1.66, 100.3, 2.28, 0.37, 'COLD STORE', '4 C  /  PROVISIONS', '#b5c3a7', pi);
  }
  dispenser(k, -31, 69.4);
  cabinet(k, -57, 69.25, 4.5, 1.09, 0.78, '#a6ad94');
  k.label(-57, 0.64, 69.66, 3, 0.39, 'TRAY RETURN', 'SORT  /  RINSE', '#cba57f');
  planter(k, -29, 92, 0.9);
  for (let i = 0; i < 3; i++) {
    k.box(-63 + i * 1.09, 0.47, 69.7, 0.77, 0.94, 0.63, 'paint', ['#748d7e', '#a8a387', '#858b7d'][i], true);
    k.box(-63 + i * 1.09, 0.95, 69.7, 0.55, 0.04, 0.39, 'rubber', '#3e4b3e', true);
  }
}

export function engineering(k: K) {
  for (const z of [-94, -81, -68]) {
    k.at(85, 0, z, 0, () => {
      k.box(0, 0.23, 0, 15, 0.46, 5.7, 'stone', '#828878', true);
      k.box(0, 0.56, 0, 13.9, 0.25, 4.74, 'graphite', '#505c4e', true);
      k.cyl(0, 2.18, 0, 1.64, 8.2, 'steel', '#7f8a7a', [0, 0, pi / 2]);
      for (const xx of [-4.3, -1.8, 1.7, 4.32]) {
        k.cyl(xx, 2.18, 0, 1.82, 0.43, 'paint', '#b49c63', [0, 0, pi / 2]);
        for (let j = 0; j < 12; j++) {
          const a = (j * pi) / 6;
          k.cyl(xx + 0.234, 2.18 + Math.cos(a) * 1.57, Math.sin(a) * 1.57, 0.072, 0.055, 'steel', '#596753', [
            0,
            0,
            pi / 2,
          ]);
        }
      }
      for (let xx = -3.6; xx < 3.8; xx += 0.42)
        k.cyl(xx, 2.18, 0, 1.71, 0.09, 'graphite', '#67735e', [0, 0, pi / 2]);
      k.box(-5.32, 1.73, 0, 2.01, 2.16, 2.83, 'paint', '#b59d65', true);
      k.box(-5.32, 1.79, 1.426, 1.63, 1.2, 0.06, 'vent', '#666e56');
      k.cyl(5.41, 1.91, 0, 1.15, 1.94, 'graphite', '#66755e', [0, 0, pi / 2]);
      k.label(0, 1.57, 1.689, 2.88, 0.53, 'GENERATOR ' + (z + 95), 'BACKUP / DISTRIBUTION', '#cebc83');
      k.solid(0, 1.9, 0, 14.7, 3.8, 5.6);
      k.shadow(0, 0, 18, 8);
      for (const s of [-1, 1]) {
        k.rod([3.9, 0.65, s * 1.12], [3.9, 0.65, s * 3.03], 0.16);
        k.rod([3.9, 0.65, s * 3.03], [7.45, 0.65, s * 3.03], 0.16);
      }
    });
  }
  for (let z = -96; z < -65; z += 3.7) {
    cabinet(k, 100.7, z, 3.1, 2.45, 0.79, '#9da994', -pi / 2, 2);
    k.box(100.26, 1.81, z, 0.04, 0.25, 1.89, 'vent', '#687b64');
  }
  kiosk(k, 71, -86, 'POWER SCADA', pi / 2);
  k.label(84, 4.31, -103.62, 16, 1.93, '07  /  POWER', 'GENERATION  +  ELECTRICAL DISTRIBUTION', '#cfb67c');
  for (const x of [35.8, 51.4])
    for (const z of [-93, -76]) {
      k.cyl(x, 0.24, z, 3.36, 0.48, 'stone', '#8f9c8c');
      k.cyl(x, 2.49, z, 3.16, 4.55, 'steel', '#adb7a7');
      k.oval(x, 4.78, z, 3.15, 0.52, 3.15, 'steel', '#b8bdae');
      for (const h of [1.03, 2.58, 4.18]) k.cyl(x, h, z, 3.2, 0.078, 'graphite', '#7a8c7f');
      k.cyl(x, 5.24, z, 0.48, 0.23, 'steel', '#a6b1a2');
      k.label(
        x,
        2.72,
        z + 3.177,
        2.2,
        0.56,
        'H2O  /  ' + (x > 40 ? '02' : '01'),
        'FILTRATION TANK',
        '#a1c4b7',
      );
      k.rod([x + 2.7, 0.94, z], [x + 4.7, 0.94, z], 0.21, 'paint', '#73958b');
      k.rod([x + 4.7, 0.94, z], [x + 4.7, 3.75, z], 0.19, 'paint', '#799a8d');
      for (const y of [1.31, 3.21]) k.cyl(x + 4.7, y, z, 0.27, 0.11, 'steel', '#a9b3a1');
      const valve = new T.TorusGeometry(0.237, 0.032, 6, 16);
      k.emit(valve, 'paint', x + 4.7, 2.2, z + 0.4, 1, 1, 1, '#9b6a49');
      k.rod([x + 4.7, 2.2, z], [x + 4.7, 2.2, z + 0.41], 0.049);
      k.solid(x, 2.48, z, 6.4, 4.97, 6.4);
      k.shadow(x, z, 9, 9);
    }
  k.rod([40.5, 3.75, -93], [40.5, 3.75, -76], 0.19, 'paint', '#76998c');
  k.rod([56.1, 3.75, -93], [56.1, 3.75, -76], 0.19, 'paint', '#76998c');
  k.box(44.2, 0.72, -85, 3.24, 0.2, 30, 'vent', '#838e7c');
  k.walk(44.2, -85, 3.24, 30, 0.82);
  for (let i = 0; i < 5; i++) {
    k.box(44.2, 0.082 * (i + 1), -67.97 - i * 0.39, 3.24, 0.164 * (i + 1), 0.4, 'steel', '#9ba48f');
    k.walk(44.2, -67.97 - i * 0.39, 3.24, 0.41, 0.164 * (i + 1));
  }
  for (const s of [-1, 1]) railing(k, 44.2 + s * 1.63, -85, 30, 0.82, pi / 2, false);
  kiosk(k, 28.5, -70, 'WATER CONTROL', pi / 2);
  k.label(44, 4.69, -103.61, 14.7, 1.61, '08  /  WATER', 'PURIFICATION  +  RESERVE STORAGE', '#8cb9aa');
  for (const x of [36, 54, 74, 93]) {
    k.at(x, 0, -48, 0, () => {
      table(k, 0, 0, 7.1, 1.51, 'steel');
      cabinet(k, -2.45, 0.03, 1.71, 0.71, 1.04, '#a87853', 0, 4);
      cabinet(k, 2.43, 0.03, 1.71, 0.71, 1.04, '#a87853', 0, 4);
      k.box(0, 1.86, -0.74, 7.11, 1.89, 0.13, 'vent', '#a7967d');
      for (let i = 0; i < 14; i++) {
        const xx = -3.12 + i * 0.477;
        const h = 0.27 + (i % 4) * 0.079;
        k.rod([xx, 2.31, -0.645], [xx, 2.31 - h, -0.645], 0.027, 'steel', '#c5c7b6');
        k.cyl(xx, 2.34, -0.648, 0.077, 0.041, 'steel', '#adbaa4', [pi / 2, 0, 0]);
        k.box(xx, 2.26 - h, -0.635, 0.071, 0.147, 0.071, 'rubber', '#626f5d', true);
      }
      k.box(0, 2.9, -0.47, 7.24, 0.08, 0.73, 'steel', '#a9b29d');
      k.box(0, 2.848, -0.2, 6.98, 0.023, 0.12, 'light', '#ffe3b1');
      k.box(0, 1.02, 0.09, 0.76, 0.41, 0.4, 'graphite', '#666f63', true);
      k.cyl(0, 1.3, 0.09, 0.15, 0.53, 'steel', '#95a18d', [0, 0, pi / 2]);
    });
    shelf(k, x, -56.4, 6.3, 0.92, 'supply');
  }
  for (const x of [43, 66, 87]) {
    table(k, x, -33, 4.4, 1.63, 'steel');
    cabinet(k, x + 3.65, -33, 1.1, 1.06, 0.69, '#a87854', 0, 5);
  }
  k.label(50, 3.89, -59.64, 14, 1.6, '09  /  MAINTENANCE', 'REPAIR WORKSHOP  +  PARTS LIBRARY', '#c39370');
  kiosk(k, 99, -30, 'WORK ORDERS');
  safety(k, 102.96, -38, -pi / 2);
}

export function storage(k: K) {
  for (const x of [43, 55, 67, 79, 91])
    for (const z of [77.6, 90.5]) {
      shelf(k, x, z, 9.43, 1.43, 'supply', pi / 2);
      k.label(x, 3.99, z + 4.79, 1.81, 0.48, 'R ' + Math.round(x / 9), 'SUPPLY RESERVE', '#acb59a');
    }
  room(k, 32.1, 92.2, 11.98, 16, 'Cold reserves', '#adc3b5', true);
  for (const z of [88, 94]) cabinet(k, 32.5, z, 3.33, 2.1, 0.82, '#b0bba7');
  table(k, 34.4, 72.4, 3.4, 1.3, 'steel');
  monitor(k, 34.4, 0.87, 72.3, 0);
  chair(k, 34.4, 73.75, pi, 'office', '#748570');
  for (const x of [51, 70, 91]) {
    k.box(x, 0.012, 99, 11, 0.014, 0.12, 'paint', '#baae7d');
    k.label(
      x,
      0.027,
      99.9,
      5.54,
      0.8,
      'LOADING  /  ' + Math.ceil(x / 30),
      'KEEP AISLE CLEAR',
      '#bdaf88',
      0,
      true,
    );
  }
  k.label(
    63,
    4.97,
    103.62,
    17.2,
    1.61,
    '10  /  LOGISTICS',
    'GENERAL SUPPLIES  +  COLD RESERVES',
    '#a6b597',
    pi,
  );
  kiosk(k, 98, 70, 'INVENTORY', -pi / 2);
}
