import * as THREE from 'three';

function makeCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

function toTexture(
  canvas: HTMLCanvasElement,
  repeatX = 1,
  repeatY = 1,
  srgb = true
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = 4;
  if (srgb) {
    tex.colorSpace = THREE.SRGBColorSpace;
  }
  tex.needsUpdate = true;
  return tex;
}

export interface TexturePack {
  glassSkyscraperA: THREE.CanvasTexture;
  glassSkyscraperAEmissive: THREE.CanvasTexture;
  glassSkyscraperB: THREE.CanvasTexture;
  glassSkyscraperBEmissive: THREE.CanvasTexture;
  concreteTower: THREE.CanvasTexture;
  concreteTowerEmissive: THREE.CanvasTexture;
  hotelFacade: THREE.CanvasTexture;
  mallFacade: THREE.CanvasTexture;
  asphaltRoad: THREE.CanvasTexture;
  plazaPaver: THREE.CanvasTexture;
  sidewalkConcrete: THREE.CanvasTexture;
  hazardStripes: THREE.CanvasTexture;
  blastSteel: THREE.CanvasTexture;
  bunkerWall: THREE.CanvasTexture;
  bunkerFloor: THREE.CanvasTexture;
  hospitalTile: THREE.CanvasTexture;
  schoolFloor: THREE.CanvasTexture;
  parkGrass: THREE.CanvasTexture;
  helipad: THREE.CanvasTexture;
}

export function createTexturePack(): TexturePack {
  // 1. Glass Skyscraper A (Blue-Teal Curtain Wall + Mullions + Selective Lit Offices)
  const [gACanvas, gACtx] = makeCanvas(512, 512);
  const [gAECanvas, gAECtx] = makeCanvas(512, 512);
  gACtx.fillStyle = '#182433';
  gACtx.fillRect(0, 0, 512, 512);
  gAECtx.fillStyle = '#000000';
  gAECtx.fillRect(0, 0, 512, 512);

  const cols = 8;
  const rows = 12;
  const cw = 512 / cols;
  const rh = 512 / rows;

  for (let r = 0; r < rows; r++) {
    // Structural spandrel band
    gACtx.fillStyle = '#101822';
    gACtx.fillRect(0, r * rh, 512, 10);
    for (let c = 0; c < cols; c++) {
      const seed = (r * 37 + c * 17) % 19;
      const lit = seed === 2 || seed === 7 || seed === 13;
      const warm = seed === 7;
      const x = c * cw + 4;
      const y = r * rh + 10;
      const w = cw - 8;
      const h = rh - 13;

      const grad = gACtx.createLinearGradient(x, y, x, y + h);
      if (lit) {
        grad.addColorStop(0, warm ? '#9e8458' : '#5f87a6');
        grad.addColorStop(1, warm ? '#5b4b32' : '#2e4960');
        gAECtx.fillStyle = warm ? '#aa7c3e' : '#3d6e8f';
        gAECtx.fillRect(x + 2, y + 2, w - 4, h - 4);
      } else {
        grad.addColorStop(0, '#2a4158');
        grad.addColorStop(0.5, '#1d2f42');
        grad.addColorStop(1, '#14202e');
      }
      gACtx.fillStyle = grad;
      gACtx.fillRect(x, y, w, h);

      // Vertical mullion highlight
      gACtx.fillStyle = '#364b61';
      gACtx.fillRect(c * cw, r * rh, 3, rh);
    }
  }

  // 2. Glass Skyscraper B (Gold/Charcoal Executive Curtain Wall)
  const [gBCanvas, gBCtx] = makeCanvas(512, 512);
  const [gBECanvas, gBECtx] = makeCanvas(512, 512);
  gBCtx.fillStyle = '#1d1f24';
  gBCtx.fillRect(0, 0, 512, 512);
  gBECtx.fillStyle = '#000000';
  gBECtx.fillRect(0, 0, 512, 512);

  for (let r = 0; r < 10; r++) {
    const rH = 512 / 10;
    gBCtx.fillStyle = '#2d3138';
    gBCtx.fillRect(0, r * rH, 512, 12);
    for (let c = 0; c < 6; c++) {
      const cW = 512 / 6;
      const seed = (r * 23 + c * 41) % 13;
      const lit = seed === 1 || seed === 5 || seed === 9;
      const x = c * cW + 5;
      const y = r * rH + 12;
      const w = cW - 10;
      const h = rH - 14;
      gBCtx.fillStyle = lit ? '#8e7e5c' : '#28303b';
      gBCtx.fillRect(x, y, w, h);
      // Window divider
      gBCtx.fillStyle = '#15181d';
      gBCtx.fillRect(x + w * 0.5 - 1, y, 2, h);
      if (lit) {
        gBECtx.fillStyle = '#8b7346';
        gBECtx.fillRect(x + 2, y + 2, w - 4, h - 4);
      }
    }
  }

  // 3. Brutalist Concrete Commercial Tower
  const [cCanvas, cCtx] = makeCanvas(512, 512);
  const [cECanvas, cECtx] = makeCanvas(512, 512);
  cCtx.fillStyle = '#6d7073';
  cCtx.fillRect(0, 0, 512, 512);
  cECtx.fillStyle = '#000000';
  cECtx.fillRect(0, 0, 512, 512);
  // Subtle concrete panel lines & weathering
  for (let i = 0; i < 400; i++) {
    cCtx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.05)';
    cCtx.fillRect((i * 73) % 512, (i * 41) % 512, 18, 12);
  }
  for (let r = 0; r < 8; r++) {
    const rH = 512 / 8;
    // Recessed horizontal ribbon window
    cCtx.fillStyle = '#222830';
    cCtx.fillRect(0, r * rH + 20, 512, 28);
    // Concrete piers
    for (let c = 0; c < 8; c++) {
      const cW = 512 / 8;
      cCtx.fillStyle = '#7b7f82';
      cCtx.fillRect(c * cW, r * rH, 14, rH);
      cCtx.fillStyle = '#535659';
      cCtx.fillRect(c * cW + 14, r * rH, 4, rH);
      if ((r + c * 3) % 7 === 0) {
        cECtx.fillStyle = '#6f8596';
        cECtx.fillRect(c * cW + 20, r * rH + 22, cW - 24, 24);
      }
    }
  }

  // 4. Grand Hotel / Balcony Tower
  const [hCanvas, hCtx] = makeCanvas(512, 512);
  hCtx.fillStyle = '#8b8378';
  hCtx.fillRect(0, 0, 512, 512);
  for (let r = 0; r < 8; r++) {
    const rH = 512 / 8;
    // Slab edge
    hCtx.fillStyle = '#a39b90';
    hCtx.fillRect(0, r * rH, 512, 10);
    for (let c = 0; c < 6; c++) {
      const cW = 512 / 6;
      const x = c * cW + 6;
      // Glass sliding door
      hCtx.fillStyle = (r + c) % 4 === 0 ? '#9c835d' : '#24313d';
      hCtx.fillRect(x, r * rH + 12, cW - 12, rH - 22);
      // Balcony railing
      hCtx.fillStyle = '#383d42';
      hCtx.fillRect(x - 2, r * rH + rH - 12, cW - 8, 10);
    }
  }

  // 5. Shopping Complex / Mall Facade
  const [mCanvas, mCtx] = makeCanvas(512, 512);
  mCtx.fillStyle = '#333b44';
  mCtx.fillRect(0, 0, 512, 512);
  // Cladding panels
  for (let y = 0; y < 512; y += 64) {
    mCtx.fillStyle = y % 128 === 0 ? '#444f5b' : '#38414b';
    mCtx.fillRect(0, y, 512, 62);
  }
  // Large storefront glass band
  mCtx.fillStyle = '#243e52';
  mCtx.fillRect(16, 160, 480, 220);
  mCtx.strokeStyle = '#6f8294';
  mCtx.lineWidth = 6;
  for (let x = 16; x <= 496; x += 80) {
    mCtx.beginPath();
    mCtx.moveTo(x, 160);
    mCtx.lineTo(x, 380);
    mCtx.stroke();
  }

  // 6. Asphalt Road
  const [rCanvas, rCtx] = makeCanvas(256, 256);
  rCtx.fillStyle = '#24272c';
  rCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 800; i++) {
    rCtx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.08)';
    rCtx.fillRect((i * 53) % 256, (i * 97) % 256, 3, 3);
  }
  // Subtle road wear tracks
  rCtx.fillStyle = 'rgba(0,0,0,0.14)';
  rCtx.fillRect(42, 0, 34, 256);
  rCtx.fillRect(180, 0, 34, 256);

  // 7. Plaza Stone Pavers
  const [pCanvas, pCtx] = makeCanvas(256, 256);
  pCtx.fillStyle = '#535860';
  pCtx.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 32) {
    for (let x = 0; x < 256; x += 32) {
      const shade = 78 + ((x * 7 + y * 13) % 18);
      pCtx.fillStyle = `rgb(${shade}, ${shade + 3}, ${shade + 7})`;
      pCtx.fillRect(x + 1, y + 1, 30, 30);
    }
  }

  // 8. Sidewalk Concrete
  const [sCanvas, sCtx] = makeCanvas(256, 256);
  sCtx.fillStyle = '#6d7178';
  sCtx.fillRect(0, 0, 256, 256);
  sCtx.strokeStyle = '#555960';
  sCtx.lineWidth = 2;
  for (let i = 0; i <= 256; i += 64) {
    sCtx.beginPath();
    sCtx.moveTo(i, 0);
    sCtx.lineTo(i, 256);
    sCtx.moveTo(0, i);
    sCtx.lineTo(256, i);
    sCtx.stroke();
  }

  // 9. Hazard Stripes
  const [hzCanvas, hzCtx] = makeCanvas(256, 256);
  hzCtx.fillStyle = '#d49b1a';
  hzCtx.fillRect(0, 0, 256, 256);
  hzCtx.fillStyle = '#181a1f';
  for (let i = -256; i < 512; i += 64) {
    hzCtx.beginPath();
    hzCtx.moveTo(i, 0);
    hzCtx.lineTo(i + 32, 0);
    hzCtx.lineTo(i + 288, 256);
    hzCtx.lineTo(i + 256, 256);
    hzCtx.closePath();
    hzCtx.fill();
  }

  // 10. Reinforced Blast Steel (Hatch & Bunker Blast Doors)
  const [bsCanvas, bsCtx] = makeCanvas(512, 512);
  bsCtx.fillStyle = '#3b424b';
  bsCtx.fillRect(0, 0, 512, 512);
  // Heavy steel plate seams & rivets
  bsCtx.strokeStyle = '#23282e';
  bsCtx.lineWidth = 6;
  bsCtx.strokeRect(8, 8, 496, 496);
  bsCtx.strokeRect(24, 24, 464, 464);
  for (let y = 0; y < 512; y += 128) {
    bsCtx.beginPath();
    bsCtx.moveTo(0, y);
    bsCtx.lineTo(512, y);
    bsCtx.stroke();
  }
  for (let x = 0; x < 512; x += 128) {
    bsCtx.beginPath();
    bsCtx.moveTo(x, 0);
    bsCtx.lineTo(x, 512);
    bsCtx.stroke();
  }
  // Rivets
  bsCtx.fillStyle = '#5c6673';
  for (let y = 36; y < 500; y += 44) {
    bsCtx.fillRect(14, y, 6, 6);
    bsCtx.fillRect(492, y, 6, 6);
  }
  // Caution border stripe
  bsCtx.fillStyle = '#c48f18';
  bsCtx.fillRect(0, 0, 512, 12);
  bsCtx.fillRect(0, 500, 512, 12);

  // 11. Bunker Concrete Ribbed Wall
  const [bwCanvas, bwCtx] = makeCanvas(256, 256);
  bwCtx.fillStyle = '#50565e';
  bwCtx.fillRect(0, 0, 256, 256);
  bwCtx.fillStyle = '#3f444c';
  bwCtx.fillRect(0, 200, 256, 56);
  bwCtx.fillStyle = '#656c75';
  bwCtx.fillRect(0, 194, 256, 6);
  bwCtx.strokeStyle = '#353a40';
  bwCtx.lineWidth = 3;
  for (let x = 0; x <= 256; x += 64) {
    bwCtx.beginPath();
    bwCtx.moveTo(x, 0);
    bwCtx.lineTo(x, 256);
    bwCtx.stroke();
  }

  // 12. Bunker Industrial Floor
  const [bfCanvas, bfCtx] = makeCanvas(256, 256);
  bfCtx.fillStyle = '#3a3f46';
  bfCtx.fillRect(0, 0, 256, 256);
  bfCtx.strokeStyle = '#2d3137';
  bfCtx.lineWidth = 3;
  bfCtx.strokeRect(2, 2, 252, 252);
  bfCtx.strokeRect(128, 2, 126, 252);
  bfCtx.strokeRect(2, 128, 252, 126);

  // 13. Hospital Clean Tile
  const [htCanvas, htCtx] = makeCanvas(256, 256);
  htCtx.fillStyle = '#b9c9cb';
  htCtx.fillRect(0, 0, 256, 256);
  htCtx.strokeStyle = '#92a8ab';
  htCtx.lineWidth = 2;
  for (let i = 0; i <= 256; i += 32) {
    htCtx.beginPath();
    htCtx.moveTo(i, 0);
    htCtx.lineTo(i, 256);
    htCtx.moveTo(0, i);
    htCtx.lineTo(256, i);
    htCtx.stroke();
  }

  // 14. School Terrazzo Floor
  const [sfCanvas, sfCtx] = makeCanvas(256, 256);
  sfCtx.fillStyle = '#a39988';
  sfCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 300; i++) {
    sfCtx.fillStyle = i % 3 === 0 ? '#787164' : '#bfb5a4';
    sfCtx.fillRect((i * 47) % 256, (i * 83) % 256, 4, 4);
  }
  sfCtx.strokeStyle = '#877e6f';
  sfCtx.lineWidth = 2;
  for (let i = 0; i <= 256; i += 64) {
    sfCtx.beginPath();
    sfCtx.moveTo(i, 0);
    sfCtx.lineTo(i, 256);
    sfCtx.moveTo(0, i);
    sfCtx.lineTo(256, i);
    sfCtx.stroke();
  }

  // 15. Urban Park Grass
  const [pkCanvas, pkCtx] = makeCanvas(256, 256);
  pkCtx.fillStyle = '#334d30';
  pkCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 600; i++) {
    pkCtx.fillStyle = i % 2 === 0 ? '#3f5d3b' : '#283d25';
    pkCtx.fillRect((i * 37) % 256, (i * 61) % 256, 4, 4);
  }

  // 16. Helipad Marking
  const [hpCanvas, hpCtx] = makeCanvas(256, 256);
  hpCtx.fillStyle = '#2d3238';
  hpCtx.fillRect(0, 0, 256, 256);
  hpCtx.strokeStyle = '#d4a62a';
  hpCtx.lineWidth = 10;
  hpCtx.beginPath();
  hpCtx.arc(128, 128, 96, 0, Math.PI * 2);
  hpCtx.stroke();
  hpCtx.fillStyle = '#d4a62a';
  hpCtx.fillRect(82, 68, 20, 120);
  hpCtx.fillRect(154, 68, 20, 120);
  hpCtx.fillRect(82, 118, 92, 20);

  return {
    glassSkyscraperA: toTexture(gACanvas, 1, 2),
    glassSkyscraperAEmissive: toTexture(gAECanvas, 1, 2),
    glassSkyscraperB: toTexture(gBCanvas, 1, 2),
    glassSkyscraperBEmissive: toTexture(gBECanvas, 1, 2),
    concreteTower: toTexture(cCanvas, 1, 2),
    concreteTowerEmissive: toTexture(cECanvas, 1, 2),
    hotelFacade: toTexture(hCanvas, 1, 2),
    mallFacade: toTexture(mCanvas, 2, 1),
    asphaltRoad: toTexture(rCanvas, 16, 16),
    plazaPaver: toTexture(pCanvas, 14, 14),
    sidewalkConcrete: toTexture(sCanvas, 6, 6),
    hazardStripes: toTexture(hzCanvas, 4, 1),
    blastSteel: toTexture(bsCanvas, 2, 2),
    bunkerWall: toTexture(bwCanvas, 2, 1),
    bunkerFloor: toTexture(bfCanvas, 16, 16),
    hospitalTile: toTexture(htCanvas, 12, 12),
    schoolFloor: toTexture(sfCanvas, 12, 12),
    parkGrass: toTexture(pkCanvas, 6, 6),
    helipad: toTexture(hpCanvas, 1, 1),
  };
}

/**
 * Generates crisp wall signage textures for bunker sectors & city complexes.
 */
export function createSignTexture(
  title: string,
  subtitle: string,
  accentColor = '#f59e0b',
  bgColor = '#141920'
): THREE.CanvasTexture {
  const [canvas, ctx] = makeCanvas(512, 160);
  ctx.fillStyle = bgColor;
  ctx.fillRect(0, 0, 512, 160);

  ctx.fillStyle = accentColor;
  ctx.fillRect(0, 0, 18, 160);
  ctx.fillRect(0, 0, 512, 6);
  ctx.fillRect(0, 154, 512, 6);

  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 40px sans-serif';
  ctx.textBaseline = 'middle';
  ctx.fillText(title, 36, 62);

  ctx.fillStyle = accentColor;
  ctx.font = 'bold 24px monospace';
  ctx.fillText(subtitle, 36, 114);

  return toTexture(canvas, 1, 1);
}
