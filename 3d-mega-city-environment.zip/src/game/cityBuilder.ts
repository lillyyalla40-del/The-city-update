import * as THREE from 'three';
import { CollisionWorld } from './collision';
import { TexturePack, createSignTexture } from './textures';
import { ZoneDefinition } from './types';

export interface CityBuildResult {
  group: THREE.Group;
  zones: ZoneDefinition[];
}

interface InstanceTransform {
  x: number;
  y: number;
  z: number;
  sx?: number;
  sy?: number;
  sz?: number;
  ry?: number;
  color?: number;
}

function addInstances(
  parent: THREE.Group,
  geometry: THREE.BufferGeometry,
  material: THREE.Material,
  items: InstanceTransform[]
): THREE.InstancedMesh | null {
  if (items.length === 0) return null;
  const mesh = new THREE.InstancedMesh(geometry, material, items.length);
  const dummy = new THREE.Object3D();
  const col = new THREE.Color();
  let hasColors = false;

  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    dummy.position.set(it.x, it.y, it.z);
    dummy.rotation.set(0, it.ry ?? 0, 0);
    dummy.scale.set(it.sx ?? 1, it.sy ?? 1, it.sz ?? 1);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    if (it.color !== undefined) {
      hasColors = true;
      col.setHex(it.color);
      mesh.setColorAt(i, col);
    }
  }
  mesh.instanceMatrix.needsUpdate = true;
  if (hasColors && mesh.instanceColor) {
    mesh.instanceColor.needsUpdate = true;
  }
  mesh.frustumCulled = false;
  parent.add(mesh);
  return mesh;
}

export function buildMegaCity(
  collision: CollisionWorld,
  textures: TexturePack
): CityBuildResult {
  const group = new THREE.Group();
  group.name = 'AbovegroundMegaCity';

  const zones: ZoneDefinition[] = [
    {
      id: 'meridian_plaza',
      name: 'Central Meridian Plaza',
      subtitle: 'Ground-Level Bunker Access Sector',
      environment: 'surface',
      minX: -38,
      maxX: 38,
      minZ: -38,
      maxZ: 38,
      minY: -1.5,
      maxY: 40,
      color: '#f59e0b',
    },
    {
      id: 'financial_nw',
      name: 'Apex Financial District',
      subtitle: 'High-Rise Corporate Towers',
      environment: 'surface',
      minX: -180,
      maxX: -18,
      minZ: -180,
      maxZ: -18,
      minY: -1.5,
      maxY: 160,
      color: '#38bdf8',
    },
    {
      id: 'civic_ne',
      name: 'Northgate Commercial & Park',
      subtitle: 'Office Towers & Civic Commons',
      environment: 'surface',
      minX: 18,
      maxX: 180,
      minZ: -180,
      maxZ: -18,
      minY: -1.5,
      maxY: 160,
      color: '#34d399',
    },
    {
      id: 'galleria_sw',
      name: 'Metro Galleria Complex',
      subtitle: 'Shopping Concourse & Transit Hub',
      environment: 'surface',
      minX: -180,
      maxX: -18,
      minZ: 18,
      maxZ: 180,
      minY: -1.5,
      maxY: 160,
      color: '#a78bfa',
    },
    {
      id: 'hotel_se',
      name: 'Grand Meridian Hotel District',
      subtitle: 'Hospitality Towers & Expressways',
      environment: 'surface',
      minX: 18,
      maxX: 180,
      minZ: 18,
      maxZ: 180,
      minY: -1.5,
      maxY: 160,
      color: '#fb7185',
    },
  ];

  // Shared Architectural Materials (kept minimal for ultra-low draw calls)
  const asphaltMat = new THREE.MeshStandardMaterial({
    map: textures.asphaltRoad,
    roughness: 0.85,
    metalness: 0.08,
  });

  const sidewalkMat = new THREE.MeshStandardMaterial({
    map: textures.sidewalkConcrete,
    roughness: 0.9,
    metalness: 0.05,
  });

  const plazaMat = new THREE.MeshStandardMaterial({
    map: textures.plazaPaver,
    roughness: 0.8,
    metalness: 0.1,
  });

  const glassMatA = new THREE.MeshStandardMaterial({
    map: textures.glassSkyscraperA,
    emissiveMap: textures.glassSkyscraperAEmissive,
    emissive: new THREE.Color(0xffffff),
    emissiveIntensity: 0.65,
    roughness: 0.22,
    metalness: 0.65,
  });

  const glassMatB = new THREE.MeshStandardMaterial({
    map: textures.glassSkyscraperB,
    emissiveMap: textures.glassSkyscraperBEmissive,
    emissive: new THREE.Color(0xffffff),
    emissiveIntensity: 0.6,
    roughness: 0.25,
    metalness: 0.6,
  });

  const concreteTowerMat = new THREE.MeshStandardMaterial({
    map: textures.concreteTower,
    emissiveMap: textures.concreteTowerEmissive,
    emissive: new THREE.Color(0xffffff),
    emissiveIntensity: 0.45,
    roughness: 0.72,
    metalness: 0.18,
  });

  const hotelMat = new THREE.MeshStandardMaterial({
    map: textures.hotelFacade,
    roughness: 0.6,
    metalness: 0.2,
  });

  const mallMat = new THREE.MeshStandardMaterial({
    map: textures.mallFacade,
    roughness: 0.45,
    metalness: 0.35,
  });

  const trimDarkMat = new THREE.MeshStandardMaterial({
    color: 0x20262e,
    roughness: 0.55,
    metalness: 0.55,
  });

  const trimLightMat = new THREE.MeshStandardMaterial({
    color: 0x767d87,
    roughness: 0.75,
    metalness: 0.2,
  });

  const glassAtriumMat = new THREE.MeshStandardMaterial({
    color: 0x4b7896,
    roughness: 0.15,
    metalness: 0.8,
    transparent: true,
    opacity: 0.65,
  });

  const helipadMat = new THREE.MeshStandardMaterial({
    map: textures.helipad,
    roughness: 0.7,
  });

  // =========================================================================
  // 1. GROUND ASPHALT DECKS (Split around 18m x 18m Central Hatch Opening!)
  // =========================================================================
  const addGroundSlice = (minX: number, maxX: number, minZ: number, maxZ: number) => {
    const w = maxX - minX;
    const d = maxZ - minZ;
    const cx = (minX + maxX) * 0.5;
    const cz = (minZ + maxZ) * 0.5;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, 0.4, d), asphaltMat);
    mesh.position.set(cx, -0.2, cz);
    mesh.receiveShadow = true;
    group.add(mesh);

    collision.addSurface({
      minX,
      maxX,
      minZ,
      maxZ,
      yStart: 0.0,
      yEnd: 0.0,
      enabled: true,
    });
  };

  // Surrounding 560m x 560m ground outside the [-9, 9] central shaft hole
  addGroundSlice(-280, 280, -280, -9);
  addGroundSlice(-280, 280, 9, 280);
  addGroundSlice(-280, -9, -9, 9);
  addGroundSlice(9, 280, -9, 9);

  // =========================================================================
  // 2. CENTRAL MERIDIAN PLAZA (Surrounding the Hatch at Y = 0.15)
  // =========================================================================
  const addPlazaSlab = (minX: number, maxX: number, minZ: number, maxZ: number) => {
    const w = maxX - minX;
    const d = maxZ - minZ;
    const cx = (minX + maxX) * 0.5;
    const cz = (minZ + maxZ) * 0.5;
    const slab = new THREE.Mesh(new THREE.BoxGeometry(w, 0.3, d), plazaMat);
    slab.position.set(cx, 0.0, cz);
    slab.receiveShadow = true;
    group.add(slab);
    collision.addSurface({ minX, maxX, minZ, maxZ, yStart: 0.15, yEnd: 0.15 });
  };

  addPlazaSlab(-34, 34, -34, -9);
  addPlazaSlab(-34, 34, 9, 34);
  addPlazaSlab(-34, -9, -9, 9);
  addPlazaSlab(9, 34, -9, 9);

  // Plaza architectural monument pylons & illuminated civic beacons at 4 corners
  for (const sx of [-26, 26]) {
    for (const sz of [-26, 26]) {
      const base = new THREE.Mesh(new THREE.BoxGeometry(4.2, 1.2, 4.2), trimLightMat);
      base.position.set(sx, 0.75, sz);
      group.add(base);
      const obelisk = new THREE.Mesh(new THREE.BoxGeometry(1.8, 9.5, 1.8), trimDarkMat);
      obelisk.position.set(sx, 5.5, sz);
      group.add(obelisk);
      const band = new THREE.Mesh(
        new THREE.BoxGeometry(1.9, 0.4, 1.9),
        new THREE.MeshBasicMaterial({ color: 0xf59e0b })
      );
      band.position.set(sx, 9.6, sz);
      group.add(band);
      collision.addCenteredBox(sx, 2.5, sz, 4.2, 5.0, 4.2);
    }
  }

  // =========================================================================
  // 3. ROAD LANE MARKINGS & CROSSWALKS (Instanced)
  // =========================================================================
  const laneMarkings: InstanceTransform[] = [];
  const dashGeo = new THREE.BoxGeometry(0.28, 0.03, 3.2);
  const whitePaintMat = new THREE.MeshBasicMaterial({ color: 0xd1d5db });
  const yellowPaintMat = new THREE.MeshBasicMaterial({ color: 0xeab308 });
  const yellowMarkings: InstanceTransform[] = [];

  // North-South & East-West Boulevards
  const roadCoords = [-128, -68, 0, 68, 128];
  for (const r of roadCoords) {
    for (let t = -170; t <= 170; t += 9) {
      // Skip inside Central Plaza
      if (Math.abs(r) < 34 && Math.abs(t) < 35) continue;
      // N-S Avenue dashes
      laneMarkings.push({ x: r - 3.6, y: 0.02, z: t });
      laneMarkings.push({ x: r + 3.6, y: 0.02, z: t });
      yellowMarkings.push({ x: r, y: 0.025, z: t, sx: 1.2, sz: 2.6 });

      // E-W Avenue dashes
      laneMarkings.push({ x: t, y: 0.02, z: r - 3.6, ry: Math.PI * 0.5 });
      laneMarkings.push({ x: t, y: 0.02, z: r + 3.6, ry: Math.PI * 0.5 });
      yellowMarkings.push({ x: t, y: 0.025, z: r, sx: 1.2, sz: 2.6, ry: Math.PI * 0.5 });
    }
  }
  addInstances(group, dashGeo, whitePaintMat, laneMarkings);
  addInstances(group, dashGeo, yellowPaintMat, yellowMarkings);

  // =========================================================================
  // 4. CITY BLOCKS SIDEWALKS & MODULAR SKYSCRAPER ARCHITECTURE (Instanced for 60 FPS!)
  // =========================================================================
  const skyscraperMats = [glassMatA, glassMatB, concreteTowerMat, hotelMat];
  const facadeBatches: InstanceTransform[][] = [[], [], [], []];
  const darkTrimBoxes: InstanceTransform[] = [];
  const lightTrimBoxes: InstanceTransform[] = [];
  const lobbyGlassBoxes: InstanceTransform[] = [];
  const spireItems: InstanceTransform[] = [];
  const beaconBoxes: InstanceTransform[] = [];

  /**
   * Queues a multi-tiered realistic skyscraper (podium, setbacks, fins, rooftop mechanics)
   * into instanced batches so 60+ skyscrapers render in ~10 draw calls total!
   */
  const buildSkyscraper = (
    cx: number,
    cz: number,
    w: number,
    d: number,
    height: number,
    styleIdx: number,
    hasHelipad = false
  ) => {
    const matIdx = styleIdx % skyscraperMats.length;
    const podiumH = Math.min(10, height * 0.18);

    // Podium / Ground-floor Lobby
    darkTrimBoxes.push({ x: cx, y: podiumH * 0.5, z: cz, sx: w, sy: podiumH, sz: d });
    lobbyGlassBoxes.push({ x: cx, y: podiumH * 0.42, z: cz, sx: w + 0.15, sy: podiumH * 0.65, sz: d + 0.15 });
    lightTrimBoxes.push({ x: cx, y: 4.4, z: cz + d * 0.5 + 1.5, sx: w * 0.46, sy: 0.5, sz: 3.2 });

    // Main Tower Shaft & Setback Crown
    const shaftW = w * 0.84;
    const shaftD = d * 0.84;
    const shaftH = height * 0.62;
    facadeBatches[matIdx].push({
      x: cx,
      y: podiumH + shaftH * 0.5,
      z: cz,
      sx: shaftW,
      sy: shaftH,
      sz: shaftD,
    });

    // Mechanical Band Collar
    darkTrimBoxes.push({ x: cx, y: podiumH + shaftH, z: cz, sx: shaftW + 0.6, sy: 1.4, sz: shaftD + 0.6 });

    // Upper Setback Crown
    const crownW = shaftW * 0.78;
    const crownD = shaftD * 0.78;
    const crownH = Math.max(8, height - podiumH - shaftH);
    facadeBatches[matIdx].push({
      x: cx,
      y: podiumH + shaftH + crownH * 0.5,
      z: cz,
      sx: crownW,
      sy: crownH,
      sz: crownD,
    });

    // Vertical Architectural Corner Fins
    const finH = shaftH + crownH * 0.7;
    for (const fx of [-1, 1]) {
      for (const fz of [-1, 1]) {
        lightTrimBoxes.push({
          x: cx + fx * shaftW * 0.48,
          y: podiumH + finH * 0.5,
          z: cz + fz * shaftD * 0.48,
          sx: 0.9,
          sy: finH,
          sz: 0.9,
        });
      }
    }

    // Rooftop Parapet, Cooling Units & Spire/Helipad
    const roofY = podiumH + shaftH + crownH;
    darkTrimBoxes.push({ x: cx, y: roofY + 0.6, z: cz, sx: crownW + 0.5, sy: 1.2, sz: crownD + 0.5 });

    if (hasHelipad) {
      const pad = new THREE.Mesh(new THREE.PlaneGeometry(crownW * 0.75, crownD * 0.75), helipadMat);
      pad.rotation.x = -Math.PI * 0.5;
      pad.position.set(cx, roofY + 1.25, cz);
      group.add(pad);
    } else {
      lightTrimBoxes.push({ x: cx, y: roofY + 2.1, z: cz, sx: crownW * 0.45, sy: 3.0, sz: crownD * 0.45 });
      if (height > 62) {
        spireItems.push({ x: cx, y: roofY + 9.5, z: cz });
        beaconBoxes.push({ x: cx, y: roofY + 16.5, z: cz });
      }
    }

    // Solid Collider for Podium + Tower
    collision.addCenteredBox(cx, height * 0.5, cz, w, height + 2, d);
  };

  /**
   * Builds a block sidewalk island with optional urban furniture.
   */
  const addSidewalkBlock = (minX: number, maxX: number, minZ: number, maxZ: number) => {
    const w = maxX - minX;
    const d = maxZ - minZ;
    const cx = (minX + maxX) * 0.5;
    const cz = (minZ + maxZ) * 0.5;
    const slab = new THREE.Mesh(new THREE.BoxGeometry(w, 0.3, d), sidewalkMat);
    slab.position.set(cx, 0.0, cz);
    slab.receiveShadow = true;
    group.add(slab);
    collision.addSurface({ minX, maxX, minZ, maxZ, yStart: 0.15, yEnd: 0.15 });
  };

  // Metropolitan block layout avoiding Central Plaza (-34..34) and main avenues (-128, -68, 0, 68, 128):
  const blocks: { minX: number; maxX: number; minZ: number; maxZ: number }[] = [];
  const xSpans: [number, number][] = [
    [-168, -138],
    [-118, -78],
    [-58, -18],
    [18, 58],
    [78, 118],
    [138, 168],
  ];
  const zSpans: [number, number][] = [
    [-168, -138],
    [-118, -78],
    [-58, -18],
    [18, 58],
    [78, 118],
    [138, 168],
  ];

  for (let ix = 0; ix < xSpans.length; ix++) {
    for (let iz = 0; iz < zSpans.length; iz++) {
      const [minX, maxX] = xSpans[ix];
      const [minZ, maxZ] = zSpans[iz];
      // Skip the 4 inner corners that overlap Central Meridian Plaza (-34..34)
      if (Math.abs((minX + maxX) * 0.5) < 42 && Math.abs((minZ + maxZ) * 0.5) < 42) {
        continue;
      }
      blocks.push({ minX, maxX, minZ, maxZ });
    }
  }

  // Special Landmark Districts assigned to specific blocks
  const treePositions: InstanceTransform[] = [];
  const benchPositions: InstanceTransform[] = [];

  const buildUrbanPark = (b: { minX: number; maxX: number; minZ: number; maxZ: number }) => {
    const w = b.maxX - b.minX;
    const d = b.maxZ - b.minZ;
    const cx = (b.minX + b.maxX) * 0.5;
    const cz = (b.minZ + b.maxZ) * 0.5;

    const grass = new THREE.Mesh(
      new THREE.BoxGeometry(w - 4, 0.34, d - 4),
      new THREE.MeshStandardMaterial({ map: textures.parkGrass, roughness: 0.95 })
    );
    grass.position.set(cx, 0.02, cz);
    group.add(grass);

    // Cross stone walkways
    const path1 = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.36, d - 1), plazaMat);
    path1.position.set(cx, 0.03, cz);
    group.add(path1);
    const path2 = new THREE.Mesh(new THREE.BoxGeometry(w - 1, 0.36, 4.5), plazaMat);
    path2.position.set(cx, 0.03, cz);
    group.add(path2);

    // Dry Concrete Fountain Monument at Park Center
    const basin = new THREE.Mesh(new THREE.CylinderGeometry(5.5, 6.0, 0.9, 16), trimLightMat);
    basin.position.set(cx, 0.6, cz);
    group.add(basin);
    const spire = new THREE.Mesh(new THREE.BoxGeometry(1.6, 4.5, 1.6), trimDarkMat);
    spire.position.set(cx, 2.4, cz);
    group.add(spire);
    collision.addCenteredBox(cx, 1.5, cz, 11.0, 3.0, 11.0);

    // Perimeter trees & benches
    for (const tx of [-w * 0.32, w * 0.32]) {
      for (const tz of [-d * 0.32, d * 0.32]) {
        treePositions.push({ x: cx + tx, y: 0.18, z: cz + tz });
        collision.addCenteredBox(cx + tx, 1.8, cz + tz, 1.1, 3.6, 1.1);
      }
    }
    benchPositions.push({ x: cx - 7, y: 0.45, z: cz + 3.2, ry: 0 });
    benchPositions.push({ x: cx + 7, y: 0.45, z: cz - 3.2, ry: Math.PI });
  };

  // Accessible Walkable Shopping Complex (Metro Galleria) at SW Block (-98, 98)
  const buildShoppingGalleria = (cx: number, cz: number) => {
    const mallGroup = new THREE.Group();
    mallGroup.position.set(cx, 0, cz);

    // Walkable interior terrazzo slab
    const floor = new THREE.Mesh(new THREE.BoxGeometry(38, 0.3, 38), plazaMat);
    floor.position.y = 0.01;
    mallGroup.add(floor);
    collision.addSurface({
      minX: cx - 19,
      maxX: cx + 19,
      minZ: cz - 19,
      maxZ: cz + 19,
      yStart: 0.16,
      yEnd: 0.16,
    });

    // Outer perimeter walls with wide North & East open entrance portals!
    // West & South solid shopping wings
    const westWing = new THREE.Mesh(new THREE.BoxGeometry(8, 14, 38), mallMat);
    westWing.position.set(-15, 7, 0);
    mallGroup.add(westWing);
    collision.addCenteredBox(cx - 15, 7, cz, 8, 14, 38);

    const southWing = new THREE.Mesh(new THREE.BoxGeometry(30, 14, 8), mallMat);
    southWing.position.set(4, 7, 15);
    mallGroup.add(southWing);
    collision.addCenteredBox(cx + 4, 7, cz + 15, 30, 14, 8);

    // North & East colonnade frames with 12m wide walkable portal openings
    const nwCorner = new THREE.Mesh(new THREE.BoxGeometry(10, 14, 7), mallMat);
    nwCorner.position.set(-10, 7, -15.5);
    mallGroup.add(nwCorner);
    collision.addCenteredBox(cx - 10, 7, cz - 15.5, 10, 14, 7);

    const neCorner = new THREE.Mesh(new THREE.BoxGeometry(10, 14, 7), mallMat);
    neCorner.position.set(14, 7, -15.5);
    mallGroup.add(neCorner);
    collision.addCenteredBox(cx + 14, 7, cz - 15.5, 10, 14, 7);

    const seCorner = new THREE.Mesh(new THREE.BoxGeometry(7, 14, 14), mallMat);
    seCorner.position.set(15.5, 7, 8);
    mallGroup.add(seCorner);
    collision.addCenteredBox(cx + 15.5, 7, cz + 8, 7, 14, 14);

    // Upper Sky-Roof Skylight Vault spanning the entire Galleria (Y = 14)
    const roofRim = new THREE.Mesh(new THREE.BoxGeometry(38, 1.4, 38), trimDarkMat);
    roofRim.position.y = 14.2;
    mallGroup.add(roofRim);
    collision.addCenteredBox(cx, 14.2, cz, 38, 1.4, 38);

    const skylight = new THREE.Mesh(new THREE.BoxGeometry(20, 2.2, 20), glassAtriumMat);
    skylight.position.y = 15.4;
    mallGroup.add(skylight);

    // Interior Atrium Kiosk & Columns
    for (const px of [-5, 7]) {
      for (const pz of [-5, 5]) {
        const col = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 14, 8), trimLightMat);
        col.position.set(px, 7, pz);
        mallGroup.add(col);
        collision.addCenteredBox(cx + px, 7, cz + pz, 1.2, 14, 1.2);
      }
    }

    const mallSign = new THREE.Mesh(
      new THREE.PlaneGeometry(14, 3.2),
      new THREE.MeshBasicMaterial({
        map: createSignTexture('METRO GALLERIA', 'COMMERCIAL CONCOURSE // OPEN ACCESS', '#a78bfa'),
      })
    );
    mallSign.position.set(2, 10.5, -19.1);
    mallSign.rotation.y = Math.PI;
    mallGroup.add(mallSign);

    group.add(mallGroup);
  };

  // Grand Twin-Tower Hotel Complex at SE Block (98, 98)
  const buildGrandHotel = (cx: number, cz: number) => {
    buildSkyscraper(cx - 10, cz - 4, 16, 26, 58, 3, false);
    buildSkyscraper(cx + 10, cz + 4, 16, 26, 66, 3, true);
    // Skybridge linking twin hotel towers at Y = 28m
    const bridge = new THREE.Mesh(new THREE.BoxGeometry(10, 4.5, 7.5), glassMatA);
    bridge.position.set(cx, 28, cz);
    group.add(bridge);
  };

  // Parking Structure / Surface Lot at (-98, 38)
  const buildParkingLot = (b: { minX: number; maxX: number; minZ: number; maxZ: number }) => {
    const w = b.maxX - b.minX;
    const d = b.maxZ - b.minZ;
    const cx = (b.minX + b.maxX) * 0.5;
    const cz = (b.minZ + b.maxZ) * 0.5;

    const lot = new THREE.Mesh(new THREE.BoxGeometry(w - 2, 0.28, d - 2), asphaltMat);
    lot.position.set(cx, 0.02, cz);
    group.add(lot);

    // Booth
    const booth = new THREE.Mesh(new THREE.BoxGeometry(3.2, 2.8, 2.6), trimDarkMat);
    booth.position.set(cx, 1.5, b.minZ + 3.5);
    group.add(booth);
    collision.addCenteredBox(cx, 1.5, b.minZ + 3.5, 3.2, 2.8, 2.6);
  };

  // Populate all city blocks deterministically (NO residential houses anywhere!)
  blocks.forEach((b, idx) => {
    addSidewalkBlock(b.minX, b.maxX, b.minZ, b.maxZ);
    const cx = (b.minX + b.maxX) * 0.5;
    const cz = (b.minZ + b.maxZ) * 0.5;
    const bw = b.maxX - b.minX;
    const bd = b.maxZ - b.minZ;

    // Assign specialized landmark blocks
    if (Math.abs(cx - 98) < 5 && Math.abs(cz - -98) < 5) {
      buildUrbanPark(b);
      return;
    }
    if (Math.abs(cx - -98) < 5 && Math.abs(cz - 98) < 5) {
      buildShoppingGalleria(cx, cz);
      return;
    }
    if (Math.abs(cx - 98) < 5 && Math.abs(cz - 98) < 5) {
      buildGrandHotel(cx, cz);
      return;
    }
    if (Math.abs(cx - -98) < 5 && Math.abs(cz - 38) < 5) {
      buildParkingLot(b);
      return;
    }
    if (Math.abs(cx - 38) < 5 && Math.abs(cz - -98) < 5) {
      buildUrbanPark(b);
      return;
    }

    // Standard Metropolitan High-Rise Commercial Blocks (1-2 towers per block with alleys!)
    if (bw >= 34 && bd >= 34) {
      const h1 = 44 + ((idx * 17) % 62); // 44m - 106m skyscrapers
      const h2 = 30 + ((idx * 23) % 44);
      buildSkyscraper(cx - 9, cz - 7, 17, 19, h1, idx % 4, idx % 5 === 0);
      buildSkyscraper(cx + 9.5, cz + 8, 16, 17, h2, (idx + 2) % 4, false);
    } else {
      const h = 36 + ((idx * 19) % 52);
      buildSkyscraper(cx, cz, Math.min(22, bw - 6), Math.min(22, bd - 6), h, idx % 4, idx % 4 === 0);
    }
  });

  // Flush all skyscraper structural batches as InstancedMeshes (~8 draw calls total for 60+ skyscrapers!)
  const unitBoxGeo = new THREE.BoxGeometry(1, 1, 1);
  for (let i = 0; i < skyscraperMats.length; i++) {
    addInstances(group, unitBoxGeo, skyscraperMats[i], facadeBatches[i]);
  }
  addInstances(group, unitBoxGeo, trimDarkMat, darkTrimBoxes);
  addInstances(group, unitBoxGeo, trimLightMat, lightTrimBoxes);
  addInstances(group, unitBoxGeo, glassAtriumMat, lobbyGlassBoxes);
  addInstances(group, new THREE.CylinderGeometry(0.18, 0.45, 14, 6), trimLightMat, spireItems);

  // =========================================================================
  // 5. ELEVATED MULTI-LANE HIGHWAY OVERPASS (East-West Viaduct along Z = -128)
  // =========================================================================
  const hwyY = 6.4;
  const hwyZ = -128;
  const hwyDeck = new THREE.Mesh(new THREE.BoxGeometry(272, 0.9, 13), concreteTowerMat);
  hwyDeck.position.set(0, hwyY - 0.45, hwyZ);
  group.add(hwyDeck);

  const hwyRoadSurface = new THREE.Mesh(new THREE.BoxGeometry(272, 0.1, 11.4), asphaltMat);
  hwyRoadSurface.position.set(0, hwyY + 0.02, hwyZ);
  group.add(hwyRoadSurface);

  // Highway Guardrails
  for (const gz of [hwyZ - 6.1, hwyZ + 6.1]) {
    const rail = new THREE.Mesh(new THREE.BoxGeometry(272, 1.0, 0.45), trimLightMat);
    rail.position.set(0, hwyY + 0.5, gz);
    group.add(rail);
    collision.addCenteredBox(0, hwyY + 0.5, gz, 272, 1.0, 0.45);
  }

  collision.addSurface({
    minX: -136,
    maxX: 136,
    minZ: hwyZ - 5.8,
    maxZ: hwyZ + 5.8,
    yStart: hwyY,
    yEnd: hwyY,
  });

  // Support Piers along Highway (spaced cleanly out of intersections)
  for (let px = -148; px <= 148; px += 34) {
    if (Math.abs(px) < 12 || Math.abs(Math.abs(px) - 68) < 10) continue;
    const pier = new THREE.Mesh(new THREE.BoxGeometry(2.6, hwyY, 4.5), trimLightMat);
    pier.position.set(px, hwyY * 0.5, hwyZ);
    group.add(pier);
    collision.addCenteredBox(px, hwyY * 0.5, hwyZ, 2.6, hwyY, 4.5);
  }

  // Walkable Highway On-Ramps (West & East ends: X = -172..-136 & X = 136..172)
  const rampLen = 36;
  const rampAngle = Math.atan2(hwyY, rampLen);
  const rampHyp = Math.sqrt(rampLen * rampLen + hwyY * hwyY);

  const westHwyRamp = new THREE.Mesh(new THREE.BoxGeometry(rampHyp, 0.7, 12.2), asphaltMat);
  westHwyRamp.position.set(-154, hwyY * 0.5 - 0.3, hwyZ);
  westHwyRamp.rotation.z = rampAngle;
  group.add(westHwyRamp);
  collision.addSurface({
    minX: -172,
    maxX: -136,
    minZ: hwyZ - 5.8,
    maxZ: hwyZ + 5.8,
    yStart: 0.0,
    yEnd: hwyY,
    slopeAxis: 'x',
  });

  const eastHwyRamp = new THREE.Mesh(new THREE.BoxGeometry(rampHyp, 0.7, 12.2), asphaltMat);
  eastHwyRamp.position.set(154, hwyY * 0.5 - 0.3, hwyZ);
  eastHwyRamp.rotation.z = -rampAngle;
  group.add(eastHwyRamp);
  collision.addSurface({
    minX: 136,
    maxX: 172,
    minZ: hwyZ - 5.8,
    maxZ: hwyZ + 5.8,
    yStart: hwyY,
    yEnd: 0.0,
    slopeAxis: 'x',
  });

  // =========================================================================
  // 6. UNDERGROUND ROAD TUNNEL PORTAL ENTRANCES (at X = ±128, Z = 42)
  // =========================================================================
  for (const tx of [-128, 128]) {
    const portalGroup = new THREE.Group();
    portalGroup.position.set(tx, 0, 42);

    // Concrete retaining tunnel arch
    const archTop = new THREE.Mesh(new THREE.BoxGeometry(12.5, 1.8, 10), trimDarkMat);
    archTop.position.set(0, 4.4, 2);
    portalGroup.add(archTop);

    for (const side of [-1, 1]) {
      const wall = new THREE.Mesh(new THREE.BoxGeometry(1.2, 5.2, 12), trimLightMat);
      wall.position.set(side * 5.7, 2.6, 2);
      portalGroup.add(wall);
      collision.addCenteredBox(tx + side * 5.7, 2.6, 44, 1.2, 5.2, 12);
    }

    // Dark tunnel interior void + emergency barricades
    const voidBack = new THREE.Mesh(
      new THREE.BoxGeometry(10.5, 4.8, 1.0),
      new THREE.MeshBasicMaterial({ color: 0x05070a })
    );
    voidBack.position.set(0, 2.4, 6.5);
    portalGroup.add(voidBack);
    collision.addCenteredBox(tx, 2.4, 48.5, 10.5, 4.8, 1.5);

    const tunnelSign = new THREE.Mesh(
      new THREE.PlaneGeometry(8.5, 1.6),
      new THREE.MeshBasicMaterial({
        map: createSignTexture('SUB-SURFACE TRANSIT TUNNEL', 'CLOSED // EMERGENCY EVACUATION', '#ef4444'),
      })
    );
    tunnelSign.position.set(0, 4.4, -3.1);
    tunnelSign.rotation.y = Math.PI;
    portalGroup.add(tunnelSign);

    group.add(portalGroup);
  }

  // =========================================================================
  // 7. INSTANCED CITY DETAILS: STREETLIGHTS, TRAFFIC SIGNALS, TREES, VEHICLES, BARRIERS
  // =========================================================================
  const poleItems: InstanceTransform[] = [];
  const lampHeadItems: InstanceTransform[] = [];
  const barrierItems: InstanceTransform[] = [];

  for (let p = -150; p <= 150; p += 28) {
    if (Math.abs(p) < 26) continue;
    // Along North-South Central & Outer Avenues
    for (const rx of [-11, 11, -77, -59, 59, 77]) {
      poleItems.push({ x: rx, y: 3.4, z: p });
      lampHeadItems.push({ x: rx + (rx < 0 ? 0.9 : -0.9), y: 6.7, z: p });
    }
  }

  addInstances(group, new THREE.CylinderGeometry(0.12, 0.16, 6.8, 6), trimDarkMat, poleItems);
  addInstances(
    group,
    new THREE.BoxGeometry(1.4, 0.25, 0.45),
    new THREE.MeshBasicMaterial({ color: 0xfde68a }),
    lampHeadItems
  );

  // Traffic Signal Gantries at Major Intersections
  const signalPosts: InstanceTransform[] = [];
  const signalRedLights: InstanceTransform[] = [];
  for (const ix of [-68, 68]) {
    for (const iz of [-68, 68]) {
      signalPosts.push({ x: ix - 9, y: 2.8, z: iz - 9 });
      signalRedLights.push({ x: ix - 7.5, y: 5.2, z: iz - 9 });
    }
  }
  addInstances(group, new THREE.CylinderGeometry(0.16, 0.2, 5.6, 6), trimDarkMat, signalPosts);
  addInstances(
    group,
    new THREE.BoxGeometry(0.45, 0.9, 0.45),
    new THREE.MeshBasicMaterial({ color: 0xef4444 }),
    signalRedLights
  );

  // Urban Park Trees & Benches
  if (treePositions.length > 0) {
    const trunks = treePositions.map((t) => ({ ...t, y: 1.6 }));
    const crowns = treePositions.map((t) => ({ ...t, y: 4.3 }));
    addInstances(
      group,
      new THREE.CylinderGeometry(0.26, 0.36, 3.2, 6),
      new THREE.MeshStandardMaterial({ color: 0x4b382a, roughness: 0.95 }),
      trunks
    );
    addInstances(
      group,
      new THREE.DodecahedronGeometry(2.1, 0),
      new THREE.MeshStandardMaterial({ color: 0x2d4a2b, roughness: 0.9 }),
      crowns
    );
  }
  if (benchPositions.length > 0) {
    addInstances(
      group,
      new THREE.BoxGeometry(2.2, 0.65, 0.75),
      new THREE.MeshStandardMaterial({ color: 0x5c4632, roughness: 0.8 }),
      benchPositions
    );
  }

  // Abandoned Vehicles (Sedans, SUVs, Buses & Emergency Vehicles) via InstancedMesh
  const carChassis: InstanceTransform[] = [];
  const carCabins: InstanceTransform[] = [];
  const busBodies: InstanceTransform[] = [];

  const vehicleSpecs = [
    { x: -16, z: -46, ry: 0.18, color: 0x475569 },
    { x: 18, z: -52, ry: -0.4, color: 0x7f1d1d },
    { x: -5, z: 48, ry: 0.9, color: 0x1e3a8a },
    { x: 5, z: -48, ry: -0.25, color: 0x3f3f46 },
    { x: -64, z: -32, ry: 0.1, color: 0x52525b },
    { x: -72, z: 26, ry: 1.4, color: 0x1e293b },
    { x: 64, z: 44, ry: -0.8, color: 0x78350f },
    { x: 72, z: -24, ry: 0.35, color: 0x334155 },
    { x: -94, z: 34, ry: 0.0, color: 0x475569 },
    { x: -102, z: 34, ry: 0.08, color: 0x374151 },
    { x: -94, z: 42, ry: Math.PI, color: 0x6b7280 },
    { x: 46, z: 4, ry: 1.55, color: 0x1d4ed8 },
    { x: -46, z: -5, ry: -1.3, color: 0x991b1b },
    { x: 124, z: -18, ry: 0.2, color: 0x3f3f46 },
    { x: -124, z: -84, ry: -0.5, color: 0x4b5563 },
  ];

  for (const v of vehicleSpecs) {
    carChassis.push({ x: v.x, y: 0.65, z: v.z, ry: v.ry, color: v.color });
    carCabins.push({ x: v.x, y: 1.32, z: v.z, ry: v.ry, color: 0x111827 });
    collision.addCenteredBox(v.x, 0.9, v.z, 2.3, 1.8, 4.4);
  }

  // City Transit Buses
  const busSpecs = [
    { x: -66, z: 84, ry: 0.22 },
    { x: 68, z: -56, ry: 1.45 },
    { x: 18, z: 54, ry: -0.6 },
  ];
  for (const b of busSpecs) {
    busBodies.push({ x: b.x, y: 1.55, z: b.z, ry: b.ry, color: 0xb45309 });
    collision.addCenteredBox(b.x, 1.6, b.z, 3.2, 3.2, 9.6);
  }

  const carMat = new THREE.MeshStandardMaterial({ roughness: 0.55, metalness: 0.45 });
  addInstances(group, new THREE.BoxGeometry(2.0, 0.85, 4.3), carMat, carChassis);
  addInstances(group, new THREE.BoxGeometry(1.75, 0.68, 2.2), carMat, carCabins);
  addInstances(group, new THREE.BoxGeometry(2.7, 2.8, 9.4), carMat, busBodies);

  // Concrete Jersey Roadblocks around Central Plaza Approach
  for (let bx = -22; bx <= 22; bx += 5.5) {
    if (Math.abs(bx) < 8) continue;
    barrierItems.push({ x: bx, y: 0.55, z: -36, ry: 0 });
    barrierItems.push({ x: bx, y: 0.55, z: 36, ry: 0 });
    collision.addCenteredBox(bx, 0.6, -36, 3.4, 1.2, 0.9);
    collision.addCenteredBox(bx, 0.6, 36, 3.4, 1.2, 0.9);
  }
  addInstances(group, new THREE.BoxGeometry(3.2, 1.1, 0.8), trimLightMat, barrierItems);

  // Red Aviation Warning Beacons on Tall Skyscrapers
  addInstances(
    group,
    new THREE.SphereGeometry(0.45, 6, 6),
    new THREE.MeshBasicMaterial({ color: 0xff2222 }),
    beaconBoxes
  );

  // =========================================================================
  // 8. OUTER METROPOLITAN SKYLINE BACKDROP RING (±195m..±260m)
  // =========================================================================
  const outerRing: InstanceTransform[] = [];
  for (let i = 0; i < 36; i++) {
    const angle = (i / 36) * Math.PI * 2;
    const rad = 205 + (i % 3) * 24;
    const x = Math.cos(angle) * rad;
    const z = Math.sin(angle) * rad;
    const h = 48 + ((i * 29) % 75);
    outerRing.push({ x, y: h * 0.5, z, sx: 22, sy: h, sz: 22 });
  }
  addInstances(group, new THREE.BoxGeometry(1, 1, 1), concreteTowerMat, outerRing);

  return { group, zones };
}
