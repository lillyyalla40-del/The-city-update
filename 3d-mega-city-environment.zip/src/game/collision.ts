import * as THREE from 'three';

export interface SolidBox {
  id?: string;
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
  enabled: boolean;
  blocksCamera: boolean;
}

export interface WalkableSurface {
  id?: string;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  // Flat height or sloped along Z or X
  yStart: number;
  yEnd: number;
  slopeAxis?: 'z' | 'x';
  enabled: boolean;
}

const CELL_SIZE = 16;

export class CollisionWorld {
  private solids: SolidBox[] = [];
  private grid = new Map<string, SolidBox[]>();
  private surfaces: WalkableSurface[] = [];
  private surfaceGrid = new Map<string, WalkableSurface[]>();

  private key(cx: number, cz: number): string {
    return `${cx},${cz}`;
  }

  addSolid(box: Omit<SolidBox, 'enabled' | 'blocksCamera'> & { enabled?: boolean; blocksCamera?: boolean }): SolidBox {
    const entry: SolidBox = {
      ...box,
      enabled: box.enabled ?? true,
      blocksCamera: box.blocksCamera ?? true,
    };
    this.solids.push(entry);

    const minCx = Math.floor(entry.minX / CELL_SIZE);
    const maxCx = Math.floor(entry.maxX / CELL_SIZE);
    const minCz = Math.floor(entry.minZ / CELL_SIZE);
    const maxCz = Math.floor(entry.maxZ / CELL_SIZE);

    for (let cx = minCx; cx <= maxCx; cx++) {
      for (let cz = minCz; cz <= maxCz; cz++) {
        const k = this.key(cx, cz);
        let arr = this.grid.get(k);
        if (!arr) {
          arr = [];
          this.grid.set(k, arr);
        }
        arr.push(entry);
      }
    }
    return entry;
  }

  addCenteredBox(
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    opts?: { id?: string; enabled?: boolean; blocksCamera?: boolean }
  ): SolidBox {
    return this.addSolid({
      id: opts?.id,
      minX: x - w * 0.5,
      maxX: x + w * 0.5,
      minY: y - h * 0.5,
      maxY: y + h * 0.5,
      minZ: z - d * 0.5,
      maxZ: z + d * 0.5,
      enabled: opts?.enabled,
      blocksCamera: opts?.blocksCamera,
    });
  }

  addSurface(surface: Omit<WalkableSurface, 'enabled'> & { enabled?: boolean }): WalkableSurface {
    const entry: WalkableSurface = {
      ...surface,
      enabled: surface.enabled ?? true,
    };
    this.surfaces.push(entry);

    const minCx = Math.floor(entry.minX / CELL_SIZE);
    const maxCx = Math.floor(entry.maxX / CELL_SIZE);
    const minCz = Math.floor(entry.minZ / CELL_SIZE);
    const maxCz = Math.floor(entry.maxZ / CELL_SIZE);

    for (let cx = minCx; cx <= maxCx; cx++) {
      for (let cz = minCz; cz <= maxCz; cz++) {
        const k = this.key(cx, cz);
        let arr = this.surfaceGrid.get(k);
        if (!arr) {
          arr = [];
          this.surfaceGrid.set(k, arr);
        }
        arr.push(entry);
      }
    }
    return entry;
  }

  private querySolids(x: number, z: number, radius: number): SolidBox[] {
    const minCx = Math.floor((x - radius) / CELL_SIZE);
    const maxCx = Math.floor((x + radius) / CELL_SIZE);
    const minCz = Math.floor((z - radius) / CELL_SIZE);
    const maxCz = Math.floor((z + radius) / CELL_SIZE);

    const result: SolidBox[] = [];
    const seen = new Set<SolidBox>();
    for (let cx = minCx; cx <= maxCx; cx++) {
      for (let cz = minCz; cz <= maxCz; cz++) {
        const arr = this.grid.get(this.key(cx, cz));
        if (!arr) continue;
        for (let i = 0; i < arr.length; i++) {
          const b = arr[i];
          if (b.enabled && !seen.has(b)) {
            seen.add(b);
            result.push(b);
          }
        }
      }
    }
    return result;
  }

  /**
   * Computes the highest walkable surface at (x, z) that is at or below currentY + stepUp.
   * Ensures the player NEVER falls through floors or spawns under the ground.
   */
  getFloorHeight(x: number, z: number, currentY: number, stepUp = 0.75): number {
    const cx = Math.floor(x / CELL_SIZE);
    const cz = Math.floor(z / CELL_SIZE);
    const arr = this.surfaceGrid.get(this.key(cx, cz));

    let bestY = -999;
    const maxAllowed = currentY + stepUp;

    if (arr) {
      for (let i = 0; i < arr.length; i++) {
        const s = arr[i];
        if (!s.enabled) continue;
        if (x < s.minX || x > s.maxX || z < s.minZ || z > s.maxZ) continue;

        let y = s.yStart;
        if (s.slopeAxis === 'z') {
          const t = Math.max(0, Math.min(1, (z - s.minZ) / Math.max(0.001, s.maxZ - s.minZ)));
          y = s.yStart + (s.yEnd - s.yStart) * t;
        } else if (s.slopeAxis === 'x') {
          const t = Math.max(0, Math.min(1, (x - s.minX) / Math.max(0.001, s.maxX - s.minX)));
          y = s.yStart + (s.yEnd - s.yStart) * t;
        }

        if (y <= maxAllowed && y > bestY) {
          bestY = y;
        }
      }
    }

    // Fallback safety floor: bunker floor is -12, aboveground is 0.
    if (bestY < -100) {
      return currentY < -4 ? -12.0 : 0.0;
    }
    return bestY;
  }

  /**
   * Finds ceiling height directly above (x, y, z) to avoid jumping through bunker ceilings.
   */
  getCeilingHeight(x: number, y: number, z: number, radius = 0.35): number {
    const boxes = this.querySolids(x, z, radius);
    let ceiling = 999;
    for (let i = 0; i < boxes.length; i++) {
      const b = boxes[i];
      if (x + radius > b.minX && x - radius < b.maxX && z + radius > b.minZ && z - radius < b.maxZ) {
        if (b.minY >= y + 0.8 && b.minY < ceiling) {
          ceiling = b.minY;
        }
      }
    }
    return ceiling;
  }

  /**
   * Resolves horizontal circle-vs-AABB collision in XZ plane with smooth wall sliding.
   */
  resolveHorizontal(
    x: number,
    y: number,
    z: number,
    radius: number,
    height = 1.75
  ): { x: number; z: number } {
    let rx = x;
    let rz = z;
    const boxes = this.querySolids(rx, rz, radius + 1.5);
    const bodyBottom = y + 0.35; // allow stepping up small curbs/ramps smoothly
    const bodyTop = y + height;

    // Two iterations prevent corner snagging
    for (let iter = 0; iter < 2; iter++) {
      for (let i = 0; i < boxes.length; i++) {
        const b = boxes[i];
        if (!b.enabled) continue;
        // Vertical overlap check
        if (bodyTop <= b.minY || bodyBottom >= b.maxY) continue;

        const closestX = Math.max(b.minX, Math.min(rx, b.maxX));
        const closestZ = Math.max(b.minZ, Math.min(rz, b.maxZ));
        const dx = rx - closestX;
        const dz = rz - closestZ;
        const distSq = dx * dx + dz * dz;

        if (distSq < radius * radius) {
          if (distSq > 1e-6) {
            const dist = Math.sqrt(distSq);
            const push = radius - dist;
            rx += (dx / dist) * push;
            rz += (dz / dist) * push;
          } else {
            // Center is inside box: push out along shallowest axis
            const left = rx - b.minX;
            const right = b.maxX - rx;
            const front = rz - b.minZ;
            const back = b.maxZ - rz;
            const minPen = Math.min(left, right, front, back);
            if (minPen === left) rx = b.minX - radius;
            else if (minPen === right) rx = b.maxX + radius;
            else if (minPen === front) rz = b.minZ - radius;
            else rz = b.maxZ + radius;
          }
        }
      }
    }

    // Clamp to outer city playable boundary (-176..176)
    rx = Math.max(-176, Math.min(176, rx));
    rz = Math.max(-176, Math.min(176, rz));

    return { x: rx, z: rz };
  }

  /**
   * Ray/segment intersection against camera-blocking boxes so the 3rd person camera
   * pulls smoothly in front of buildings and bunker walls/ceilings instead of clipping inside.
   */
  clipCameraSegment(target: THREE.Vector3, desiredEye: THREE.Vector3, padding = 0.35): THREE.Vector3 {
    const dirX = desiredEye.x - target.x;
    const dirY = desiredEye.y - target.y;
    const dirZ = desiredEye.z - target.z;
    const totalLen = Math.sqrt(dirX * dirX + dirY * dirY + dirZ * dirZ);
    if (totalLen < 0.05) return desiredEye.clone();

    const midX = (target.x + desiredEye.x) * 0.5;
    const midZ = (target.z + desiredEye.z) * 0.5;
    const boxes = this.querySolids(midX, midZ, totalLen * 0.55 + 1.0);

    let closestT = 1.0;

    for (let i = 0; i < boxes.length; i++) {
      const b = boxes[i];
      if (!b.enabled || !b.blocksCamera) continue;

      // Slab intersection
      let tmin = 0.0;
      let tmax = closestT;

      const invX = Math.abs(dirX) > 1e-6 ? 1 / dirX : 1e9;
      let t1 = (b.minX - target.x) * invX;
      let t2 = (b.maxX - target.x) * invX;
      if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) continue;

      const invY = Math.abs(dirY) > 1e-6 ? 1 / dirY : 1e9;
      t1 = (b.minY - target.y) * invY;
      t2 = (b.maxY - target.y) * invY;
      if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) continue;

      const invZ = Math.abs(dirZ) > 1e-6 ? 1 / dirZ : 1e9;
      t1 = (b.minZ - target.z) * invZ;
      t2 = (b.maxZ - target.z) * invZ;
      if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) continue;

      if (tmin > 0.02 && tmin < closestT) {
        closestT = tmin;
      }
    }

    const safeDist = Math.max(0.4, closestT * totalLen - padding);
    const scale = safeDist / totalLen;
    return new THREE.Vector3(
      target.x + dirX * scale,
      target.y + dirY * scale,
      target.z + dirZ * scale
    );
  }
}
