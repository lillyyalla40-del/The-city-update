import * as THREE from 'three';
import { CollisionWorld, SolidBox, WalkableSurface } from './collision';
import { TexturePack, createSignTexture } from './textures';
import { HatchState } from './types';

export interface BunkerHatchController {
  group: THREE.Group;
  shaftGroup: THREE.Group;
  getState: () => HatchState;
  getProgress: () => number;
  toggle: () => void;
  setOpenImmediate: (open: boolean) => void;
  update: (dt: number, elapsed: number) => void;
  isNearControl: (x: number, y: number, z: number) => boolean;
}

export function createBunkerHatch(
  collision: CollisionWorld,
  textures: TexturePack
): BunkerHatchController {
  const group = new THREE.Group();
  group.name = 'CentralBunkerHatch';

  const shaftGroup = new THREE.Group();
  shaftGroup.name = 'CentralShaftAndRamp';

  // Materials
  const steelMat = new THREE.MeshStandardMaterial({
    map: textures.blastSteel,
    roughness: 0.48,
    metalness: 0.72,
  });

  const darkTrimMat = new THREE.MeshStandardMaterial({
    color: 0x22272e,
    roughness: 0.55,
    metalness: 0.8,
  });

  const hazardMat = new THREE.MeshStandardMaterial({
    map: textures.hazardStripes,
    roughness: 0.6,
    metalness: 0.3,
  });

  const concreteMat = new THREE.MeshStandardMaterial({
    map: textures.bunkerWall,
    roughness: 0.85,
    metalness: 0.1,
  });

  const beaconMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    emissive: new THREE.Color(0xf59e0b),
    emissiveIntensity: 1.2,
    roughness: 0.3,
  });

  const rampLightMat = new THREE.MeshStandardMaterial({
    color: 0xe2f1ff,
    emissive: new THREE.Color(0x9bd0ff),
    emissiveIntensity: 1.6,
    roughness: 0.2,
  });

  // 1. Concrete Blast Collar Flush around the 18m x 18m opening
  const collarHeight = 0.22;
  const collarY = 0.11;
  // West, East, South raised safety curbs (1.05m tall) so players enter cleanly from North (-Z)
  const curbMat = concreteMat;
  const westCurb = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.05, 19.6), curbMat);
  westCurb.position.set(-9.7, 0.52, 0);
  group.add(westCurb);
  collision.addCenteredBox(-9.7, 0.52, 0, 1.4, 1.05, 19.6);

  const eastCurb = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.05, 19.6), curbMat);
  eastCurb.position.set(9.7, 0.52, 0);
  group.add(eastCurb);
  collision.addCenteredBox(9.7, 0.52, 0, 1.4, 1.05, 19.6);

  const southCurb = new THREE.Mesh(new THREE.BoxGeometry(20.8, 1.05, 1.4), curbMat);
  southCurb.position.set(0, 0.52, 9.7);
  group.add(southCurb);
  collision.addCenteredBox(0, 0.52, 9.7, 20.8, 1.05, 1.4);

  // Hazard apron strips around collar
  const northApron = new THREE.Mesh(new THREE.BoxGeometry(18.6, collarHeight, 1.2), hazardMat);
  northApron.position.set(0, collarY, -9.6);
  group.add(northApron);

  // Recessed slide tracks on West and East plaza deck for doors to retract along
  for (const side of [-1, 1]) {
    for (const tz of [-6.5, 6.5]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(10.5, 0.14, 0.65), darkTrimMat);
      rail.position.set(side * 14.5, 0.18, tz);
      group.add(rail);
    }
  }

  // 2. Massive Dual Blast Door Leaves (each 9.05m wide x 18.0m long x 0.45m thick)
  const leftLeaf = new THREE.Group();
  const rightLeaf = new THREE.Group();

  const buildLeaf = (leaf: THREE.Group, side: -1 | 1) => {
    const slab = new THREE.Mesh(new THREE.BoxGeometry(9.05, 0.42, 18.0), steelMat);
    slab.position.set(side * 4.525, 0.0, 0);
    slab.castShadow = true;
    slab.receiveShadow = true;
    leaf.add(slab);

    // Structural armored I-beam ribs on top
    for (let z = -7; z <= 7; z += 3.5) {
      const rib = new THREE.Mesh(new THREE.BoxGeometry(8.5, 0.16, 0.48), darkTrimMat);
      rib.position.set(side * 4.5, 0.24, z);
      leaf.add(rib);
    }

    // Center interlocking hazard seam lip
    const seam = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.46, 17.8), hazardMat);
    seam.position.set(side * 0.23, 0.02, 0);
    leaf.add(seam);

    // Hydraulic locking bolts
    for (const bz of [-5.5, 0, 5.5]) {
      const bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.6, 8), darkTrimMat);
      bolt.rotation.z = Math.PI * 0.5;
      bolt.position.set(side * 0.4, 0.22, bz);
      leaf.add(bolt);
    }
  };

  buildLeaf(leftLeaf, -1);
  buildLeaf(rightLeaf, 1);
  leftLeaf.position.set(0, 0.04, 0);
  rightLeaf.position.set(0, 0.04, 0);
  group.add(leftLeaf);
  group.add(rightLeaf);

  // 3. Hydraulic Cylinders & Warning Beacons
  const pistons: { mesh: THREE.Mesh; side: -1 | 1; z: number }[] = [];
  for (const side of [-1, 1] as const) {
    for (const z of [-6.5, 6.5]) {
      const housing = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.7, 1.1), darkTrimMat);
      housing.position.set(side * 10.6, 0.5, z);
      group.add(housing);

      const piston = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 2.2, 8), steelMat);
      piston.rotation.z = Math.PI * 0.5;
      piston.position.set(side * 9.5, 0.46, z);
      group.add(piston);
      pistons.push({ mesh: piston, side, z });
    }
  }

  // Warning Beacon Towers on North corners of the hatch
  const beaconMeshes: THREE.Mesh[] = [];
  for (const bx of [-10.2, 10.2]) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.24, 2.2, 8), darkTrimMat);
    post.position.set(bx, 1.1, -9.8);
    group.add(post);

    const lamp = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.42, 10), beaconMat);
    lamp.position.set(bx, 2.3, -9.8);
    group.add(lamp);
    beaconMeshes.push(lamp);
  }

  // Control Terminal Console on NW corner of Plaza Hatch
  const terminalGroup = new THREE.Group();
  terminalGroup.position.set(-11.4, 0.15, -10.8);
  const ped = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.35, 0.8), darkTrimMat);
  ped.position.y = 0.675;
  terminalGroup.add(ped);
  const screenMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: new THREE.Color(0x0284c7),
    emissiveIntensity: 1.4,
  });
  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.48, 0.1), screenMat);
  screen.position.set(0, 1.25, 0.36);
  screen.rotation.x = -0.35;
  terminalGroup.add(screen);
  group.add(terminalGroup);
  collision.addCenteredBox(-11.4, 0.85, -10.8, 1.2, 1.5, 0.9);

  // Monumental Bunker Portal Sign on South curb facing incoming explorers
  const signTex = createSignTexture('SECTOR 00 // CENTRAL BUNKER HATCH', 'AUTHORIZED SURVIVOR ACCESS', '#f59e0b');
  const signMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(8.5, 2.4),
    new THREE.MeshBasicMaterial({ map: signTex })
  );
  signMesh.position.set(0, 2.4, 10.45);
  signMesh.rotation.y = Math.PI;
  group.add(signMesh);

  const signFrame = new THREE.Mesh(new THREE.BoxGeometry(8.9, 2.7, 0.35), darkTrimMat);
  signFrame.position.set(0, 2.4, 10.65);
  group.add(signFrame);
  for (const sx of [-3.6, 3.6]) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.4, 2.4, 0.4), darkTrimMat);
    leg.position.set(sx, 1.2, 10.65);
    group.add(leg);
  }

  // 4. Hatch Deck Collision (active when closed, disabled when open)
  const hatchDeckSurface: WalkableSurface = collision.addSurface({
    id: 'hatch_deck_surface',
    minX: -9.1,
    maxX: 9.1,
    minZ: -9.1,
    maxZ: 9.1,
    yStart: 0.24,
    yEnd: 0.24,
    enabled: true,
  });

  const hatchDeckSolid: SolidBox = collision.addSolid({
    id: 'hatch_deck_solid',
    minX: -9.0,
    maxX: 9.0,
    minY: -0.4,
    maxY: 0.24,
    minZ: -9.0,
    maxZ: 9.0,
    enabled: true,
    blocksCamera: true,
  });

  // 5. Descending Concrete Ramp & Underground Shaft Tunnel (Z = -8.5 -> +28, Y = 0.15 -> -12.0)
  const rampLen = 36.5; // Z: -8.5 to 28.0
  const dropY = 12.15;  // 0.15 down to -12.0
  const horizLen = rampLen;
  const hypLen = Math.sqrt(horizLen * horizLen + dropY * dropY);
  const pitchAngle = Math.atan2(dropY, horizLen);

  const rampSlab = new THREE.Mesh(new THREE.BoxGeometry(16.0, 0.7, hypLen + 0.5), concreteMat);
  rampSlab.position.set(0, (0.15 - 12.0) * 0.5 - 0.32, (-8.5 + 28.0) * 0.5);
  rampSlab.rotation.x = pitchAngle;
  rampSlab.receiveShadow = true;
  shaftGroup.add(rampSlab);

  // Walkable surface for the descending ramp (always enabled underneath!)
  collision.addSurface({
    id: 'bunker_entry_ramp',
    minX: -8.0,
    maxX: 8.0,
    minZ: -8.6,
    maxZ: 28.2,
    yStart: 0.15,
    yEnd: -12.0,
    slopeAxis: 'z',
    enabled: true,
  });

  // Ramp side concrete walls enclosing the shaft from Y=0.2 down to Y=-12.5
  const shaftWallLeft = new THREE.Mesh(new THREE.BoxGeometry(1.2, 13.0, 38.0), concreteMat);
  shaftWallLeft.position.set(-8.6, -6.2, 10.0);
  shaftGroup.add(shaftWallLeft);
  collision.addCenteredBox(-8.6, -6.2, 10.0, 1.2, 13.0, 38.0);

  const shaftWallRight = new THREE.Mesh(new THREE.BoxGeometry(1.2, 13.0, 38.0), concreteMat);
  shaftWallRight.position.set(8.6, -6.2, 10.0);
  shaftGroup.add(shaftWallRight);
  collision.addCenteredBox(8.6, -6.2, 10.0, 1.2, 13.0, 38.0);

  // Back wall behind top of ramp under Z = -9.2 down to -12 (separates ramp void from north bunker space)
  const shaftBackWall = new THREE.Mesh(new THREE.BoxGeometry(18.4, 12.6, 1.2), concreteMat);
  shaftBackWall.position.set(0, -6.1, -9.4);
  shaftGroup.add(shaftBackWall);
  collision.addCenteredBox(0, -6.1, -9.4, 18.4, 12.6, 1.2);

  // Sloped ceiling above the covered lower half of the ramp (Z = 9.5 to 28.5)
  const tunnelCeiling = new THREE.Mesh(new THREE.BoxGeometry(18.4, 0.8, 20.0), concreteMat);
  tunnelCeiling.position.set(0, -1.8, 19.0);
  tunnelCeiling.rotation.x = 0.18;
  shaftGroup.add(tunnelCeiling);
  collision.addCenteredBox(0, -1.8, 19.0, 18.4, 1.2, 20.0);

  // Glowing strip lights & handrails along the ramp walls
  for (let i = 0; i < 6; i++) {
    const t = i / 5;
    const z = -5 + t * 30;
    const y = 0.15 - t * 11.2;
    for (const side of [-1, 1]) {
      const strip = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.22, 2.2), rampLightMat);
      strip.position.set(side * 7.85, y + 2.1, z);
      strip.rotation.x = pitchAngle;
      shaftGroup.add(strip);
    }
  }

  // Sub-level hatch control console at bottom of ramp
  const subConsole = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.35, 0.8), darkTrimMat);
  subConsole.position.set(-9.6, -11.32, 27.5);
  shaftGroup.add(subConsole);
  const subScreen = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.48, 0.1), screenMat);
  subScreen.position.set(-9.6, -10.8, 27.85);
  shaftGroup.add(subScreen);
  collision.addCenteredBox(-9.6, -11.3, 27.5, 1.2, 1.5, 0.9);

  // State machine
  let state: HatchState = 'closed';
  let progress = 0; // 0 = closed, 1 = fully open

  const applyProgress = (p: number) => {
    // Leaves slide smoothly outward 9.4m and rise 0.25m onto the side tracks
    const slide = p * 9.6;
    const lift = Math.sin(Math.min(1, p * 2.5) * Math.PI * 0.5) * 0.28;
    leftLeaf.position.set(-slide, 0.04 + lift, 0);
    rightLeaf.position.set(slide, 0.04 + lift, 0);

    for (const pit of pistons) {
      pit.mesh.position.x = pit.side * (9.5 + slide * 0.25);
    }

    // Collision switches cleanly once hatch is > 72% open
    const isPassable = p >= 0.72;
    hatchDeckSurface.enabled = !isPassable;
    hatchDeckSolid.enabled = !isPassable;
  };

  const setOpenImmediate = (open: boolean) => {
    progress = open ? 1 : 0;
    state = open ? 'open' : 'closed';
    applyProgress(progress);
  };

  const toggle = () => {
    if (state === 'closed' || state === 'closing') {
      state = 'opening';
    } else {
      state = 'closing';
    }
  };

  const update = (dt: number, elapsed: number) => {
    const speed = 0.42; // ~2.4 seconds full hydraulic cycle
    if (state === 'opening') {
      progress = Math.min(1, progress + dt * speed);
      applyProgress(progress);
      if (progress >= 1) state = 'open';
    } else if (state === 'closing') {
      progress = Math.max(0, progress - dt * speed);
      applyProgress(progress);
      if (progress <= 0) state = 'closed';
    }

    // Pulse beacons when moving or open
    if (state === 'opening' || state === 'closing') {
      const pulse = 0.6 + Math.abs(Math.sin(elapsed * 9.0)) * 2.4;
      beaconMat.emissiveIntensity = pulse;
      beaconMat.color.setHex(0xff5500);
      beaconMat.emissive.setHex(0xff5500);
    } else if (state === 'open') {
      beaconMat.emissiveIntensity = 1.4;
      beaconMat.color.setHex(0x22c55e);
      beaconMat.emissive.setHex(0x22c55e);
    } else {
      beaconMat.emissiveIntensity = 0.9 + Math.sin(elapsed * 2.0) * 0.3;
      beaconMat.color.setHex(0xf59e0b);
      beaconMat.emissive.setHex(0xf59e0b);
    }
  };

  const isNearControl = (x: number, y: number, z: number): boolean => {
    // Near surface plaza hatch or terminal
    if (y > -3.5) {
      const distCenter = Math.hypot(x, z);
      const distTerminal = Math.hypot(x - -11.4, z - -10.8);
      return distCenter < 17.5 || distTerminal < 5.0;
    }
    // Near sub-level ramp console
    const distSub = Math.hypot(x - -9.6, z - 27.5);
    return distSub < 6.0 || (Math.abs(x) < 9.5 && z > -9 && z < 30);
  };

  applyProgress(0);

  return {
    group,
    shaftGroup,
    getState: () => state,
    getProgress: () => progress,
    toggle,
    setOpenImmediate,
    update,
    isNearControl,
  };
}
