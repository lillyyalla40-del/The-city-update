import { SECTORS } from '../facility';
import { CollisionWorld } from './collision';
import { FacilityKit, FLOOR } from './facilityKit';
import { centralHall, partition, shell, wall, type Gate } from './architecture';
import { cafeteria, command, engineering, habitat, medical, storage } from './sectorInteriors';
import { buildAcademy } from './academy';
import type { ZoneDefinition } from './types';
import { serviceFitout } from './serviceFitout';
import { worldAudio } from '../ambience';

export function buildUndergroundBunker(collision: CollisionWorld) {
  const k = new FacilityKit(collision);
  const gates: Gate[] = [];
  for (const s of SECTORS) {
    k.sector = s.id;
    shell(k, s);
  }
  k.sector = 'structure';
  wall(k, 0, -104.3, 209, 0.65, 10.9);
  wall(k, 0, 104.3, 209, 0.65, 10.9);
  wall(k, -104.3, 0, 0.65, 208.6, 10.9);
  wall(k, 104.3, 0, 0.65, 208.6, 10.9);
  const split = (
    x1: number,
    z1: number,
    x2: number,
    z2: number,
    door: number,
    w: number,
    sector: number,
    reverse?: string,
  ) => {
    const s = SECTORS[sector];
    partition(
      k,
      gates,
      x1,
      z1,
      x2,
      z2,
      door,
      w,
      reverse || s.name,
      'SEC ' + s.number,
      s.color,
      sector === 0 ? 10.9 : 6.5,
    );
  };
  split(-24, -24, -24, 66, 37.5, 5.4, 1);
  split(24, -24, 24, 66, 44, 6.4, 3);
  split(-24, 66, 24, 66, 0, 6, 4);
  split(-104, 66, -24, 66, -65, 6.2, 5);
  split(24, 66, 104, 66, 60, 6.5, 9);
  split(-24, 66, -24, 104, 70, 4.7, 5);
  split(24, 66, 24, 104, 69.7, 4.4, 9);
  split(-104, -24, -24, -24, -76.5, 5.6, 2);
  split(-24, -24, 24, -24, 16, 5.8, 2);
  split(24, -24, 104, -24, 61, 6.3, 8);
  split(24, -60, 64, -60, 43.5, 6, 7);
  split(64, -60, 104, -60, 70.5, 6, 6);
  split(64, -104, 64, -60, -85, 5.2, 6);
  split(24, -104, 24, -60, -83, 5.6, 7);
  split(24, -60, 24, -24, -60 + 4.7, 5.2, 8);
  k.sector = 'concourse';
  const lift = centralHall(k);
  k.sector = 'medical';
  medical(k);
  k.sector = 'education';
  buildAcademy(k);
  k.sector = 'habitat';
  habitat(k);
  k.sector = 'cafeteria';
  cafeteria(k);
  k.sector = 'command';
  command(k);
  k.sector = 'auto';
  engineering(k);
  k.sector = 'storage';
  storage(k);
  serviceFitout(k);
  k.finish();
  const zones: ZoneDefinition[] = [
    {
      id: 'bunker_shaft',
      name: 'Central access shaft',
      subtitle: 'Surface connection',
      environment: 'shaft',
      minX: -9,
      maxX: 9,
      minZ: -9,
      maxZ: 28.3,
      minY: -12.2,
      maxY: -0.2,
      color: '#e59768',
    },
    ...SECTORS.map((s) => ({
      id: s.id,
      name: s.name,
      subtitle: s.category,
      environment: 'bunker' as const,
      minX: s.bounds[0],
      maxX: s.bounds[1],
      minZ: s.bounds[2],
      maxZ: s.bounds[3],
      minY: -13,
      maxY: -0.3,
      color: s.color,
    })),
  ];
  let timer = 1,
    lastX = Infinity,
    lastZ = Infinity;
  const doorDirections = new WeakMap<Gate, number>();
  return {
    group: k.group,
    zones,
    setDetail: (mobile: boolean) => k.detail(mobile),
    dispose: () => k.dispose(),
    update(dt: number, x: number, z: number, y: number, mobile: boolean) {
      timer += dt;
      if (timer > 0.16 || Math.abs(x - lastX) + Math.abs(z - lastZ) > 4) {
        const active = SECTORS.find(
          (s) => x >= s.bounds[0] && x <= s.bounds[1] && z >= s.bounds[2] && z <= s.bounds[3],
        );
        const visible = new Set([active?.id || 'concourse']);
        for (const g of gates) {
          const near = Math.hypot(x - g.x, z - g.z) < 10;
          if (near)
            for (const s of SECTORS)
              if (
                g.x >= s.bounds[0] - 1 &&
                g.x <= s.bounds[1] + 1 &&
                g.z >= s.bounds[2] - 1 &&
                g.z <= s.bounds[3] + 1
              )
                visible.add(s.id);
          const a = active?.bounds;
          g.leaves[0].parent!.visible =
            !!a && g.x >= a[0] - 0.6 && g.x <= a[1] + 0.6 && g.z >= a[2] - 0.6 && g.z <= a[3] + 0.6;
        }
        k.cull(x, z, mobile, visible);
        timer = 0;
        lastX = x;
        lastZ = z;
      }
      for (const g of gates) {
        const dist = Math.hypot(x - g.x, z - g.z),
          target = dist < 7.8 ? 1 : dist > 9.5 ? 0 : g.progress;
        if (target === g.progress) continue;
        const direction = Math.sign(target - g.progress);
        if (doorDirections.get(g) !== direction) {
          doorDirections.set(g, direction);
          if (dist < 18) worldAudio.cue(direction > 0 ? 'door-open' : 'door-close', g.x, FLOOR + 1.5, g.z);
        }
        g.progress += Math.sign(target - g.progress) * Math.min(Math.abs(target - g.progress), dt * 1.25);
        const smooth = g.progress * g.progress * (3 - 2 * g.progress);
        g.leaves[0].position.x = -g.width / 4 - smooth * (g.width / 2 + 0.08);
        g.leaves[1].position.x = g.width / 4 + smooth * (g.width / 2 + 0.08);
        g.collider.enabled = g.progress < 0.87;
      }
      if (lift.height !== lift.target) {
        lift.height +=
          Math.sign(lift.target - lift.height) * Math.min(dt * 1.25, Math.abs(lift.target - lift.height));
        lift.platform.position.y = lift.height;
        lift.surface.yStart = lift.surface.yEnd = FLOOR + lift.height;
        if (lift.height === lift.target) worldAudio.cue('arrival', lift.x, FLOOR + lift.height + 1.2, lift.z);
      }
      return (
        Math.abs(x - lift.x) < 1.42 && Math.abs(z - lift.z) < 1.58 && Math.abs(y - FLOOR - lift.height) < 0.65
      );
    },
    liftPrompt(x: number, y: number, z: number) {
      if (Math.abs(x - lift.x) > 2.2 || Math.abs(z - lift.z) > 2.35 || y > -5) return null;
      if (Math.abs(lift.height - lift.target) > 0.02) return 'Lift in transit';
      if (Math.abs(y - FLOOR - lift.height) > 0.8) return 'Call passenger lift';
      return lift.height < 1 ? 'Ride to upper gallery' : 'Ride to concourse';
    },
    useLift(x: number, y: number, z: number) {
      if (
        Math.abs(x - lift.x) > 2.2 ||
        Math.abs(z - lift.z) > 2.35 ||
        y > -5 ||
        Math.abs(lift.height - lift.target) > 0.02
      )
        return false;
      if (Math.abs(y - FLOOR - lift.height) > 0.8) lift.target = y - FLOOR > 2.3 ? 4.42 : 0;
      else lift.target = lift.height < 1 ? 4.42 : 0;
      worldAudio.cue('lift', lift.x, FLOOR + lift.height + 1.1, lift.z);
      return true;
    },
  };
}
