import * as THREE from 'three';
import { CollisionWorld } from './collision';
import { PlayerInputState } from './types';

export class ThirdPersonPlayer {
  public readonly group = new THREE.Group();
  public readonly position = new THREE.Vector3(0, 0.15, -24);
  public yaw = Math.PI; // Facing +Z toward the Central Bunker Hatch at (0,0,0)
  public pitch = 0.28; // Slight downward look angle
  public cameraDistance = 6.2;
  public flashlightOn = false;
  public firstPerson = false;

  private velocityY = 0;
  private grounded = true;
  private charYaw = Math.PI;
  private walkCycle = 0;
  private isMovingFlag = false;
  private isSprintingFlag = false;

  // Articulated limbs for walk/run animation
  private leftLeg: THREE.Group;
  private rightLeg: THREE.Group;
  private leftArm: THREE.Group;
  private rightArm: THREE.Group;
  private bodyGroup: THREE.Group;
  private headlamp: THREE.SpotLight;
  private headlampTarget = new THREE.Object3D();

  // Pre-allocated scratch vectors (zero GC in game loop!)
  private readonly camTarget = new THREE.Vector3();
  private readonly desiredEye = new THREE.Vector3();

  constructor(
    private readonly collision: CollisionWorld,
    scene: THREE.Scene,
  ) {
    this.group.name = 'SurvivorPlayer';

    const jacketMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.75 });
    const pantsMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.85 });
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xd4a383, roughness: 0.7 });
    const gearMat = new THREE.MeshStandardMaterial({ color: 0x4b5320, roughness: 0.8 });
    const bootMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.9 });
    const visorMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });

    this.bodyGroup = new THREE.Group();
    this.group.add(this.bodyGroup);

    // Legs (pivot at hip y = 0.88)
    const makeLeg = (xOffset: number) => {
      const legPivot = new THREE.Group();
      legPivot.position.set(xOffset, 0.88, 0);
      const thigh = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.72, 0.24), pantsMat);
      thigh.position.y = -0.36;
      legPivot.add(thigh);
      const boot = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.22, 0.32), bootMat);
      boot.position.set(0, -0.77, 0.04);
      legPivot.add(boot);
      return legPivot;
    };

    this.leftLeg = makeLeg(-0.14);
    this.rightLeg = makeLeg(0.14);
    this.bodyGroup.add(this.leftLeg, this.rightLeg);

    // Torso & Survival Backpack
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.64, 0.3), jacketMat);
    torso.position.y = 1.2;
    this.bodyGroup.add(torso);

    const backpack = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.5, 0.22), gearMat);
    backpack.position.set(0, 1.22, -0.24);
    this.bodyGroup.add(backpack);

    // Arms (pivot at shoulder y = 1.46)
    const makeArm = (xOffset: number) => {
      const armPivot = new THREE.Group();
      armPivot.position.set(xOffset, 1.46, 0);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.58, 0.18), jacketMat);
      arm.position.y = -0.26;
      armPivot.add(arm);
      const hand = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.15), skinMat);
      hand.position.y = -0.58;
      armPivot.add(hand);
      return armPivot;
    };

    this.leftArm = makeArm(-0.35);
    this.rightArm = makeArm(0.35);
    this.bodyGroup.add(this.leftArm, this.rightArm);

    // Head & Tactical Cap
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.3, 0.28), skinMat);
    head.position.y = 1.69;
    this.bodyGroup.add(head);

    const helmet = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.15, 0.33), gearMat);
    helmet.position.set(0, 1.81, 0.01);
    this.bodyGroup.add(helmet);

    const lampNode = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.07, 0.08), visorMat);
    lampNode.position.set(0, 1.8, 0.17);
    this.bodyGroup.add(lampNode);

    // Tactical Headlamp SpotLight
    this.headlamp = new THREE.SpotLight(0xe0f2fe, 0, 42, Math.PI * 0.28, 0.55, 1.2);
    this.headlamp.position.set(0, 1.8, 0.22);
    this.bodyGroup.add(this.headlamp);
    this.bodyGroup.add(this.headlampTarget);
    this.headlampTarget.position.set(0, 1.35, 10);
    this.headlamp.target = this.headlampTarget;

    // Snap cleanly to exact spawn floor height
    const spawnFloor = this.collision.getFloorHeight(this.position.x, this.position.z, 2.0, 2.0);
    this.position.y = spawnFloor;
    this.group.position.copy(this.position);
    this.bodyGroup.rotation.y = this.charYaw;

    scene.add(this.group);
  }

  public addLookDelta(dx: number, dy: number) {
    // Dragging right (dx > 0) pans camera right (yaw decreases)
    this.yaw -= dx;
    this.pitch = Math.max(this.firstPerson ? -1.28 : -0.42, Math.min(1.18, this.pitch + dy));
  }

  public setPerspective(firstPerson: boolean, camera: THREE.PerspectiveCamera) {
    this.firstPerson = firstPerson;
    this.bodyGroup.traverse((o) => {
      if (o instanceof THREE.Mesh) o.visible = !firstPerson;
    });
    this.pitch = firstPerson ? -0.065 : 0.16;
    this.snapCamera(camera);
  }

  public setFlashlight(on: boolean) {
    this.flashlightOn = on;
    this.headlamp.intensity = on ? 11 : 0;
  }

  public snapCamera(camera: THREE.PerspectiveCamera) {
    if (this.firstPerson) {
      camera.position.set(this.position.x, this.position.y + 1.69, this.position.z);
      camera.rotation.order = 'YXZ';
      camera.rotation.set(-this.pitch, this.yaw, 0);
      return;
    }
    const sinY = Math.sin(this.yaw);
    const cosY = Math.cos(this.yaw);
    const forwardX = -sinY;
    const forwardZ = -cosY;
    this.camTarget.set(this.position.x, this.position.y + 1.65, this.position.z);
    const cosP = Math.cos(this.pitch);
    const sinP = Math.sin(this.pitch);
    this.desiredEye.set(
      this.camTarget.x - forwardX * this.cameraDistance * cosP,
      this.camTarget.y + this.cameraDistance * sinP,
      this.camTarget.z - forwardZ * this.cameraDistance * cosP,
    );
    const safeEye = this.collision.clipCameraSegment(this.camTarget, this.desiredEye, 0.42);
    camera.position.copy(safeEye);
    camera.lookAt(this.camTarget);
  }

  public teleport(x: number, y: number, z: number, yaw?: number, camera?: THREE.PerspectiveCamera) {
    const floor = this.collision.getFloorHeight(x, z, y + 1.2, 2.0);
    this.position.set(x, Math.max(y, floor), z);
    this.velocityY = 0;
    this.grounded = true;
    if (yaw !== undefined) {
      this.yaw = yaw;
      this.charYaw = yaw;
    }
    this.group.position.copy(this.position);
    this.bodyGroup.rotation.y = this.charYaw;
    if (camera) {
      this.snapCamera(camera);
    }
  }

  public get isMoving() {
    return this.isMovingFlag;
  }

  public get isSprinting() {
    return this.isSprintingFlag;
  }

  public update(dt: number, input: PlayerInputState, camera: THREE.PerspectiveCamera) {
    // Clamp dt strictly so low frame spikes never cause physics tunneling!
    const safeDt = Math.min(dt, 0.05);

    // Forward & Right unit vectors on XZ plane derived cleanly from camera yaw
    const sinY = Math.sin(this.yaw);
    const cosY = Math.cos(this.yaw);
    const forwardX = -sinY;
    const forwardZ = -cosY;
    const rightX = cosY;
    const rightZ = -sinY;

    // Combine normalized joystick/keyboard input
    let inX = input.moveX;
    let inY = input.moveY;
    const mag = Math.hypot(inX, inY);
    if (mag > 1) {
      inX /= mag;
      inY /= mag;
    }

    const moving = mag > 0.06;
    this.isMovingFlag = moving;
    this.isSprintingFlag = moving && input.sprint;

    if (moving) {
      const wishX = rightX * inX + forwardX * inY;
      const wishZ = rightZ * inX + forwardZ * inY;
      const speed = (input.sprint ? 12.2 : 6.6) * Math.min(1, mag);

      const nextX = this.position.x + wishX * speed * safeDt;
      const nextZ = this.position.z + wishZ * speed * safeDt;

      // Sub-step horizontal collision for fast sprints
      const resolved = this.collision.resolveHorizontal(nextX, this.position.y, nextZ, 0.42, 1.75);
      this.position.x = resolved.x;
      this.position.z = resolved.z;

      // Smooth shortest-angle rotation toward movement direction (ZERO teleporting/snapping)
      const targetAngle = Math.atan2(wishX, wishZ);
      let diff = targetAngle - this.charYaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.charYaw += diff * Math.min(1, safeDt * 13);

      this.walkCycle += safeDt * (input.sprint ? 13 : 8.5);
    } else {
      this.walkCycle = 0;
    }

    // Jump & Gravity
    if (input.jumpRequested && this.grounded) {
      this.velocityY = 7.4;
      this.grounded = false;
    }

    this.velocityY -= 21.0 * safeDt;
    const nextY = this.position.y + this.velocityY * safeDt;

    // Ceiling check inside bunker / under highway
    const ceilY = this.collision.getCeilingHeight(this.position.x, this.position.y, this.position.z);
    if (nextY + 1.85 > ceilY && this.velocityY > 0) {
      this.velocityY = 0;
    }

    // Floor support check
    const floorY = this.collision.getFloorHeight(this.position.x, this.position.z, this.position.y, 0.85);
    if (nextY <= floorY) {
      this.position.y = floorY;
      this.velocityY = 0;
      this.grounded = true;
    } else {
      this.position.y = nextY;
      this.grounded = false;
    }

    // Safety fail-safe clamp: never drop into void below bunker
    if (this.position.y < -14.5) {
      this.position.y = -12.0;
      this.velocityY = 0;
      this.grounded = true;
    }

    // Sync mesh transforms
    this.group.position.copy(this.position);
    this.bodyGroup.rotation.y = this.charYaw;

    // Limb animation
    const swing = moving ? Math.sin(this.walkCycle) * (input.sprint ? 0.72 : 0.48) : 0;
    this.leftLeg.rotation.x = swing;
    this.rightLeg.rotation.x = -swing;
    this.leftArm.rotation.x = -swing * 0.75;
    this.rightArm.rotation.x = swing * 0.75;

    if (this.firstPerson) {
      this.snapCamera(camera);
      this.bodyGroup.rotation.y = this.yaw + Math.PI;
      this.headlampTarget.position.y = 1.8 - Math.tan(this.pitch) * 10;
      return;
    }

    // Third-person over-shoulder camera orbit with collision clipping
    this.camTarget.set(this.position.x, this.position.y + 1.65, this.position.z);
    const cosP = Math.cos(this.pitch);
    const sinP = Math.sin(this.pitch);
    this.desiredEye.set(
      this.camTarget.x - forwardX * this.cameraDistance * cosP,
      this.camTarget.y + this.cameraDistance * sinP,
      this.camTarget.z - forwardZ * this.cameraDistance * cosP,
    );

    const safeEye = this.collision.clipCameraSegment(this.camTarget, this.desiredEye, 0.42);
    camera.position.lerp(safeEye, Math.min(1, safeDt * 18));
    camera.lookAt(this.camTarget);
  }
}
