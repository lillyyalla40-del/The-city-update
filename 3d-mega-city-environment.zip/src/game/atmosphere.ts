import * as T from 'three';
import type { QualityPreset } from './types';
import { worldAudio } from '../ambience';
type Anchor = { x: number; y: number; z: number; heading?: number };
type Sheet = {
  mesh: T.Sprite;
  type: 'smoke' | 'steam' | 'glow';
  p: Anchor;
  phase: number;
  size: number;
  sector: string;
};

function spriteMap(cloud = false) {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const ctx = c.getContext('2d')!;
  if (cloud) {
    for (let i = 0; i < 9; i++) {
      const x = 27 + Math.sin(i * 2.4) * 12,
        y = 30 + Math.cos(i * 2.4) * 10;
      const g = ctx.createRadialGradient(x, y, 0, x, y, 19);
      g.addColorStop(0, 'rgba(255,255,255,.28)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 64, 64);
    }
  } else {
    const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, '#fff');
    g.addColorStop(0.11, 'rgba(255,255,255,.73)');
    g.addColorStop(0.32, 'rgba(255,255,255,.16)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 64, 64);
  }
  return new T.CanvasTexture(c);
}

export class Atmosphere {
  readonly group = new T.Group();
  enabled = true;
  quality: QualityPreset;
  private particle: T.Points;
  private buffer = new Float32Array(78 * 3);
  private seeds = new Float32Array(78 * 4);
  private sheets: Sheet[] = [];
  private leaves: T.InstancedMesh;
  private scratch = new T.Object3D();
  private sparks: T.LineSegments;
  private sparkData = new Float32Array(10 * 6);
  private flareTime = 0;
  private nextSpark = 5;
  private shafts: T.Mesh[] = [];
  private pinLights: T.InstancedMesh;
  private glows: T.InstancedMesh;
  private glowPositions: Anchor[];
  private glowTexture = spriteMap();
  private cloudTexture = spriteMap(true);
  private clock = 0;
  private vehicleBeam = new T.SpotLight(0xffe6b7, 36, 22, 0.33, 0.67, 1.65);
  private vehicles: Anchor[];
  constructor(scene: T.Scene, lamps: Anchor[], cars: Anchor[], stack: Anchor, quality: QualityPreset) {
    this.quality = quality;
    this.group.name = 'Environment / pooled light and air';
    scene.add(this.group);
    this.vehicles = cars;
    this.vehicleBeam.castShadow = false;
    this.group.add(this.vehicleBeam, this.vehicleBeam.target);
    for (let i = 0; i < this.seeds.length; i++) this.seeds[i] = ((i * 64879 + 13921) % 100019) / 100019;
    const g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(this.buffer, 3).setUsage(T.DynamicDrawUsage));
    this.particle = new T.Points(
      g,
      new T.PointsMaterial({
        size: 0.035,
        map: this.glowTexture,
        transparent: true,
        opacity: 0.31,
        color: '#f4e0b7',
        depthWrite: false,
        sizeAttenuation: true,
      }),
    );
    this.particle.frustumCulled = false;
    this.group.add(this.particle);
    this.leaves = new T.InstancedMesh(
      new T.PlaneGeometry(0.17, 0.1),
      new T.MeshLambertMaterial({ color: '#ab8c61', side: T.DoubleSide }),
      8,
    );
    this.leaves.instanceMatrix.setUsage(T.DynamicDrawUsage);
    this.leaves.frustumCulled = false;
    this.group.add(this.leaves);
    const add = (type: Sheet['type'], p: Anchor, size: number, sector: string, n: number) => {
      for (let i = 0; i < n; i++) {
        const m = new T.Sprite(
          new T.SpriteMaterial({
            map: type === 'glow' ? this.glowTexture : this.cloudTexture,
            transparent: true,
            color: type === 'smoke' ? '#918f89' : type === 'steam' ? '#dbe8df' : '#ffd99a',
            depthWrite: false,
            blending: type === 'glow' ? T.AdditiveBlending : T.NormalBlending,
          }),
        );
        this.group.add(m);
        this.sheets.push({ mesh: m, type, p, phase: i / n, size, sector });
      }
    };
    add('smoke', stack, 3.3, 'surface', 7);
    add('steam', { x: 39.03, y: -8.9, z: -98 }, 0.72, 'water', 5);
    add('steam', { x: 89, y: -8.25, z: -81 }, 0.69, 'power', 5);
    const sg = new T.BufferGeometry();
    sg.setAttribute('position', new T.BufferAttribute(this.sparkData, 3).setUsage(T.DynamicDrawUsage));
    this.sparks = new T.LineSegments(
      sg,
      new T.LineBasicMaterial({ color: '#ffe5af', transparent: true, opacity: 0.88, depthWrite: false }),
    );
    this.sparks.frustumCulled = false;
    this.group.add(this.sparks);
    for (const [x, y, z, length, rad] of [
      [-62, 8, -41, 20, 2.6],
      [-14, 9, 78, 20, 3.1],
      [-7, -4.9, 45, 7.4, 1.6],
      [-40, -7.6, -55, 4.3, 0.81],
    ]) {
      const m = new T.Mesh(
        new T.ConeGeometry(rad, length, 12, 1, true),
        new T.MeshBasicMaterial({
          color: '#ffedc7',
          transparent: true,
          opacity: 0.024,
          depthWrite: false,
          side: T.DoubleSide,
          blending: T.AdditiveBlending,
        }),
      );
      m.position.set(x, y, z);
      m.rotation.z = 0.25;
      this.shafts.push(m);
      this.group.add(m);
    }
    this.glowPositions = [...lamps, ...cars];
    this.glows = new T.InstancedMesh(
      new T.PlaneGeometry(1, 1),
      new T.MeshBasicMaterial({
        map: this.glowTexture,
        color: '#ffe2b3',
        transparent: true,
        opacity: 0.63,
        depthWrite: false,
        blending: T.AdditiveBlending,
      }),
      this.glowPositions.length,
    );
    this.glows.frustumCulled = false;
    this.group.add(this.glows);
    this.pinLights = new T.InstancedMesh(
      new T.SphereGeometry(0.035, 6, 4),
      new T.MeshBasicMaterial({ color: '#b5d1a8' }),
      16,
    );
    for (let i = 0; i < 16; i++) {
      this.scratch.position.set(
        i < 8 ? 18.4 : 71.52,
        i < 8 ? -10.7 + (i % 2) * 0.22 : -10.44,
        (i < 8 ? 77 : -86) + Math.floor((i % 8) / 2) * 2.3,
      );
      this.scratch.scale.setScalar(1);
      this.scratch.updateMatrix();
      this.pinLights.setMatrixAt(i, this.scratch.matrix);
    }
    this.pinLights.computeBoundingSphere();
    this.group.add(this.pinLights);
  }
  update(dt: number, pos: Anchor, camera: T.PerspectiveCamera, underground: boolean, zone: string) {
    this.group.visible = this.enabled;
    if (!this.enabled) return;
    this.clock += dt;
    const t = this.clock,
      fast = this.quality === 'mobile',
      n = fast ? 20 : this.quality === 'high' ? 78 : 48;
    this.particle.geometry.setDrawRange(0, n);
    const wrap = (v: number, size: number) => (((v % size) + size) % size) - size / 2;
    for (let i = 0; i < n; i++) {
      const j = i * 4,
        rad = underground ? 10 : 22;
      this.buffer[3 * i] = pos.x + wrap(this.seeds[j] * rad + t * (underground ? 0.054 : 0.29) - pos.x, rad);
      this.buffer[3 * i + 1] =
        pos.y + 0.08 + ((this.seeds[j + 1] * 3.45 + t * (underground ? 0.042 : 0.079)) % 3.45);
      this.buffer[3 * i + 2] = pos.z + wrap(this.seeds[j + 2] * rad + t * 0.063 - pos.z, rad);
    }
    this.particle.geometry.attributes.position.needsUpdate = true;
    (this.particle.material as T.PointsMaterial).opacity = underground ? 0.15 : 0.31;
    this.leaves.visible = !underground;
    this.leaves.count = fast ? 3 : 8;
    if (!underground) {
      for (let i = 0; i < this.leaves.count; i++) {
        const life = (t * 0.081 + i * 0.37) % 1;
        this.scratch.position.set(
          pos.x + wrap(i * 7.3 + t * 0.88 - pos.x, 24),
          0.045 + Math.pow(Math.sin(life * PI2), 4) * 0.27,
          pos.z + wrap(i * 5.1 + t * 0.27 - pos.z, 24),
        );
        this.scratch.rotation.set(
          -Math.PI / 2 + 0.2 * Math.sin(t + i),
          life * 2,
          Math.sin(t * 0.36 + i) * 0.64,
        );
        this.scratch.scale.setScalar(0.8 + (i % 3) * 0.2);
        this.scratch.updateMatrix();
        this.leaves.setMatrixAt(i, this.scratch.matrix);
      }
      this.leaves.instanceMatrix.needsUpdate = true;
    }
    for (const s of this.sheets) {
      const visible =
        (s.sector === 'surface' ? !underground : zone === s.sector) &&
        Math.hypot(pos.x - s.p.x, pos.z - s.p.z) < (fast ? 70 : 155);
      s.mesh.visible = visible;
      if (!visible) continue;
      const life = (t * (s.type === 'smoke' ? 0.086 : 0.271) + s.phase) % 1,
        spread = s.type === 'smoke' ? 4.8 : 0.55;
      s.mesh.position.set(
        s.p.x + life * spread + Math.sin(life * 4 + s.phase) * 0.21,
        s.p.y + life * (s.type === 'smoke' ? 9 : 2.6),
        s.p.z + life * spread * 0.22,
      );
      s.mesh.scale.setScalar(s.size * (0.4 + life * 1.5));
      s.mesh.material.opacity = Math.sin(life * Math.PI) * (s.type === 'smoke' ? 0.2 : 0.22);
      s.mesh.material.rotation = s.phase * 4 + life * 0.45;
    }
    this.glows.visible = !underground;
    if (!underground) {
      let count = 0;
      this.glowPositions.forEach((p, i) => {
        if (Math.hypot(p.x - pos.x, p.z - pos.z) > (fast ? 43 : 78)) return;
        this.scratch.position.set(p.x, p.y, p.z);
        this.scratch.quaternion.copy(camera.quaternion);
        const flicker = i === 13 && Math.sin(t * 2.9) > 0.97 ? 0.47 : 1;
        this.scratch.scale.setScalar((i >= this.glowPositions.length - 3 ? 1.65 : 2.21) * flicker);
        this.scratch.updateMatrix();
        this.glows.setMatrixAt(count++, this.scratch.matrix);
      });
      this.glows.count = count;
      this.glows.instanceMatrix.needsUpdate = true;
    }
    this.shafts.forEach((s, i) => {
      s.visible =
        !fast &&
        (i < 2 ? !underground : i === 2 ? zone === 'concourse' : zone === 'education') &&
        Math.hypot(pos.x - s.position.x, pos.z - s.position.z) < 42;
    });
    const isIndustrial = zone === 'power' || zone === 'workshop',
      p = underground
        ? { x: zone === 'power' ? 99.97 : 54, y: -10.3, z: zone === 'power' ? -77.5 : -48.6 }
        : { x: -77, y: 1.39, z: -77 };
    // One nearest-source light is reused for every active set of headlamps.
    this.vehicleBeam.visible = false;
    if (!underground) {
      let best = fast ? 18 : 38;
      let car: Anchor | undefined;
      for (const v of this.vehicles) {
        const d = Math.hypot(pos.x - v.x, pos.z - v.z);
        if (d < best) {
          car = v;
          best = d;
        }
      }
      if (car) {
        this.vehicleBeam.visible = true;
        this.vehicleBeam.position.set(car.x, car.y, car.z);
        this.vehicleBeam.target.position.set(
          car.x + Math.sin(car.heading || 0) * 11,
          0.03,
          car.z + Math.cos(car.heading || 0) * 11,
        );
      }
    }
    const near = (!underground || isIndustrial) && Math.hypot(p.x - pos.x, p.z - pos.z) < 33;
    this.nextSpark -= dt;
    if (this.nextSpark <= 0) {
      this.nextSpark = 8 + Math.random() * 13;
      if (near) {
        this.flareTime = 0.23;
        worldAudio.cue('spark', p.x, p.y, p.z);
      }
    }
    this.flareTime = Math.max(0, this.flareTime - dt);
    this.sparks.visible = near && this.flareTime > 0;
    if (this.sparks.visible) {
      const age = 0.23 - this.flareTime;
      for (let j = 0; j < 10; j++) {
        const a = j * 2.399,
          xx = Math.cos(a) * age * 1.7,
          zz = Math.sin(a) * age * 1.4,
          yy = age * (0.4 + (j % 4) * 0.47) - age * age * 8;
        this.sparkData.set(
          [p.x + xx, p.y + yy, p.z + zz, p.x + xx * 0.8, p.y + yy + 0.042, p.z + zz * 0.8],
          j * 6,
        );
      }
      this.sparks.geometry.attributes.position.needsUpdate = true;
    }
    this.pinLights.visible = underground && (zone === 'command' || zone === 'power');
    if (this.pinLights.visible)
      (this.pinLights.material as T.MeshBasicMaterial).color.setScalar(0.57 + 0.16 * Math.sin(t * 2.2));
  }
  setMachineRunning(on: boolean) {
    for (const s of this.sheets) if (s.sector === 'power') s.size = on ? 1.08 : 0.69;
  }
  dispose() {
    this.group.removeFromParent();
    this.group.traverse((o) => {
      if (o instanceof T.Sprite) o.material.dispose();
      else if (o instanceof T.Mesh || o instanceof T.LineSegments || o instanceof T.Points) {
        o.geometry.dispose();
        (o.material as T.Material).dispose();
        if (o instanceof T.InstancedMesh) o.dispose();
      }
    });
    this.vehicleBeam.dispose();
    this.glowTexture.dispose();
    this.cloudTexture.dispose();
  }
}
const PI2 = Math.PI * 2;
