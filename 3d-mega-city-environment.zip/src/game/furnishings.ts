import { FacilityKit as K } from './facilityKit';
const pi = Math.PI;
export function chair(k: K, x: number, z: number, angle = 0, kind = 'lounge', color = '#787b66') {
  k.at(x, 0, z, angle, () => {
    const office = kind === 'office';
    const lounge = kind === 'lounge';
    const w = lounge ? 0.75 : 0.52;
    k.box(0, 0.47, 0, w, 0.13, 0.52, office ? 'fabric' : 'paint', color, true);
    k.box(0, 0.78, -0.24, w, 0.53, 0.095, 'fabric', color, true, [-0.11, 0, 0]);
    if (office) {
      k.cyl(0, 0.27, 0, 0.048, 0.34);
      for (let i = 0; i < 5; i++) {
        const a = i * pi * 0.4;
        const ax = Math.cos(a) * 0.33,
          az = Math.sin(a) * 0.33;
        k.rod([0, 0.17, 0], [ax, 0.09, az], 0.026, 'graphite', '#454a49');
        k.oval(ax, 0.067, az, 0.065, 0.065, 0.04, 'rubber', '#252827');
      }
    } else
      for (const s of [-1, 1])
        for (const f of [-1, 1])
          k.rod([s * w * 0.38, 0.42, f * 0.18], [s * w * 0.46, 0.045, f * 0.235], 0.025, 'steel', '#676b64');
    for (const s of [-1, 1]) {
      k.rod([s * w * 0.38, 0.42, -0.2], [s * w * 0.38, 0.85, -0.24], 0.026);
      if (lounge || office) {
        k.rod([s * w * 0.52, 0.49, 0.15], [s * w * 0.52, 0.7, 0.15], 0.021);
        k.box(s * w * 0.52, 0.7, 0, 0.06, 0.055, 0.36, 'graphite', '#464b45', true);
      }
    }
    k.shadow(0, 0, w * 1.8, 1.1);
    k.solid(0, 0.5, 0, w, 0.99, 0.58);
  });
}
export function table(k: K, x: number, z: number, w: number, d: number, material = 'wood', angle = 0) {
  k.at(x, 0, z, angle, () => {
    k.box(0, 0.82, 0, w, 0.085, d, material, material === 'wood' ? '#b59b75' : '#acb2ad', true);
    k.box(0, 0.746, 0, w - 0.13, 0.08, d - 0.13, 'graphite', '#424947');
    for (const s of [-1, 1])
      for (const f of [-1, 1]) {
        k.box(s * (w / 2 - 0.13), 0.36, f * (d / 2 - 0.13), 0.07, 0.72, 0.07, 'steel', '#797d77');
        k.box(s * (w / 2 - 0.13), 0.03, f * (d / 2 - 0.13), 0.11, 0.06, 0.11, 'rubber', '#343933', true);
      }
    k.shadow(0, 0, w * 1.14, d * 1.4);
    k.solid(0, 0.45, 0, w, 0.9, d);
  });
}
export function bench(k: K, x: number, z: number, angle = 0, len = 3.6) {
  k.at(x, 0, z, angle, () => {
    for (let i = 0; i < 6; i++)
      k.box(0, 0.49, -0.29 + i * 0.114, len, 0.09, 0.095, 'wood', i % 2 ? '#927a57' : '#a58a65', true);
    for (let i = 0; i < 3; i++)
      k.box(0, 0.72 + i * 0.13, -0.33 - i * 0.022, len, 0.104, 0.065, 'wood', '#9d825e', true);
    for (const s of [-1, 1]) {
      k.box(s * len * 0.35, 0.26, 0, 0.08, 0.46, 0.6, 'graphite', '#40443e');
      k.box(s * len * 0.35, 0.04, 0, 0.27, 0.07, 0.7, 'steel', '#656960', true);
      k.rod([s * len * 0.35, 0.45, -0.3], [s * len * 0.35, 1.03, -0.39], 0.034);
    }
    k.shadow(0, 0, len * 1.15, 1.3);
    k.solid(0, 0.5, 0, len, 1, 0.7);
  });
}
export function monitor(k: K, x: number, y: number, z: number, style = 0, w = 0.84, angle = 0) {
  k.at(x, y, z, angle, () => {
    k.box(0, 0.025, 0.05, w * 0.48, 0.045, 0.26, 'graphite', '#393f3e', true);
    k.cyl(0, 0.18, 0, 0.033, 0.3);
    k.box(0, 0.38, 0, w, 0.56 * w, 0.048, 'graphite', '#252b29', true);
    k.box(0, 0.39, 0.026, w - 0.038, 0.56 * w - 0.038, 0.004, 'screen' + style, '#ffffff');
    k.box(0, 0.012, 0.35, w * 0.67, 0.025, 0.17, 'vent', '#71736b', true);
  });
}
export function cabinet(
  k: K,
  x: number,
  z: number,
  w = 1.8,
  h = 1.1,
  d = 0.65,
  color = '#818a82',
  angle = 0,
  drawers = 3,
) {
  k.at(x, 0, z, angle, () => {
    k.box(0, h * 0.5, 0, w, h, d, 'graphite', '#535e58', true);
    k.box(0, h + 0.025, 0, w + 0.045, 0.055, d + 0.055, 'steel', '#b0b7ad', true);
    k.box(0, 0.06, 0.01, w - 0.16, 0.12, d - 0.1, 'rubber', '#343c37');
    for (let j = 0; j < drawers; j++) {
      const cy = 0.13 + ((j + 0.5) * (h - 0.2)) / drawers;
      k.box(0, cy, d * 0.5 + 0.007, w - 0.075, (h - 0.23) / drawers - 0.018, 0.032, 'paint', color, true);
      k.box(0, cy + 0.04, d * 0.5 + 0.047, w * 0.26, 0.029, 0.053, 'steel', '#b1b7ac', true);
    }
    k.solid(0, h * 0.5, 0, w, h, d);
    k.shadow(0, 0, w * 1.15, d * 1.4);
  });
}
export function planter(k: K, x: number, z: number, scale = 1) {
  k.at(x, 0, z, 0, () => {
    k.box(0, 0.38 * scale, 0, 1.45 * scale, 0.76 * scale, 1.3 * scale, 'stone', '#aaa99b', true);
    k.box(0, 0.78 * scale, 0, 1.29 * scale, 0.04, 1.15 * scale, 'rubber', '#4d4b37');
    for (let j = 0; j < 9; j++) {
      const a = j * 2.39,
        xx = Math.cos(a) * 0.51 * scale,
        zz = Math.sin(a) * 0.48 * scale,
        yy = (1.35 + k.random() * 0.6) * scale;
      k.rod([xx * 0.12, 0.72 * scale, zz * 0.12], [xx, yy, zz], 0.014 * scale, 'wood', '#655e41');
      for (let v = 0; v < 4; v++)
        k.oval(
          xx + Math.cos(a + v) * 0.105 * scale,
          yy - v * 0.092 * scale,
          zz + Math.sin(a + v) * 0.1 * scale,
          0.12 * scale,
          0.29 * scale,
          0.06 * scale,
          'paint',
          ['#667359', '#52684c', '#75815b'][j % 3],
          [0.48, a + v, a * 0.5],
        );
    }
    k.shadow(0, 0, 2.5 * scale, 2.3 * scale);
    k.solid(0, 0.4 * scale, 0, 1.45 * scale, 0.8 * scale, 1.3 * scale);
  });
}
export function lightBar(k: K, x: number, y: number, z: number, len: number, angle = 0, warm = false) {
  k.at(x, y, z, angle, () => {
    k.box(0, 0, 0, 0.23, 0.15, len, 'graphite', '#363e39');
    k.box(0, -0.081, 0, 0.15, 0.023, len - 0.12, 'light', warm ? '#ffe1b1' : '#e7f2eb');
    for (const a of [-1, 1]) k.box(0, 0.15, a * len * 0.38, 0.09, 0.21, 0.12, 'steel', '#7e8479');
  });
}
export function shelf(
  k: K,
  x: number,
  z: number,
  w: number,
  len: number,
  kind: 'books' | 'supply' | 'medical',
  angle = 0,
) {
  k.at(x, 0, z, angle, () => {
    const h = kind === 'supply' ? 3.9 : 2.45;
    const tiers = kind === 'supply' ? 3 : 5;
    const mat = kind === 'books' ? 'wood' : 'steel';
    for (const s of [-1, 1])
      for (const f of [-1, 1])
        k.box(
          s * w * 0.49,
          h * 0.5,
          f * len * 0.47,
          0.065,
          h,
          0.075,
          mat,
          kind === 'books' ? '#a28a65' : '#747e71',
        );
    for (let j = 0; j <= tiers; j++) {
      const y = 0.13 + (j * (h - 0.13)) / tiers;
      k.box(0, y, 0, w + 0.06, 0.068, len, mat, kind === 'books' ? '#ad9572' : '#989f8d');
      if (j === tiers) continue;
      if (kind === 'books') {
        const colors = ['#8b735a', '#5f7474', '#8f4e3c', '#c7b48a', '#53604b', '#53576a'];
        for (let t = -w * 0.45; t < w * 0.42; ) {
          const bw = 0.07 + k.random() * 0.065,
            bh = 0.23 + k.random() * 0.17;
          k.box(
            t,
            y + bh * 0.5 + 0.034,
            0,
            bw,
            bh,
            len * 0.72,
            'paint',
            colors[Math.floor(k.random() * colors.length)],
          );
          k.box(t, y + bh * 0.69, len * 0.362, bw * 0.76, 0.014, 0.01, 'paint', '#c1b39b');
          t += bw + 0.014;
        }
      } else {
        const n = Math.max(2, Math.floor(w / 0.84));
        for (let v = 0; v < n; v++) {
          const bx = ((v - (n - 1) / 2) * w) / n;
          const bh = kind === 'supply' ? 0.68 : 0.25;
          const bw = (w / n) * 0.81;
          k.box(
            bx,
            y + 0.04 + bh / 2,
            0,
            bw,
            bh,
            len * 0.76,
            'paint',
            kind === 'supply' ? ['#727963', '#908572', '#738078'][v % 3] : '#c7d2bd',
            true,
          );
          k.box(bx, y + 0.06 + bh, 0, bw + 0.02, 0.055, len * 0.8, 'graphite', '#747d6c', true);
          k.box(bx, y + bh * 0.6, len * 0.39, bw * 0.34, bh * 0.23, 0.014, 'paint', '#d9dac8');
        }
      }
    }
    k.solid(0, h / 2, 0, w, h, len);
    k.shadow(0, 0, w * 1.16, len * 1.5);
  });
}
export function bed(k: K, x: number, z: number, operating = false) {
  k.at(x, 0, z, 0, () => {
    const col = operating ? '#648d84' : '#c9d5cd';
    for (const s of [-1, 1])
      for (const f of [-1, 1]) {
        k.cyl(s * 0.43, 0.12, f * 0.87, 0.096, 0.065, 'rubber', '#3e4944', [0, 0, pi / 2]);
        k.rod([s * 0.43, 0.15, f * 0.87], [s * 0.43, 0.34, f * 0.87], 0.03);
      }
    k.box(0, 0.3, 0, 0.91, 0.1, 1.83, 'steel', '#b0b9ae', true);
    k.rod([0, 0.33, -0.55], [0, 0.58, 0.48], 0.072);
    k.rod([0, 0.33, 0.55], [0, 0.58, -0.48], 0.072);
    k.box(0, 0.61, 0, 1.05, 0.12, 2.16, 'paint', '#aaaE9e', true);
    k.box(0, 0.755, 0.34, 1.0, 0.17, 1.39, 'fabric', col, true);
    k.box(0, 0.9, -0.7, 1, 0.17, 0.77, 'fabric', col, true, [0.33, 0, 0]);
    k.box(0, 1.02, -0.83, 0.71, 0.14, 0.37, 'fabric', '#ebece1', true, [0.25, 0, 0]);
    k.box(0, 0.83, 1.08, 1.04, 0.34, 0.09, 'paint', '#9cae9f', true);
    k.box(0, 0.99, -1.08, 1.04, 0.51, 0.09, 'paint', '#adbaac', true);
    for (const s of [-1, 1]) {
      k.rod([s * 0.545, 0.65, -0.73], [s * 0.545, 0.98, -0.73], 0.028);
      k.rod([s * 0.545, 0.65, 0.42], [s * 0.545, 0.98, 0.42], 0.028);
      k.rod([s * 0.545, 0.98, -0.73], [s * 0.545, 0.98, 0.42], 0.035);
    }
    cabinet(k, 1.22, -0.5, 0.62, 0.85, 0.63, '#bbc8bc');
    monitor(k, 1.22, 0.89, -0.52, 1, 0.65);
    k.cyl(-0.93, 1.02, -0.67, 0.024, 1.95);
    k.box(-0.93, 1.98, -0.67, 0.36, 0.035, 0.04, 'steel', '#b4c4bd');
    k.box(-0.78, 1.78, -0.67, 0.16, 0.28, 0.06, 'glass', '#b5c6c3', true);
    k.shadow(0, 0, 1.8, 3.2);
    k.solid(0, 0.56, 0, 1.1, 1.12, 2.2);
  });
}
export function dispenser(k: K, x: number, z: number) {
  k.at(x, 0, z, 0, () => {
    k.box(0, 0.54, 0, 0.49, 1.08, 0.48, 'paint', '#c0c8c0', true);
    k.box(0, 0.76, 0.246, 0.32, 0.28, 0.03, 'graphite', '#434c48', true);
    k.cyl(0, 1.32, 0, 0.18, 0.43, 'glass', '#91b8b4');
    k.box(0, 0.83, 0.28, 0.12, 0.045, 0.12, 'steel', '#a7b4aa');
    k.solid(0, 0.65, 0, 0.52, 1.4, 0.51);
  });
}
export function kiosk(k: K, x: number, z: number, title: string, angle = 0) {
  k.at(x, 0, z, angle, () => {
    k.box(0, 0.06, 0, 0.96, 0.12, 0.67, 'graphite', '#525c54', true);
    k.box(0, 0.82, 0, 0.58, 1.5, 0.33, 'graphite', '#484f48', true);
    k.box(0, 1.53, 0, 1.03, 0.71, 0.11, 'paint', '#454d46', true, [-0.14, 0, 0]);
    k.box(0, 1.55, 0.063, 0.95, 0.59, 0.01, 'screen0', '#fff', false, [-0.14, 0, 0]);
    k.label(0, 0.98, 0.172, 0.54, 0.2, title, 'LF ACCESS');
    k.solid(0, 0.85, 0, 1.03, 1.8, 0.67);
    k.shadow(0, 0, 1.36, 1.05);
  });
}
export function safety(k: K, x: number, z: number, angle = 0) {
  k.at(x, 0, z, angle, () => {
    k.box(0, 1.24, 0, 0.65, 0.98, 0.17, 'paint', '#9a503b', true);
    k.box(0, 1.24, 0.091, 0.49, 0.77, 0.018, 'glass', '#a3aca0');
    k.cyl(0, 1.14, 0.1, 0.13, 0.52, 'paint', '#a84b36');
    k.box(0, 1.47, 0.11, 0.19, 0.045, 0.08, 'steel', '#6d7770');
    k.label(0, 1.91, 0.09, 0.69, 0.21, 'FIRE POINT', '', '#e2906c');
    k.box(0.51, 1.38, 0, 0.19, 0.37, 0.12, 'vent', '#959d93', true);
  });
}
