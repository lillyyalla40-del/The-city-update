export type QualityPreset = 'mobile' | 'balanced' | 'high';

export type HatchState = 'closed' | 'opening' | 'open' | 'closing';

export type ZoneEnvironment = 'surface' | 'shaft' | 'bunker';

export interface ZoneDefinition {
  id: string;
  name: string;
  subtitle: string;
  environment: ZoneEnvironment;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  minY: number;
  maxY: number;
  color: string;
}

export interface InteractablePrompt {
  id: string;
  label: string;
  sublabel: string;
  action: () => void;
}

export interface PlayerInputState {
  // Normalized -1..1 movement relative to camera yaw
  moveX: number;
  moveY: number;
  sprint: boolean;
  jumpRequested: boolean;
}

export interface HudTelemetry {
  fps: number;
  drawCalls: number;
  triangles: number;
  position: { x: number; y: number; z: number };
  yawDeg: number;
  currentZone: ZoneDefinition;
  room?: string;
  hatchState: HatchState;
  hatchProgress: number; // 0 = closed, 1 = open
  nearPrompt: { id: string; label: string; sublabel: string } | null;
  flashlightOn: boolean;
  isUnderground: boolean;
  isMoving: boolean;
  isSprinting: boolean;
}

export interface FastTravelPoint {
  id: string;
  label: string;
  group: 'Surface City' | 'Underground Bunker';
  x: number;
  y: number;
  z: number;
  yaw: number;
  requiresOpenHatch?: boolean;
}
