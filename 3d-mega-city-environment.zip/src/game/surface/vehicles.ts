import * as T from 'three';
import { SurfaceKit as K, type V3 } from './SurfaceKit';

export type VehicleType = 'sedan' | 'suv' | 'van' | 'bus' | 'delivery' | 'truck' | 'ambulance';
export interface VehicleSite {
  kind: VehicleType;
  x: number;
  z: number;
  y: number;
  yaw: number;
  color: string;
  open: boolean;
}
export const VEHICLE_SITES: VehicleSite[] = [
  { kind: 'bus', x: -62.3, z: -20, y: 0, yaw: -1.32, color: '#bfab7f', open: true },
  { kind: 'sedan', x: -73.2, z: -4.7, y: 0, yaw: -1.78, color: '#7e8a90', open: true },
  { kind: 'suv', x: -64.7, z: -42.5, y: 0, yaw: 1.71, color: '#6d776a', open: false },
  { kind: 'ambulance', x: -58.5, z: -64.4, y: 0, yaw: 0.17, color: '#d7d8c8', open: true },
  { kind: 'van', x: 67.5, z: 4.7, y: 0, yaw: 1.36, color: '#adbdaf', open: false },
  { kind: 'delivery', x: -92.5, z: 73, y: 0, yaw: 0.13, color: '#b6b4a0', open: true },
  { kind: 'suv', x: 112, z: -74.9, y: 0, yaw: 3.03, color: '#77877f', open: true },
  { kind: 'truck', x: 46, z: -128.9, y: 6.47, yaw: 0.035, color: '#788989', open: false },
  { kind: 'sedan', x: 34.1, z: -130, y: 6.47, yaw: 0.11, color: '#a29a83', open: false },
  { kind: 'van', x: 72.8, z: 117, y: 0, yaw: 1.62, color: '#b9b7a7', open: true },
];
const PI = Math.PI;
function seat(k: K, x: number, y: number, z: number, w = 0.55) {
  k.box(x, y, z, 0.49, 0.13, w, '#515d57', 'rubber', true);
  k.box(x - 0.2, y + 0.33, z, 0.11, 0.59, w, '#626b61', 'rubber', true, [0, 0, 0.11]);
  k.box(x - 0.24, y + 0.69, z, 0.13, 0.18, w * 0.65, '#626b62', 'rubber', true);
  k.box(x, y - 0.18, z, 0.27, 0.26, w * 0.52, '#343c37', 'metal');
}
function wheel(k: K, x: number, z: number, r: number, t: number) {
  const side = Math.sign(z);
  let tyre = k.geoCache.get('tyre');
  if (!tyre) {
    tyre = new T.LatheGeometry(
      [
        [0.49, -0.42],
        [0.68, -0.48],
        [0.91, -0.46],
        [1, -0.31],
        [1, 0.32],
        [0.9, 0.46],
        [0.67, 0.49],
        [0.49, 0.42],
        [0.49, -0.42],
      ].map(([a, b]) => new T.Vector2(a, b)),
      20,
    );
    k.geoCache.set('tyre', tyre);
  }
  k.put(tyre, 'rubber', x, r, z, r, t, r, '#353c38', [PI / 2, 0, 0]);
  k.cyl(x, r, z + side * t * 0.46, r * 0.61, 0.033, '#6a716d', 'metal', [PI / 2, 0, 0]);
  k.cyl(x, r, z + side * t * 0.51, r * 0.31, 0.052, '#a2a69a', 'metal', [PI / 2, 0, 0]);
  for (let j = 0; j < 6; j++) {
    const a = (j * PI) / 3;
    k.cyl(
      x + Math.cos(a) * r * 0.44,
      r + Math.sin(a) * r * 0.44,
      z + side * t * 0.52,
      r * 0.073,
      0.022,
      '#303b36',
      'rubber',
      [PI / 2, 0, 0],
    );
  }
}
function glass(k: K, a: V3, b: V3, c: V3, d: V3, broken: boolean) {
  if (!broken) k.quad(a, b, c, d, 'glass', '#b1c4bd');
  else {
    const mix = (v: V3, w: V3, t: number): V3 => v.map((n, j) => n + (w[j] - n) * t) as V3;
    const e = mix(a, b, 0.23),
      f = mix(a, d, 0.53);
    k.quad(a, e, mix(e, f, 0.54), f, 'shard', '#7e9591');
    k.quad(c, mix(c, d, 0.52), mix(c, a, 0.16), mix(c, b, 0.37), 'shard', '#80948b');
  }
}
function cargo(k: K, l: number, w: number, h: number, truck: boolean, open: boolean) {
  const rear = -l / 2 + 0.13,
    front = l * 0.1,
    y = 0.82,
    roof = h + 0.36,
    depth = front - rear,
    mid = (front + rear) / 2;
  k.box(mid, y, 0, depth, 0.16, w - 0.08, '#766e5f', 'timber');
  k.box(mid, roof, 0, depth, 0.14, w + 0.07, '#b4b4a5', 'body', true);
  for (const s of [-1, 1]) {
    k.box(
      mid,
      (roof + y) / 2,
      s * (w / 2 - 0.045),
      depth,
      roof - y,
      0.085,
      truck ? '#9a9c8d' : '#c4c5b4',
      'body',
    );
    for (let i = 0; i < 12; i++)
      k.box(
        rear + 0.25 + (i * (depth - 0.5)) / 11,
        (roof + y) / 2,
        s * w * 0.5,
        0.035,
        roof - y - 0.1,
        0.034,
        '#949b91',
        'metal',
      );
    k.box(mid, y + 0.29, s * (w / 2 + 0.02), depth, 0.16, 0.048, '#717e73', 'rust');
  }
  k.box(front, roof / 2 + 0.34, 0, 0.12, roof - y, w, '#9b9f91', 'body');
  for (const s of [-1, 1])
    k.local(rear, 0, s * w * 0.5, -s * (open ? 0.57 : PI / 2), () => {
      k.box(-w * 0.24, (roof + y) / 2, 0, w * 0.48, roof - y - 0.04, 0.09, '#b7b6a4', 'body');
      for (const yy of [y + 0.17, roof - 0.16])
        k.box(-w * 0.24, yy, 0.066, w * 0.47, 0.075, 0.036, '#8f9588', 'metal');
      k.rod([-w * 0.4, y + 0.09, 0.09], [-w * 0.4, roof - 0.09, 0.09], 0.022, '#989e90');
      if (open) k.solid('cargo-door', -w * 0.24, (roof + y) / 2, 0, w * 0.48, roof - y, 0.091);
    });
  if (open)
    for (const [j, xx] of [rear + 1.7, rear + 2.7].entries()) {
      k.box(xx, y + 0.48, j === 0 ? -0.31 : 0.27, 0.83, 0.76, 0.68, '#9c8b69', 'timber');
      k.box(xx, y + 0.88, j === 0 ? -0.31 : 0.27, 0.84, 0.045, 0.71, '#a29a7b', 'paint');
    }
}
export function abandonedVehicle(k: K, v: VehicleSite) {
  const dims: Record<VehicleType, [number, number, number, number]> = {
    sedan: [4.61, 1.83, 1.44, 0.34],
    suv: [4.88, 1.97, 1.81, 0.397],
    van: [5.45, 2.05, 2.43, 0.398],
    bus: [10.66, 2.53, 3.07, 0.54],
    delivery: [6.74, 2.22, 2.86, 0.437],
    truck: [8.27, 2.45, 3.02, 0.49],
    ambulance: [6.06, 2.18, 2.64, 0.427],
  };
  const [l, w, h, r] = dims[v.kind],
    bus = v.kind === 'bus',
    boxTruck = v.kind === 'truck' || v.kind === 'delivery',
    light = v.kind === 'sedan' || v.kind === 'suv',
    back = -l / 2,
    front = l / 2,
    ax1 = -l * 0.304,
    ax2 = l * 0.29,
    belt = bus ? 1.37 : boxTruck ? 1.16 : light ? 0.945 : 1.13;
  k.cell = 'vehicle';
  k.range = 125;
  k.local(v.x, v.y, v.z, v.yaw, () => {
    const main = k.shape(
      'body-' + v.kind,
      (s) => {
        s.moveTo(back + 0.08, 0.37);
        s.lineTo(ax1 - r - 0.08, 0.37);
        s.absarc(ax1, 0.37, r + 0.08, PI, 0, true);
        s.lineTo(ax2 - r - 0.08, 0.37);
        s.absarc(ax2, 0.37, r + 0.08, PI, 0, true);
        s.lineTo(front - 0.09, 0.37);
        s.quadraticCurveTo(front + 0.04, 0.39, front, 0.59);
        s.lineTo(front - 0.1, belt - 0.13);
        s.quadraticCurveTo(front - 0.34, belt, front - 0.55, belt);
        s.lineTo(back + 0.34, belt + 0.03);
        s.quadraticCurveTo(back, belt + 0.02, back, belt - 0.24);
        s.closePath();
      },
      w,
      0.04,
    );
    k.put(main, 'body', 0, 0, 0, 1, 1, 1, v.color);
    k.box(0, 0.37, 0, l * 0.91, 0.22, w * 0.74, '#333c37', 'rubber');
    k.shadow(0, 0.01, 0, l * 1.2, w * 1.68);
    for (const a of [ax1, ax2])
      for (const side of [-1, 1]) wheel(k, a, side * (w * 0.5 - 0.074), r, bus ? 0.33 : 0.25);
    const rear = boxTruck ? l * 0.11 : light ? back + 0.8 : back + 0.08;
    const cabF = light ? front - l * 0.24 : front - 0.09,
      roofF = light ? cabF - 0.57 : front - 0.43,
      roofR = light ? rear + 0.45 : rear + 0.12;
    const hi = boxTruck ? h - 0.32 : h,
      hh = hi - 0.085,
      lo = belt + 0.015;
    k.box((roofR + roofF) / 2, hi, 0, roofF - roofR + 0.1, 0.14, w * 0.97, v.color, 'body', true);
    k.box((rear + cabF) / 2, lo - 0.04, 0, cabF - rear, 0.14, w * 0.96, '#444b45', 'rubber');
    for (const side of [-1, 1]) {
      const zz = side * w * 0.493;
      k.rod([rear, lo, zz], [roofR, hh, zz * 0.96], bus ? 0.066 : 0.048, '#868d82', 'body');
      k.rod([cabF, lo, zz], [roofF, hh, zz * 0.96], bus ? 0.074 : 0.05, v.color, 'body');
      k.box((roofR + roofF) / 2, hh - 0.01, zz * 0.96, roofF - roofR, 0.082, 0.081, v.color, 'metal');
      const panels = bus ? 9 : boxTruck ? 1 : light ? 2 : 4;
      for (let j = 0; j < panels; j++) {
        const a = j / panels,
          b = (j + 1) / panels,
          lowA = rear + (cabF - rear) * a,
          lowB = rear + (cabF - rear) * b,
          topA = roofR + (roofF - roofR) * a,
          topB = roofR + (roofF - roofR) * b;
        const skipDoor = v.open && side === 1 && j === panels - 1 && !bus && !boxTruck;
        const panel = !light && !bus && !boxTruck && j < panels - 1 && v.kind !== 'ambulance';
        if (!skipDoor) {
          if (panel) {
            k.quad(
              [lowA, lo, zz],
              [lowB, lo, zz],
              [topB, hh, zz * 0.96],
              [topA, hh, zz * 0.96],
              'body',
              v.color,
            );
          } else
            glass(
              k,
              [lowA + 0.02, lo + 0.03, zz],
              [lowB - 0.02, lo + 0.03, zz],
              [topB - 0.02, hh - 0.05, zz * 0.96],
              [topA + 0.03, hh - 0.05, zz * 0.96],
              (bus && j % 5 === 2) || (v.open && side < 0 && j === 0),
            );
        }
        if (j > 0) k.rod([lowA, lo, zz], [topA, hh, zz * 0.96], bus ? 0.045 : 0.032, '#515c55', 'metal');
        k.box(lowA + 0.25, lo - 0.14, zz + side * 0.027, 0.16, 0.035, 0.042, '#b0b5a7', 'metal');
      }
      k.box(0, 0.53, zz + side * 0.024, l - 0.31, 0.065, 0.065, '#8f9486', 'metal');
      k.rod([cabF - 0.3, lo + 0.13, zz], [cabF - 0.3, lo + 0.21, zz + side * 0.21], 0.021, '#535e55');
      k.box(cabF - 0.29, lo + 0.25, zz + side * 0.247, 0.21, 0.155, 0.11, '#899388', 'body', true);
    }
    glass(
      k,
      [cabF + 0.02, lo, -w * 0.47],
      [cabF + 0.02, lo, w * 0.47],
      [roofF + 0.025, hh, w * 0.452],
      [roofF + 0.025, hh, -w * 0.452],
      bus || v.kind === 'van',
    );
    glass(
      k,
      [rear - 0.02, lo, w * 0.47],
      [rear - 0.02, lo, -w * 0.47],
      [roofR - 0.02, hh, -w * 0.452],
      [roofR - 0.02, hh, w * 0.452],
      v.kind === 'suv',
    );
    for (const side of [-1, 1]) {
      k.rod(
        [cabF + 0.03, lo + 0.01, side * w * 0.41],
        [cabF - 0.11, lo + 0.2, side * w * 0.06],
        0.012,
        '#36443d',
        'rubber',
      );
      k.box(front - 0.035, belt - 0.25, side * w * 0.355, 0.086, 0.176, w * 0.217, '#c1c7b1', 'shard', true);
      k.box(back - 0.033, belt - 0.23, side * w * 0.38, 0.076, 0.18, w * 0.128, '#965d4b', 'paint', true);
    }
    k.box(front + 0.035, 0.51, 0, 0.16, 0.14, w * 0.97, '#91988b', 'metal', true);
    k.box(back - 0.026, 0.47, 0, 0.17, 0.135, w * 0.96, '#7d877a', 'metal', true);
    k.box(front - 0.011, belt - 0.23, 0, 0.04, 0.23, w * 0.36, '#424b42', 'rubber');
    for (let n = 0; n < 5; n++)
      k.box(front + 0.024, belt - 0.331 + n * 0.044, 0, 0.023, 0.013, w * 0.34, '#959d8b', 'metal');
    k.box(front + 0.127, 0.53, 0, 0.022, 0.15, 0.37, '#c6bda3', 'paint');
    const driver = roofF - 0.55;
    seat(k, driver, lo - 0.12, -w * 0.245, bus ? 0.62 : 0.49);
    if (!bus) seat(k, driver, lo - 0.12, w * 0.245, 0.49);
    k.box(cabF - 0.24, lo + 0.049, 0, 0.48, 0.15, w * 0.88, '#51594f', 'rubber', true);
    let ring = k.geoCache.get('steering');
    if (!ring) {
      ring = new T.TorusGeometry(0.183, 0.023, 5, 14);
      k.geoCache.set('steering', ring);
    }
    k.put(ring, 'rubber', driver + 0.37, lo + 0.26, -w * 0.245, 1, 1, 1, '#393f36', [0.1, 1.18, 0]);
    k.rod([driver + 0.36, lo + 0.26, -w * 0.245], [cabF - 0.24, lo, -w * 0.245], 0.033, '#4e574b');
    if (light) {
      for (const side of [-1, 1]) seat(k, rear + 0.42, lo - 0.12, side * w * 0.245, 0.52);
    }
    if (bus) {
      for (let j = 0; j < 6; j++)
        for (const side of [-1, 1]) seat(k, back + 1.15 + j * 1.2, 1.09, side * 0.68, 0.78);
      for (const side of [-1, 1]) {
        k.box(0, 1.15, side * (w / 2 + 0.025), l - 0.25, 0.178, 0.018, '#8d594c', 'body');
        k.box(0, 0.99, side * (w / 2 + 0.035), l - 0.35, 0.052, 0.023, '#a37e65', 'paint');
      }
      k.box(0, h + 0.18, 0, 2.62, 0.23, 1.36, '#969c90', 'body', true);
      for (let j = 0; j < 10; j++) k.box(-1.13 + j * 0.24, h + 0.307, 0, 0.11, 0.017, 1.06, '#5b645c');
      k.local(front - 0.24, 0, 0, PI / 2, () => {
        k.box(0, 2.77, 0, 1.83, 0.39, 0.11, '#4b554b', 'rubber', true);
        k.sign(0, 2.77, 0.062, 1.72, 0.33, '04  /  MERIDIAN', '', '#bdad82', '#32382f');
      });
      k.sign(-1.2, 1.19, w * 0.5 + 0.04, 3.91, 0.29, 'MERIDIAN TRANSIT', '', '#d5c8ac', '#775c50');
    }
    if (boxTruck) cargo(k, l, w, h, v.kind === 'truck', v.open);
    if (v.kind === 'ambulance') {
      for (const side of [-1, 1]) {
        k.box(-0.37, 1.1, side * w * 0.506, l * 0.79, 0.21, 0.022, '#ab7361', 'body');
        k.box(-l * 0.27, 1.86, side * w * 0.504, 1.62, 1.29, 0.064, '#c3c7b7', 'body', true);
        k.sign(
          -l * 0.27,
          1.86,
          side * (w * 0.504 + 0.037),
          1.46,
          0.63,
          'MEDIC 04',
          'MERIDIAN RESCUE',
          '#5f746a',
          '#c5c8b8',
          side > 0 ? 0 : PI,
        );
      }
      k.box(roofF - 0.4, h + 0.137, 0, 0.33, 0.18, 1.51, '#5a737b', 'metal', true);
    }
    if (v.open && !bus && !boxTruck) {
      k.local(cabF - 0.14, 0, w * 0.518, 0.97, () => {
        const dl = light ? 1.07 : 1.16;
        k.box(-dl / 2, 0.773, 0, dl, 0.51, 0.083, v.color, 'body', true);
        k.box(-dl / 2, 0.774, -0.054, dl * 0.84, 0.34, 0.041, '#626c60', 'rubber', true);
        for (const a of [-dl + 0.036, -0.03])
          k.rod([a, 0.99, 0], [a - 0.07, hi - 0.085, 0], 0.027, '#899187');
        k.box(-dl / 2 - 0.07, hi - 0.09, 0, dl, 0.049, 0.056, '#838c7f', 'metal');
        k.box(-dl * 0.73, 0.866, 0.066, 0.145, 0.038, 0.041, '#a5ac9d', 'metal');
        k.solid('open-door/' + v.kind, -dl / 2, 0.9, 0, dl, 1.1, 0.075);
      });
    }
    // Keep angled-body colliders close to their silhouettes instead of blocking a rectangular street corner.
    const slices = 5;
    for (let j = 0; j < slices; j++)
      k.solid(v.kind + '/' + j, back + (l * (j + 0.5)) / slices, h * 0.5, 0, l / slices, h, w * 0.96);
  });
}
