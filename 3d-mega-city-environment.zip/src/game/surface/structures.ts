import * as T from 'three';
import type { TowerRecord } from '../cityPolish';
import { SurfaceKit as K, seeded, paintTexture, protectedPlaza, type V3 } from './SurfaceKit';
import type { Garden } from './reclamation';

export function deteriorateCity(city: T.Group) {
  const seen = new Set<T.Material>(),
    loader = new T.TextureLoader(),
    exteriorMaps: T.Texture[] = [];
  const applyMap = (m: T.MeshStandardMaterial, url: string) => {
    const next = loader.load('/materials/aftermath/' + url);
    next.wrapS = next.wrapT = T.RepeatWrapping;
    next.anisotropy = 4;
    next.colorSpace = T.SRGBColorSpace;
    m.map = next;
    m.needsUpdate = true;
    exteriorMaps.push(next);
  };
  const wear = new T.TextureLoader().load('/materials/aftermath/paint-wear.png');
  wear.wrapS = wear.wrapT = T.RepeatWrapping;
  exteriorMaps.push(wear);
  city.traverse((o) => {
    if (!(o instanceof T.Mesh)) return;
    const params = (o.geometry as T.BoxGeometry).parameters;
    if (
      o instanceof T.InstancedMesh &&
      params?.width === 0.28 &&
      params?.height === 0.03 &&
      o.material instanceof T.MeshBasicMaterial
    ) {
      const m = o.material;
      m.color.lerp(new T.Color('#707568'), 0.53);
      m.alphaMap = wear;
      m.alphaTest = 0.22;
      m.transparent = true;
      m.opacity = 0.69;
      m.needsUpdate = true;
    }
    if (
      o instanceof T.InstancedMesh &&
      o.material instanceof T.MeshStandardMaterial &&
      params?.width === 1 &&
      params?.height === 1 &&
      !o.material.transparent
    ) {
      const a = new T.Matrix4(),
        p = new T.Vector3(),
        q = new T.Quaternion(),
        s = new T.Vector3();
      let faded: T.InstancedMesh | null = null;
      for (let i = 0; i < o.count; i++) {
        o.getMatrixAt(i, a);
        a.decompose(p, q, s);
        if (
          (Math.abs(s.z - 3.45) < 0.001 && Math.abs(s.y - 0.013) < 0.0001) ||
          (Math.abs(s.x - 3.45) < 0.001 && Math.abs(s.y - 0.013) < 0.0001)
        ) {
          const shade = 0.32 + ((i * 17) % 24) * 0.012;
          o.setColorAt(i, new T.Color(shade, shade * 1.01, shade * 0.92));
          faded = o;
        }
      }
      if (faded?.instanceColor) faded.instanceColor.needsUpdate = true;
    }
    for (const material of Array.isArray(o.material) ? o.material : [o.material]) {
      if (seen.has(material)) continue;
      seen.add(material);
      if (material instanceof T.MeshStandardMaterial) {
        const src = (material.map?.image as HTMLImageElement | undefined)?.src || '';
        // The texture loader can still be pending; the existing facade shader is
        // a stable identifier and does not require replacing any original geometry.
        const cache = material.customProgramCacheKey();
        const match = cache.match(/^meridian-facade-(\d)$/);
        if (match) {
          const style = Number(match[1]);
          applyMap(material, 'weathered-' + ['curtain', 'bronze', 'stone', 'hotel'][style] + '.jpg');
          material.emissiveIntensity = 0.009;
          material.roughness = Math.min(0.85, material.roughness + 0.17);
          material.envMapIntensity = 0.6;
        } else if (
          src.includes('avenue-color') ||
          (material.normalScale.x === 0.26 && material.roughness === 0.82)
        ) {
          applyMap(material, 'fractured-asphalt.jpg');
          material.roughness = 0.89;
          material.color.set('#797e7b');
        } else if (material.transparent) {
          material.roughness = Math.max(0.33, material.roughness);
          material.color.lerp(new T.Color('#89978c'), 0.15);
        }
      } else if (material instanceof T.MeshBasicMaterial && !material.map) {
        material.color.lerp(new T.Color('#858a7b'), 0.44);
      }
    }
  });
  return exteriorMaps;
}

export function buildingDamage(k: K, towers: TowerRecord[]) {
  const r = seeded(83072);
  let bays = 0,
    shops = 0;
  const grades: number[] = [];
  towers.forEach((t, i) => {
    const grade = i % 9 === 0 ? 0 : 1 + ((i * 7 + 3) % 3);
    grades.push(grade);
    k.cell = 'envelope';
    k.owner = i;
    k.range = 185;
    const ph = Math.min(10, t.h * 0.18),
      w = t.w * 0.84,
      d = t.d * 0.84,
      sh = t.h * 0.62;
    if (grade > 0)
      for (let a = 0; a < (grade === 3 ? 3 : 2); a++)
        k.local(t.x, 0, t.z, (a * Math.PI) / 2, () => {
          const span = a % 2 ? d : w,
            depth = a % 2 ? w : d,
            nx = Math.max(4, Math.round(span / 2.15)),
            ny = Math.max(4, Math.round(sh / 3.6)),
            bw = span / nx - 0.17,
            bh = sh / ny - 0.31,
            start = Math.floor(r() * Math.max(1, nx - 3));
          const base = Math.floor(r() * Math.max(1, ny - 3));
          for (let j = 0; j < grade; j++)
            for (let v = 0; v < (grade > 1 ? 2 : 1); v++) {
              if (v === 1 && j === 1) continue;
              const xx = -span / 2 + bw * 0.5 + 0.09 + ((start + j) * span) / nx,
                yy = ph + ((base + v + 0.5) * sh) / ny,
                zz = depth / 2 + 0.125;
              k.put(k.plane, 'bay' + ((i + j + v) % 2), xx, yy, zz, bw, bh, 1, '#dfe3d8');
              bays++;
              if (grade === 3 && j === 0) {
                k.box(xx - bw * 0.48, yy, zz + 0.037, 0.07, bh + 0.07, 0.089, '#737f79', 'metal');
                k.box(xx + bw * 0.48, yy, zz + 0.037, 0.07, bh + 0.07, 0.089, '#737f79', 'metal');
                k.box(xx, yy - bh * 0.486, zz + 0.043, bw + 0.08, 0.1, 0.19, '#8a9184', 'metal');
                k.quad(
                  [xx - bw * 0.42, yy + bh * 0.45, zz + 0.053],
                  [xx - bw * 0.22, yy + bh * 0.45, zz + 0.06],
                  [xx - bw * 0.34, yy + bh * 0.23, zz + 0.13],
                  [xx - bw * 0.44, yy + bh * 0.19, zz + 0.1],
                  'shard',
                  '#9aaba5',
                );
              }
            }
          if (grade >= 2 && a === 0) {
            const storefront = t.d / 2 + 0.205,
              sx = -t.w * 0.287;
            k.put(
              k.plane,
              'bay' + ((i % 2) + 2),
              sx,
              2.251,
              storefront,
              Math.min(t.w * 0.293, 4.8),
              2.7,
              1,
              '#e7e7d8',
            );
            shops++;
            if (i % 3 === 0) {
              for (const [i, y] of [1.44, 2.57].entries())
                k.box(
                  sx,
                  y,
                  storefront + 0.052,
                  Math.min(t.w * 0.326, 5.1),
                  0.183,
                  0.073,
                  '#9e9c85',
                  'timber',
                  false,
                  [0, 0, i ? 0.19 : -0.14],
                );
            }
            if (grade === 3) {
              k.box(
                t.w * 0.23,
                3.61,
                storefront + 0.45,
                2.34,
                0.079,
                0.76,
                '#929282',
                'rust',
                false,
                [0.21, 0, -0.13],
              );
              k.rod(
                [t.w * 0.16, 4.08, storefront],
                [t.w * 0.16, 3.5, storefront + 0.69],
                0.021,
                '#6c7366',
                'metal',
              );
            }
          }
        });
    if (grade === 3) {
      const roof = t.h + 1.24;
      k.local(t.x, 0, t.z, 0, () => {
        k.box(
          -w * 0.2,
          roof + 0.71,
          d * 0.13,
          1.34,
          0.98,
          0.064,
          '#97a08d',
          'rust',
          false,
          [0.28, 0.17, 0.16],
        );
        k.box(w * 0.19, roof + 1.56, d * 0.15, 2.2, 0.04, 1.51, '#797e70', 'rust');
      });
    }
  });
  k.owner = -1;
  return { bays, shops, grades };
}
export function streetDamage(k: K, g: Garden) {
  const r = seeded(61033);
  k.cell = 'roadside';
  k.range = 94;
  const crackMap = paintTexture(512, 512, (c) => {
    const rr = seeded(13904);
    for (let i = 0; i < 3; i++) {
      let x = 45 + rr() * 36,
        y = 120 + rr() * 190;
      for (let j = 0; j < 13; j++) {
        const nx = x + 16 + rr() * 21,
          ny = y + (rr() - 0.46) * 48;
        c.lineCap = 'round';
        c.strokeStyle = '#b0b09877';
        c.lineWidth = 3.7;
        c.beginPath();
        c.moveTo(x + 1, y + 1);
        c.lineTo(nx + 1, ny + 1);
        c.stroke();
        c.strokeStyle = '#30382cee';
        c.lineWidth = 1.9 + rr() * 2.6;
        c.beginPath();
        c.moveTo(x, y);
        c.lineTo(nx, ny);
        c.stroke();
        if (j % 3 === 0) {
          c.strokeStyle = '#343c2f97';
          c.lineWidth = 1.4;
          c.beginPath();
          c.moveTo(nx, ny);
          c.lineTo(nx - 8, ny + 28);
          c.lineTo(nx + 8, ny + 47);
          c.stroke();
        }
        x = nx;
        y = ny;
      }
    }
  });
  k.mats.cracks = new T.MeshBasicMaterial({
    map: crackMap,
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
  });
  const lichen = paintTexture(128, 128, (c) => {
    const rr = seeded(185);
    for (let i = 0; i < 3100; i++) {
      const a = rr() * Math.PI * 2,
        d = rr() * 60,
        x = 64 + Math.cos(a) * d,
        y = 64 + Math.sin(a) * d;
      c.fillStyle = ['#66724735', '#9290772e', '#6f75483b', '#aaa48741'][i % 4];
      c.fillRect(x, y, 0.5 + rr() * 3, 0.5 + rr() * 2);
    }
  });
  k.mats.moss = new T.MeshBasicMaterial({
    map: lichen,
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
  });
  k.mats.groundWear = new T.MeshLambertMaterial({
    map: new T.TextureLoader().load('/materials/aftermath/road-patch.png', (t) => {
      t.colorSpace = T.SRGBColorSpace;
      t.anisotropy = 4;
    }),
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -2,
  });
  for (const [x, z, sz, angle] of [
    [-68, 4.8, 7.8, 0.82],
    [-64.7, -11.7, 9.3, 1.1],
    [-71, -20.5, 5.8, 0.17],
    [-65, -61.6, 8, 0.33],
    [-58.7, -72.4, 6.9, 2.4],
    [-91, 70.5, 8.35, 0.23],
    [105, -70, 9.1, 1.59],
    [46.3, -127.6, 5.8, 0.24],
    [70.6, 113.6, 6.3, 1.23],
    [-94, 38, 6.85, 2.77],
  ]) {
    const y = k.collision.getFloorHeight(x, z, z < -120 ? 6.7 : 0.35, 0.5);
    k.put(k.plane, 'groundWear', x, y + 0.073, z, sz, sz * 0.85, 1, '#d7d8c8', [-Math.PI / 2, 0, angle]);
  }
  for (const a of [-128, -68, 0, 68, 128])
    for (let t = -156; t < 158; t += 15 + r() * 12)
      for (const axis of [0, 1]) {
        const pos = a + (r() - 0.5) * 11,
          x = axis ? t : pos,
          z = axis ? pos : t;
        if (protectedPlaza(x, z, 7)) continue;
        const fl = k.collision.getFloorHeight(x, z, 0.3, 0.4);
        k.put(k.plane, 'cracks', x, fl + 0.069, z, 5.2 + r() * 6, 3.3 + r() * 4, 1, '#ffffff', [
          -Math.PI / 2,
          0,
          r() * 3,
        ]);
      }
  const clusters = [
    [-61, -20, 5.2],
    [-60, -66, 5.5],
    [-91, 74, 6],
    [-73, -4.7, 3.3],
    [113, -75, 4.1],
    [-77, -77, 4.4],
    [63, 115, 5.5],
    [-109, 44, 5.1],
  ];
  for (const [x, z, rad] of clusters) {
    const sy = k.collision.getFloorHeight(x, z, 0.3, 0.4);
    k.put(k.plane, 'moss', x, sy + 0.071, z, rad * 2.5, rad * 1.6, 1, '#e3dbbf', [-Math.PI / 2, 0, r() * 3]);
    for (let j = 0; j < 15; j++) {
      const a = r() * Math.PI * 2,
        d = rad * (0.4 + 0.83 * r()),
        xx = x + Math.cos(a) * d,
        zz = z + Math.sin(a) * d,
        sz = 0.06 + r() * 0.26,
        y = k.collision.getFloorHeight(xx, zz, 0.32, 0.4);
      k.put(
        k.fragments[j % 2],
        'stone',
        xx,
        y + sz * 0.33,
        zz,
        sz * 1.16,
        sz * 0.46,
        sz * 0.8,
        j % 3 === 0 ? '#9a9b8e' : '#b0afa1',
        [r() * 0.3, r() * 3, r() * 0.22],
      );
      if (j % 5 === 0) {
        k.put(k.plane, 'paper', xx + 0.3, y + 0.024, zz, 0.25, 0.17, 1, '#c3c0aa', [-Math.PI / 2, 0.025, a]);
      }
    }
  }
  const barrier = (x: number, z: number, ang: number, broken = false) =>
    k.local(x, 0, z, ang, () => {
      const width = broken ? 2.58 : 3.48;
      const geo = k.shape(
        'road-barrier' + width,
        (s) => {
          s.moveTo(-0.42, 0);
          s.lineTo(0.42, 0);
          s.lineTo(0.42, 0.17);
          s.lineTo(0.19, 0.68);
          s.lineTo(0.17, 0.94);
          s.lineTo(-0.17, 0.94);
          s.lineTo(-0.2, 0.68);
          s.lineTo(-0.42, 0.18);
          s.closePath();
        },
        width,
        0.017,
      );
      k.put(geo, 'stone', 0, 0.026, 0, 1, 1, 1, '#aaa99b', [0, Math.PI / 2, 0]);
      for (let j = 0; j < 5; j++)
        k.box(
          -width * 0.41 + j * width * 0.19,
          0.733,
          0.204,
          0.22,
          0.27,
          0.018,
          j % 2 ? '#5f6557' : '#bba16c',
          'paint',
          false,
          [0, 0, -0.29],
        );
      if (broken) {
        k.rod([width / 2, 0.44, 0.1], [width / 2 + 0.53, 0.29, 0.07], 0.018, '#817062', 'rust');
        k.rod([width / 2, 0.65, -0.1], [width / 2 + 0.31, 0.69, -0.19], 0.018, '#877768', 'rust');
      }
      k.solid('barrier', 0, 0.5, 0, width, 0.95, 0.84);
      k.shadow(0, 0, 0, width * 1.3, 1.73);
    });
  barrier(-62.5, -8.3, -0.14);
  barrier(-59.1, -5.8, 0.51, true);
  barrier(-54.1, -64.8, 0.27);
  barrier(-63.3, -57.8, -0.34, true);
  barrier(-87.3, 68, 0.12);
  barrier(71.7, 112.7, 0.48, true);
  const shelter = (x: number, z: number, yaw: number) =>
    k.local(x, 0, z, yaw, () => {
      k.box(0, 0.107, 0, 5.2, 0.21, 2.13, '#999e8d', 'stone');
      for (const side of [-1, 1]) {
        k.box(side * 2.31, 1.51, -0.77, 0.1, 2.81, 0.13, '#727f73', 'metal');
        k.box(side * 2.31, 0.273, -0.77, 0.23, 0.18, 0.26, '#9a9d8d', 'rust');
      }
      k.box(0, 2.87, -0.08, 5.08, 0.12, 1.83, '#83877b', 'rust', false, [0.05, 0, -0.023]);
      k.box(0, 1.45, -0.77, 0.075, 2.52, 0.086, '#7b8576', 'metal');
      k.quad(
        [-2.27, 0.39, -0.76],
        [-0.09, 0.39, -0.76],
        [-0.09, 2.77, -0.76],
        [-2.27, 2.77, -0.76],
        'glass',
        '#b5c1b3',
      );
      k.quad(
        [0.08, 0.39, -0.76],
        [2.23, 0.39, -0.76],
        [2.23, 0.81, -0.76],
        [1.29, 0.72, -0.76],
        'shard',
        '#94a59c',
      );
      k.quad(
        [0.08, 2.76, -0.76],
        [1.11, 2.76, -0.76],
        [0.71, 2.29, -0.76],
        [0.08, 2.48, -0.76],
        'shard',
        '#8d9e95',
      );
      for (let j = 0; j < 4; j++)
        k.box(-0.42, 0.665, -0.34 + j * 0.12, 3.5, 0.064, 0.096, '#a1967e', 'timber');
      k.box(-1.72, 0.426, -0.13, 0.17, 0.48, 0.68, '#69786b', 'metal');
      k.box(0.88, 0.423, -0.13, 0.18, 0.47, 0.68, '#69786b', 'metal');
      k.box(-0.42, 1.04, -0.48, 3.49, 0.47, 0.072, '#a7987d', 'timber');
      k.sign(-1.19, 2.03, -0.693, 1.7, 0.79, 'SERVICE SUSPENDED', 'MERIDIAN TRANSIT', '#d8cfb1', '#6a7162');
      k.solid('shelter-back', 0, 1.49, -0.76, 4.76, 2.92, 0.14);
      k.solid('shelter-seat', -0.42, 0.68, -0.15, 3.56, 0.91, 0.68);
    });
  shelter(-58.6, -22, Math.PI / 2);
  shelter(-103.8, 64.8, 0);
  k.local(-58.2, 0, -59.3, -0.04, () => {
    for (const side of [-1, 1]) {
      k.rod([side * 0.92, 0.03, -0.63], [side * 0.92, 1.84, 0.02], 0.035, '#849184');
      k.rod([side * 0.92, 0.03, 0.65], [side * 0.92, 1.84, 0.02], 0.035, '#849184');
    }
    k.box(0, 1.48, 0, 2.36, 0.96, 0.082, '#747f6d', 'metal');
    k.sign(0, 1.48, 0.049, 2.29, 0.89, 'EVACUATION', 'ASSEMBLY POINT  04', '#e4d9b7', '#786853');
    k.solid('evacuation-sign', 0, 0.95, 0, 2.4, 1.89, 0.6);
  });
  k.local(73.6, 0, 102, 0.18, () => {
    k.rod([0, 0.03, 0], [3.99, 0.16, 1.4], 0.073, '#788176', 'rust');
    k.box(3.38, 0.24, 1.21, 1.28, 0.064, 0.71, '#7d8875', 'metal', false, [0, 0, 0.11]);
    k.sign(3.38, 0.279, 1.21, 1.16, 0.58, 'EAST AVE', '', '#d5d6bf', '#627163');
  });
  // Slack service cables follow a damaged signal gantry, not an arbitrary skyline span.
  const wires: V3[][] = [
    [
      [-77, 5.69, -77],
      [-74.6, 4.61, -76.8],
      [-72.3, 4.25, -76.73],
      [-69.8, 4.38, -76.7],
      [-68.9, 3.16, -76.46],
      [-69, 1.68, -76.39],
    ],
    [
      [-77, 5.71, -77],
      [-77, 3.87, -76.86],
      [-77.3, 2.11, -76.83],
      [-77.13, 1.35, -76.75],
    ],
  ];
  for (const path of wires)
    for (let j = 0; j < path.length - 1; j++) k.rod(path[j], path[j + 1], 0.024, '#424c44', 'rubber');
  k.local(-68.9, 0, -76.46, 0, () => {
    k.box(0, 2.81, 0, 0.43, 0.98, 0.36, '#646d60', 'rust', true, [0.04, 0.13, 0.37]);
    for (let j = 0; j < 3; j++)
      k.cyl((1 - j) * 0.11, 3.09 - j * 0.277, 0.197, 0.103, 0.041, '#424c43', 'glass', [
        Math.PI / 2,
        0.13,
        0.37,
      ]);
  });
  k.local(-72.9, 0.02, -6.6, -0.59, () => {
    k.box(0, 0.57, 0, 0.91, 1.12, 0.54, '#a7a28b', 'body', true, [0.03, 0, 0.08]);
    k.box(0, 0.06, 0, 1.06, 0.11, 0.64, '#655f4c', 'rust');
    k.box(0.026, 1.23, -0.077, 0.64, 0.22, 0.36, '#7d826f', 'body', true);
    k.solid('abandoned-luggage', 0, 0.61, 0, 1.02, 1.22, 0.71);
  });
  for (const [xx, zz] of [
    [-67.4, 4.1],
    [-64.1, -17.3],
    [-57.9, -19.7],
    [-90.5, 74.7],
    [101.3, -74.8],
  ]) {
    const sy = k.collision.getFloorHeight(xx, zz, 0.3, 0.4);
    for (let j = 0; j < 10; j++) {
      const dx = (r() - 0.5) * 1.91,
        dz = (r() - 0.5) * 1.47,
        l = 0.11 + r() * 0.34;
      k.put(
        k.fragments[j % 2],
        'stone',
        xx + dx,
        sy + l * 0.12 + 0.02,
        zz + dz,
        l * 0.93,
        l * 0.13,
        l,
        '#7b7c6c',
        [r() * 0.14, r() * 3, r() * 0.15],
      );
    }
    g.cover(0, xx, sy + 0.015, zz, 0.61, 0.27, r() * PI);
  }
  for (const x of [-72, -70, -59]) g.cover(0, x, 0.02, -8 + (x + 69) * 0.33, 0.69, 0.43, r() * 3);
}
const PI = Math.PI;
