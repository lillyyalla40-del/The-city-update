import * as T from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import type { CollisionWorld, SolidBox } from '../collision';
import type { TowerRecord } from '../cityPolish';
import type { QualityPreset } from '../types';

export type V3 = [number, number, number];
type Part = { geo: T.BufferGeometry; matrix: T.Matrix4; color: T.Color };
type Batch = { mat: T.Material; parts: Part[]; range: number; owner: number; vegetation: boolean };
type Chunk = {
  mesh: T.Mesh;
  bounds: T.Box3;
  center: T.Vector3;
  radius: number;
  owner: number;
  range: number;
};
export const protectedPlaza = (x: number, z: number, r = 0) => Math.abs(x) < 25 + r && Math.abs(z) < 25 + r;
export function seeded(seed: number) {
  let s = seed;
  return () => (s = (s * 16807) % 2147483647) / 2147483647;
}
export function paintTexture(w: number, h: number, fn: (ctx: CanvasRenderingContext2D) => void) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  fn(c.getContext('2d')!);
  const t = new T.CanvasTexture(c);
  t.colorSpace = T.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

/** A separate surface-coordinate kit: it never receives a bunker mesh or material. */
export class SurfaceKit {
  readonly group = new T.Group();
  readonly solids: SolidBox[] = [];
  readonly mats: Record<string, T.Material> = {};
  readonly random = seeded(18203);
  readonly plane = new T.PlaneGeometry(1, 1);
  readonly wind = { value: 0 };
  readonly cube = new T.BoxGeometry(1, 1, 1);
  readonly rounded = new RoundedBoxGeometry(1, 1, 1, 1, 0.064);
  readonly tri = new T.BufferGeometry();
  readonly cylinder = new T.CylinderGeometry(1, 1, 1, 12);
  readonly disc = new T.CircleGeometry(1, 20);
  readonly fragments = [new T.DodecahedronGeometry(1, 0), new T.IcosahedronGeometry(1, 0)];
  readonly chunks: Chunk[] = [];
  readonly geoCache = new Map<string, T.BufferGeometry>();
  private economy = new Map<T.Material, T.Material>();
  private state = new T.Matrix4();
  private tmp = new T.Object3D();
  private batches = new Map<string, Batch>();
  private caches = new Set<T.BufferGeometry>();
  private matrices = new T.Matrix3();
  private lastX = Infinity;
  private lastZ = Infinity;
  private lastHeading = 10;
  private lastQuality = '';
  private timer = 0;
  owner = -1;
  range = 110;
  cell = 'street';
  constructor(
    readonly collision: CollisionWorld,
    private towers: TowerRecord[],
  ) {
    this.group.name = 'AFTERMATH / surface-only dressing';
    this.tri.setAttribute('position', new T.Float32BufferAttribute([0, 0, 0, 1, 0, 0, 0, 1, 0], 3));
    this.tri.setAttribute('uv', new T.Float32BufferAttribute([0, 0, 1, 0, 0, 1], 2));
    this.tri.computeVertexNormals();
    const loader = new T.TextureLoader();
    const load = (file: string) => {
      const t = loader.load(file);
      t.colorSpace = T.SRGBColorSpace;
      t.wrapS = t.wrapT = T.RepeatWrapping;
      t.anisotropy = 4;
      return t;
    };
    this.mats.metal = new T.MeshStandardMaterial({ color: 0xffffff, metalness: 0.55, roughness: 0.49 });
    this.mats.paint = new T.MeshStandardMaterial({ color: 0xffffff, metalness: 0.21, roughness: 0.69 });
    this.mats.body = new T.MeshStandardMaterial({
      color: 0xffffff,
      metalness: 0.23,
      roughness: 0.57,
      map: load('/materials/aftermath/body-patina.jpg'),
      side: T.DoubleSide,
    });
    const rustRough = load('/materials/aftermath/rusty_painted_metal-rough.jpg');
    rustRough.colorSpace = T.NoColorSpace;
    this.mats.rust = new T.MeshStandardMaterial({
      color: 0xffffff,
      metalness: 0.33,
      roughness: 0.94,
      map: load('/materials/aftermath/rusty_painted_metal-color.jpg'),
      roughnessMap: rustRough,
    });
    this.mats.rubber = new T.MeshStandardMaterial({ color: 0xffffff, metalness: 0.015, roughness: 0.95 });
    this.mats.stone = new T.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.93,
      metalness: 0.015,
      map: load('/materials/concrete-color.jpg'),
    });
    this.mats.timber = new T.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.86,
      metalness: 0.02,
      map: load('/materials/timber-color.jpg'),
    });
    this.mats.glass = new T.MeshStandardMaterial({
      color: '#a1bac0',
      metalness: 0.17,
      roughness: 0.24,
      transparent: true,
      opacity: 0.43,
      depthWrite: false,
      side: T.DoubleSide,
    });
    this.mats.shard = new T.MeshStandardMaterial({
      color: '#a0b5b3',
      metalness: 0.47,
      roughness: 0.2,
      side: T.DoubleSide,
    });
    this.mats.paper = new T.MeshLambertMaterial({ color: 0xffffff, side: T.DoubleSide });
    this.mats.dark = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.91, side: T.DoubleSide });
    this.mats.bakedShadow = new T.MeshBasicMaterial({
      map: paintTexture(96, 96, (c) => {
        const g = c.createRadialGradient(48, 48, 10, 48, 48, 47);
        g.addColorStop(0, 'rgba(13,16,14,.56)');
        g.addColorStop(0.52, 'rgba(13,16,14,.35)');
        g.addColorStop(1, 'rgba(13,16,14,0)');
        c.fillStyle = g;
        c.fillRect(0, 0, 96, 96);
      }),
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -1,
    });
    const windowMap = load('/materials/aftermath/window-atlas.jpg');
    for (let i = 0; i < 4; i++) {
      const g = new T.PlaneGeometry(1, 1),
        uv = g.attributes.uv;
      for (let n = 0; n < uv.count; n++)
        uv.setXY(
          n,
          ((i % 2) + 0.002 + uv.getX(n) * 0.996) / 2,
          (1 - Math.floor(i / 2) + 0.002 + uv.getY(n) * 0.996) / 2,
        );
      this.geoCache.set('window-bay-' + i, g);
    }
    this.mats.brokenWindow = new T.MeshStandardMaterial({
      color: '#c4c7ba',
      map: windowMap,
      roughness: 0.49,
      metalness: 0.18,
    });
  }
  local(x: number, y: number, z: number, az: number, fn: () => void) {
    const before = this.state.clone();
    this.tmp.position.set(x, y, z);
    this.tmp.rotation.set(0, az, 0);
    this.tmp.scale.set(1, 1, 1);
    this.tmp.updateMatrix();
    this.state.multiply(this.tmp.matrix);
    fn();
    this.state.copy(before);
  }
  put(
    geo: T.BufferGeometry,
    mat: string,
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    col: T.ColorRepresentation = '#ffffff',
    rot: V3 = [0, 0, 0],
  ) {
    if (mat.startsWith('bay')) {
      geo = this.geoCache.get('window-bay-' + mat.slice(3))!;
      mat = 'brokenWindow';
    }
    this.tmp.position.set(x, y, z);
    this.tmp.rotation.set(...rot);
    this.tmp.scale.set(w, h, d);
    this.tmp.updateMatrix();
    const matrix = this.state.clone().multiply(this.tmp.matrix);
    const e = matrix.elements;
    if (protectedPlaza(e[12], e[14])) return;
    const vegetation = mat.startsWith('flora'),
      key = [
        Math.floor(e[12] / 56),
        Math.floor(e[14] / 56),
        mat,
        this.range > 140 ? 'facade' : this.range > 100 ? 'main' : 'near',
        this.owner,
        vegetation ? geo.id : 0,
      ].join('/');
    let batch = this.batches.get(key);
    if (!batch) {
      batch = { mat: this.mats[mat], parts: [], range: this.range, owner: this.owner, vegetation };
      this.batches.set(key, batch);
    }
    batch.parts.push({ geo, matrix, color: new T.Color(col) });
    this.caches.add(geo);
  }
  box(
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    col: string,
    mat = 'paint',
    round = false,
    rot: V3 = [0, 0, 0],
  ) {
    this.put(round ? this.rounded : this.cube, mat, x, y, z, w, h, d, col, rot);
  }
  cyl(
    x: number,
    y: number,
    z: number,
    r: number,
    h: number,
    col: string,
    mat = 'metal',
    rot: V3 = [0, 0, 0],
  ) {
    this.put(this.cylinder, mat, x, y, z, r, h, r, col, rot);
  }
  rod(a: V3, b: V3, r: number, col: string, mat = 'metal') {
    const v = new T.Vector3(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
    const q = new T.Quaternion().setFromUnitVectors(new T.Vector3(0, 1, 0), v.clone().normalize()),
      e = new T.Euler().setFromQuaternion(q);
    this.cyl((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2, r, v.length(), col, mat, [
      e.x,
      e.y,
      e.z,
    ]);
  }
  quad(a: V3, b: V3, c: V3, d: V3, mat: string, col: string) {
    const g = new T.BufferGeometry();
    g.setAttribute('position', new T.Float32BufferAttribute([...a, ...b, ...c, ...d], 3));
    g.setAttribute('uv', new T.Float32BufferAttribute([0, 0, 1, 0, 1, 1, 0, 1], 2));
    g.setIndex([0, 1, 2, 0, 2, 3]);
    g.computeVertexNormals();
    this.put(g, mat, 0, 0, 0, 1, 1, 1, col);
  }
  shape(key: string, draw: (shape: T.Shape) => void, depth: number, bevel = 0.035) {
    let g = this.geoCache.get(key);
    if (!g) {
      const s = new T.Shape();
      draw(s);
      g = new T.ExtrudeGeometry(s, {
        depth: depth - 2 * bevel,
        bevelEnabled: bevel > 0,
        bevelSegments: 1,
        bevelSize: bevel,
        bevelThickness: bevel,
        steps: 1,
        curveSegments: 7,
      });
      g.translate(0, 0, -(depth - 2 * bevel) / 2);
      this.geoCache.set(key, g);
    }
    return g;
  }
  solid(id: string, x: number, y: number, z: number, w: number, h: number, d: number) {
    const b = new T.Box3(
      new T.Vector3(x - w / 2, y - h / 2, z - d / 2),
      new T.Vector3(x + w / 2, y + h / 2, z + d / 2),
    ).applyMatrix4(this.state);
    if (b.min.y < -0.005 || (b.min.x < 25 && b.max.x > -25 && b.min.z < 25 && b.max.z > -25))
      throw new Error('Surface exclusion boundary: ' + id);
    const s = this.collision.addSolid({
      id: 'aftermath/' + id,
      minX: b.min.x,
      maxX: b.max.x,
      minY: Math.max(0, b.min.y),
      maxY: b.max.y,
      minZ: b.min.z,
      maxZ: b.max.z,
    });
    this.solids.push(s);
  }
  shadow(x: number, y: number, z: number, w: number, d: number) {
    this.put(this.plane, 'bakedShadow', x, y + 0.066, z, w, d, 1, '#ffffff', [-Math.PI / 2, 0, 0]);
  }
  sign(
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    title: string,
    sub: string,
    fg: string,
    bg: string,
    yaw = 0,
  ) {
    const id = 'print/' + title + sub;
    if (!this.mats[id])
      this.mats[id] = new T.MeshStandardMaterial({
        map: paintTexture(512, 160, (c) => {
          const r = seeded(title.length * 63 + 91);
          c.fillStyle = bg;
          c.fillRect(0, 0, 512, 160);
          c.fillStyle = fg;
          c.textAlign = 'center';
          c.font = '700 46px Barlow Condensed, sans-serif';
          c.fillText(title, 256, sub ? 83 : 97, 478);
          if (sub) {
            c.font = '18px monospace';
            c.fillText(sub, 256, 123, 468);
          }
          c.strokeStyle = '#c7c5b480';
          c.strokeRect(6, 6, 500, 148);
          for (let j = 0; j < 2200; j++) {
            c.fillStyle = j % 3 ? '#42463c25' : '#e3dec42f';
            c.fillRect(r() * 512, r() * 160, 0.8 + r() * 3, r() * 4);
          }
          for (let i = 0; i < 9; i++) {
            c.fillStyle = '#463f3428';
            c.fillRect(r() * 511, 0, 1 + r() * 3, 28 + r() * 128);
          }
        }),
        roughness: 0.85,
        metalness: 0.12,
      });
    this.put(this.plane, id, x, y, z, w, h, 1, '#ffffff', [0, yaw, 0]);
  }
  finish() {
    const p = new T.Vector3(),
      n = new T.Vector3();
    for (const b of this.batches.values()) {
      let mesh: T.Mesh;
      if (b.vegetation) {
        const m = new T.InstancedMesh(b.parts[0].geo, b.mat, b.parts.length);
        b.parts.forEach((v, i) => {
          m.setMatrixAt(i, v.matrix);
          m.setColorAt(i, v.color);
        });
        m.computeBoundingSphere();
        m.computeBoundingBox();
        mesh = m;
      } else {
        let verts = 0,
          ids = 0;
        for (const v of b.parts) {
          verts += v.geo.attributes.position.count;
          ids += v.geo.index?.count || v.geo.attributes.position.count;
        }
        const positions = new Float32Array(verts * 3),
          normals = new Float32Array(verts * 3),
          uvs = new Float32Array(verts * 2),
          colors = new Float32Array(verts * 3),
          indices = verts > 65535 ? new Uint32Array(ids) : new Uint16Array(ids);
        let start = 0,
          cursor = 0;
        for (const v of b.parts) {
          const at = v.geo.attributes;
          this.matrices.getNormalMatrix(v.matrix);
          const count = at.position.count;
          for (let i = 0; i < count; i++) {
            p.fromBufferAttribute(at.position, i).applyMatrix4(v.matrix);
            n.fromBufferAttribute(at.normal, i).applyNormalMatrix(this.matrices);
            p.toArray(positions, (start + i) * 3);
            n.toArray(normals, (start + i) * 3);
            v.color.toArray(colors, (start + i) * 3);
            uvs[(start + i) * 2] = at.uv?.getX(i) || 0;
            uvs[(start + i) * 2 + 1] = at.uv?.getY(i) || 0;
          }
          const idx = v.geo.index;
          for (let j = 0; j < (idx?.count || count); j++) indices[cursor++] = start + (idx ? idx.getX(j) : j);
          start += count;
        }
        const g = new T.BufferGeometry();
        g.setAttribute('position', new T.BufferAttribute(positions, 3));
        g.setAttribute('normal', new T.BufferAttribute(normals, 3));
        g.setAttribute('color', new T.BufferAttribute(colors, 3));
        g.setAttribute('uv', new T.BufferAttribute(uvs, 2));
        g.setIndex(new T.BufferAttribute(indices, 1));
        g.computeBoundingBox();
        g.computeBoundingSphere();
        (b.mat as T.MeshStandardMaterial).vertexColors = true;
        mesh = new T.Mesh(g, b.mat);
      }
      mesh.name = 'Surface / ' + this.chunks.length;
      mesh.receiveShadow = true;
      mesh.castShadow = !b.mat.transparent && !b.vegetation && b.range >= 100;
      const bounds = (mesh instanceof T.InstancedMesh ? mesh.boundingBox : mesh.geometry.boundingBox)!;
      this.group.add(mesh);
      this.chunks.push({
        mesh,
        bounds,
        center: bounds.getCenter(new T.Vector3()),
        radius: bounds.getSize(p).length() * 0.5,
        owner: b.owner,
        range: b.range,
      });
    }
    this.batches.clear();
    for (const g of this.caches) if (!this.chunks.some((c) => c.mesh.geometry === g)) g.dispose();
    this.caches.clear();
  }
  update(dt: number, eye: T.Vector3, heading: number, q: QualityPreset, effects: boolean) {
    this.wind.value = effects ? this.wind.value + dt : 0;
    this.timer += dt;
    if (this.timer < 0.18 && this.lastQuality === q) return;
    if (
      Math.hypot(this.lastX - eye.x, this.lastZ - eye.z) < 1.8 &&
      Math.abs(heading - this.lastHeading) < 0.15 &&
      q === this.lastQuality
    )
      return;
    if (q !== this.lastQuality) {
      for (const c of this.chunks) {
        const base = (c.mesh.userData.balancedMaterial || c.mesh.material) as T.Material;
        c.mesh.userData.balancedMaterial = base;
        if (!(base instanceof T.MeshStandardMaterial)) continue;
        if (q !== 'mobile') {
          c.mesh.material = base;
          continue;
        }
        let low = this.economy.get(base);
        if (!low) {
          low = new T.MeshLambertMaterial({
            color: base.color,
            map: base.map,
            transparent: base.transparent,
            opacity: base.opacity,
            vertexColors: base.vertexColors,
            side: base.side,
            depthWrite: base.depthWrite,
            alphaTest: base.alphaTest,
          });
          this.economy.set(base, low);
        }
        c.mesh.material = low;
      }
    }
    this.timer = 0;
    this.lastX = eye.x;
    this.lastZ = eye.z;
    this.lastHeading = heading;
    this.lastQuality = q;
    const factor = q === 'mobile' ? 0.56 : q === 'balanced' ? 0.83 : 1;
    for (const c of this.chunks) {
      const dx = Math.max(c.bounds.min.x - eye.x, 0, eye.x - c.bounds.max.x),
        dz = Math.max(c.bounds.min.z - eye.z, 0, eye.z - c.bounds.max.z);
      c.mesh.visible = dx * dx + dz * dz < (c.range * factor) ** 2;
      if (!c.mesh.visible || c.owner < 0 || dx * dx + dz * dz < 24 * 24) continue;
      // Conservative segment test against solid podiums. Shrinking by the chunk
      // radius avoids popping partially visible details at building corners.
      for (let i = 0; i < this.towers.length; i++) {
        if (i === c.owner) continue;
        const a = this.towers[i],
          hw = a.w * 0.5 - c.radius,
          hd = a.d * 0.5 - c.radius;
        if (hw <= 0 || hd <= 0) continue;
        const vx = c.center.x - eye.x,
          vz = c.center.z - eye.z;
        const t1 = (a.x - hw - eye.x) / (vx || 1e-9),
          t2 = (a.x + hw - eye.x) / (vx || 1e-9),
          t3 = (a.z - hd - eye.z) / (vz || 1e-9),
          t4 = (a.z + hd - eye.z) / (vz || 1e-9);
        const near = Math.max(Math.min(t1, t2), Math.min(t3, t4), 0.001),
          far = Math.min(Math.max(t1, t2), Math.max(t3, t4), 0.95);
        if (near < far && eye.y + (c.center.y - eye.y) * near + c.radius < Math.min(10, a.h * 0.18)) {
          c.mesh.visible = false;
          break;
        }
      }
    }
  }
  dispose() {
    this.economy.forEach((m) => m.dispose());
    this.economy.clear();
    const textures = new Set<T.Texture>();
    for (const m of Object.values(this.mats)) {
      for (const v of Object.values(m)) if (v instanceof T.Texture) textures.add(v);
      m.dispose();
    }
    textures.forEach((t) => t.dispose());
  }
}
