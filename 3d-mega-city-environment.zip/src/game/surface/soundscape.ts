import { worldAudio } from '../../ambience';

type Anchor = { x: number; y: number; z: number };
type Emitter = Anchor & {
  type: 'leaves' | 'wire' | 'sign' | 'building' | 'debris';
  range: number;
  cooldown: number;
};
type Voice = {
  source: AudioBufferSourceNode | OscillatorNode;
  gain: GainNode;
  panner: PannerNode;
  filter?: BiquadFilterNode;
  end: number;
};

/** Only the existing listener is shared. The surface bus is disconnected at the ramp. */
export class AbandonedSoundscape {
  readonly emitters: Emitter[] = [
    { type: 'sign', x: -58.2, y: 1.5, z: -59.3, range: 28, cooldown: 4.8 },
    { type: 'sign', x: -58.6, y: 2.6, z: -22, range: 26, cooldown: 3.1 },
    { type: 'wire', x: -77, y: 1.5, z: -77, range: 19, cooldown: 0 },
    { type: 'leaves', x: 100, y: 1.8, z: -90, range: 33, cooldown: 1.8 },
    { type: 'leaves', x: -107, y: 1.3, z: 44, range: 23, cooldown: 1.6 },
    { type: 'leaves', x: -62.4, y: 0.5, z: -19, range: 12, cooldown: 2.4 },
    { type: 'debris', x: -72.6, y: 0.13, z: -4.7, range: 19, cooldown: 3.5 },
    { type: 'building', x: -99, y: 16, z: -96, range: 72, cooldown: 13 },
    { type: 'building', x: -97, y: 9, z: 117, range: 38, cooldown: 8 },
    { type: 'sign', x: -103.8, y: 2.7, z: 64.8, range: 24, cooldown: 5 },
    { type: 'debris', x: 72.5, y: 0.19, z: 112.7, range: 29, cooldown: 7 },
  ];
  active = false;
  readonly statistics = { events: 0, voices: 0, last: '' };
  private bus: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private voices: Voice[] = [];
  private ctx: AudioContext | null = null;
  private timer = 0;
  private buzz: Voice | null = null;
  private next = 2.8;
  private init(c: AudioContext) {
    this.ctx = c;
    this.bus = c.createGain();
    this.bus.gain.value = 0;
    this.bus.connect(c.destination);
    this.noise = c.createBuffer(1, Math.floor(c.sampleRate * 2.73), c.sampleRate);
    const a = this.noise.getChannelData(0);
    let prev = 0;
    for (let i = 0; i < a.length; i++) {
      prev = prev * 0.84 + (Math.random() * 2 - 1) * 0.16;
      a[i] = prev;
    }
  }
  private voice(e: Emitter, len: number, move: number) {
    const c = this.ctx!,
      at = c.currentTime,
      p = c.createPanner(),
      g = c.createGain();
    p.distanceModel = 'inverse';
    p.panningModel = 'equalpower';
    p.refDistance = e.type === 'leaves' ? 3.4 : 2.8;
    p.maxDistance = e.range;
    p.rolloffFactor = 1.12;
    if (p.positionX) {
      p.positionX.value = e.x;
      p.positionY.value = e.y;
      p.positionZ.value = e.z;
    } else p.setPosition(e.x, e.y, e.z);
    g.connect(p);
    p.connect(this.bus!);
    let src: AudioBufferSourceNode | OscillatorNode, f: BiquadFilterNode | undefined;
    const tone = e.type === 'wire' || e.type === 'building' || e.type === 'sign';
    if (tone) {
      const s = c.createOscillator();
      s.type = e.type === 'wire' ? 'sawtooth' : 'triangle';
      s.frequency.setValueAtTime((e.type === 'wire' ? 93 : e.type === 'sign' ? 480 : 155) * move, at);
      s.frequency.exponentialRampToValueAtTime(
        (e.type === 'wire' ? 95 : e.type === 'sign' ? 339 : 92) * move,
        at + len,
      );
      f = c.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = e.type === 'wire' ? 480 : 1430;
      src = s;
    } else {
      const s = c.createBufferSource();
      s.buffer = this.noise;
      s.loop = true;
      s.playbackRate.value = move;
      f = c.createBiquadFilter();
      f.type = 'bandpass';
      f.frequency.value = e.type === 'leaves' ? 2180 : 1280;
      f.Q.value = 0.62;
      src = s;
    }
    src.connect(f);
    f.connect(g);
    g.gain.setValueAtTime(0.00001, at);
    g.gain.exponentialRampToValueAtTime(
      e.type === 'wire' ? 0.014 : e.type === 'leaves' ? 0.16 : e.type === 'debris' ? 0.2 : 0.049,
      at + Math.min(len * 0.2, 0.23),
    );
    g.gain.exponentialRampToValueAtTime(0.00001, at + len);
    const v: Voice = { source: src, filter: f, gain: g, panner: p, end: at + len };
    this.voices.push(v);
    src.start(at);
    src.stop(at + len + 0.02);
    this.statistics.events++;
    this.statistics.last = e.type;
    src.onended = () => {
      src.disconnect();
      f?.disconnect();
      g.disconnect();
      p.disconnect();
      this.voices = this.voices.filter((a) => a !== v);
      if (this.buzz === v) this.buzz = null;
    };
    return v;
  }
  stop() {
    if (!this.active) return;
    this.active = false;
    if (this.bus && this.ctx) {
      this.bus.gain.cancelScheduledValues(this.ctx.currentTime);
      this.bus.gain.value = 0;
    }
    for (const v of this.voices) {
      v.gain.gain.value = 0;
      try {
        v.source.stop();
      } catch {
        /* An already-ended voice needs no release. */
      }
    }
    this.buzz = null;
    this.statistics.voices = 0;
  }
  update(dt: number, pos: Anchor) {
    if (
      pos.y < -0.4 ||
      !worldAudio.enabled ||
      worldAudio.paused ||
      document.hidden ||
      worldAudio.context?.state !== 'running'
    ) {
      this.stop();
      return;
    }
    if (!this.bus) this.init(worldAudio.context);
    this.active = true;
    this.timer += dt;
    this.next -= dt;
    if (this.timer < 0.22) return;
    const advance = this.timer;
    this.timer = 0;
    this.bus!.gain.setTargetAtTime(worldAudio.volume * 0.7, this.ctx!.currentTime, 0.12);
    for (const e of this.emitters) {
      e.cooldown -= advance;
      const distance = Math.hypot(pos.x - e.x, pos.y + 1.6 - e.y, pos.z - e.z);
      if (distance > e.range || e.cooldown > 0 || this.voices.length >= 3) continue;
      if (e.type === 'wire') {
        if (!this.buzz) {
          this.buzz = this.voice(e, 2.5 + Math.random() * 2.7, 0.975 + Math.random() * 0.05);
          e.cooldown = 3.8 + Math.random() * 3;
        }
        continue;
      }
      if (this.next > 0) continue;
      const len =
        e.type === 'leaves'
          ? 1.15 + Math.random() * 1.5
          : e.type === 'building'
            ? 0.75 + Math.random() * 0.7
            : e.type === 'sign'
              ? 0.13 + Math.random() * 0.2
              : 0.31 + Math.random() * 0.35;
      this.voice(e, len, 0.82 + Math.random() * 0.35);
      e.cooldown = (e.type === 'building' ? 22 : e.type === 'leaves' ? 5 : 10) * (1 + Math.random());
      this.next = 1.8 + Math.random() * 3.8;
    }
    this.statistics.voices = this.voices.length;
  }
  dispose() {
    this.stop();
    this.bus?.disconnect();
    this.bus = null;
    this.noise = null;
  }
}
