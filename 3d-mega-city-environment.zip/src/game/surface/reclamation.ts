import * as T from 'three';
import { SurfaceKit as K, seeded, protectedPlaza } from './SurfaceKit';
import type { TowerRecord } from '../cityPolish';

export function createReclamation(k: K) {
  const treeAnchors: { x: number; z: number; height: number }[] = [];
  const atlas = document.createElement('canvas');
  atlas.width = atlas.height = 1024;
  const c = atlas.getContext('2d')!,
    r = seeded(18194);
  const leaf = (x: number, y: number, a: number, size: number, color: string) => {
    c.save();
    c.translate(x, y);
    c.rotate(a);
    c.fillStyle = color;
    c.beginPath();
    c.moveTo(0, 0);
    c.bezierCurveTo(-size * 0.5, -size * 0.23, -size * 0.44, -size * 0.8, 0, -size);
    c.bezierCurveTo(size * 0.4, -size * 0.72, size * 0.37, -size * 0.21, 0, 0);
    c.fill();
    c.strokeStyle = '#bdc09366';
    c.lineWidth = 0.6;
    c.beginPath();
    c.moveTo(0, 0);
    c.lineTo(0, -size * 0.87);
    c.stroke();
    c.restore();
  };
  const palette = ['#788257', '#8f9568', '#5d714d', '#66764d', '#a8a37b', '#79875c'];
  const branch = (x: number, y: number, len: number, ang: number, depth: number) => {
    const nx = x + Math.sin(ang) * len,
      ny = y - Math.cos(ang) * len;
    c.strokeStyle = depth > 2 ? '#756f53' : '#7c805c';
    c.lineWidth = depth > 2 ? depth * 1.07 : Math.max(0.8, depth * 0.73);
    c.beginPath();
    c.moveTo(x, y);
    c.quadraticCurveTo(x + Math.sin(ang - 0.12) * len * 0.5, (y + ny) / 2, nx, ny);
    c.stroke();
    if (depth < 3) {
      for (let i = 0; i < 9; i++) {
        const t = r();
        leaf(
          x + (nx - x) * t + (r() - 0.5) * 14,
          y + (ny - y) * t + (r() - 0.5) * 16,
          ang + (r() - 0.5) * 3,
          6 + r() * 12,
          palette[Math.floor(r() * 6)],
        );
      }
    }
    if (depth > 0) {
      branch(nx, ny, len * (0.59 + r() * 0.15), ang - 0.27 - r() * 0.37, depth - 1);
      branch(nx, ny, len * (0.59 + r() * 0.13), ang + 0.25 + r() * 0.41, depth - 1);
      if (depth === 3) branch(nx, ny, len * 0.68, ang + (r() - 0.5) * 0.23, depth - 1);
    }
  };
  c.save();
  c.beginPath();
  c.rect(2, 2, 508, 508);
  c.clip();
  for (let i = 0; i < 230; i++) {
    const x = 245 + (r() - 0.5) * 286,
      y = 490 - r() * 18,
      tx = x + (r() - 0.5) * 145,
      ty = 155 + r() * 235;
    const bend = (r() - 0.5) * 52;
    c.fillStyle = palette[Math.floor(r() * 6)];
    c.beginPath();
    c.moveTo(x, y);
    c.quadraticCurveTo(x + bend, y - (y - ty) * 0.49, tx, ty);
    c.quadraticCurveTo(x + bend + 3, y - (y - ty) * 0.45, x + 1.5 + r() * 3.1, y);
    c.fill();
  }
  for (let i = 0; i < 18; i++) {
    const x = 241 + (r() - 0.5) * 234,
      y = 485,
      tx = x + (r() - 0.5) * 120,
      ty = 49 + r() * 205;
    c.strokeStyle = '#a7a17b';
    c.lineWidth = 1.7;
    c.beginPath();
    c.moveTo(x, y);
    c.quadraticCurveTo(x + (tx - x) * 0.42, 300, tx, ty);
    c.stroke();
    for (let j = 0; j < 8; j++) {
      leaf(tx + j * 0.71, ty + j * 4, j % 2 ? 0.54 : -0.68, 6 + r() * 6, '#b4ac85');
    }
    if (i % 3 === 0)
      for (let j = 0; j < 6; j++)
        leaf(x + ((tx - x) * j) / 7, y - ((y - ty) * j) / 7, j % 2 ? 0.85 : -0.8, 22 + r() * 15, '#7d8a60');
  }
  c.restore();
  c.save();
  c.translate(512, 0);
  c.beginPath();
  c.rect(3, 3, 506, 505);
  c.clip();
  for (let j = 0; j < 8; j++) branch(245 + (r() - 0.5) * 38, 491, 88 + r() * 32, (r() - 0.5) * 0.8, 4);
  c.restore();
  c.save();
  c.translate(0, 512);
  c.beginPath();
  c.rect(2, 1, 508, 508);
  c.clip();
  for (let j = 0; j < 17; j++) {
    let x = 22 + r() * 464,
      y = -3 - r() * 19;
    const steps = 8 + Math.floor(r() * 16);
    for (let q = 0; q < steps; q++) {
      const xx = x + (r() - 0.5) * 27,
        yy = y + 14 + r() * 9;
      c.lineWidth = 2.3 - q / steps;
      c.strokeStyle = '#696749';
      c.beginPath();
      c.moveTo(x, y);
      c.lineTo(xx, yy);
      c.stroke();
      for (let jj = 0; jj < 5; jj++)
        leaf(
          xx + (r() - 0.5) * 24,
          yy + (r() - 0.5) * 17,
          (r() - 0.5) * 5.5,
          9 + r() * 17,
          palette[Math.floor(r() * 4)],
        );
      x = xx;
      y = yy;
    }
  }
  c.restore();
  c.save();
  c.translate(512, 512);
  c.beginPath();
  c.rect(2, 2, 508, 507);
  c.clip();
  branch(252, 504, 120, 0.01, 5);
  branch(253, 475, 93, -0.29, 4);
  branch(251, 458, 86, 0.32, 4);
  c.restore();
  const texture = new T.CanvasTexture(atlas);
  texture.colorSpace = T.SRGBColorSpace;
  texture.anisotropy = 4;
  const material = new T.MeshLambertMaterial({
    map: texture,
    alphaTest: 0.26,
    side: T.DoubleSide,
    color: 0xffffff,
    depthWrite: true,
  });
  material.name = 'Leaf and grass cutout atlas';
  material.onBeforeCompile = (s) => {
    s.uniforms.uAtmoWind = k.wind;
    s.vertexShader =
      'uniform float uAtmoWind;\n' +
      s.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
      #ifdef USE_INSTANCING
      float phase=instanceMatrix[3].x*.17+instanceMatrix[3].z*.13;
      transformed.x+=(sin(uAtmoWind*.83+phase)+.3*sin(uAtmoWind*1.7+phase*1.2))*.024*pow(max(0.0,position.y),1.6);
      #endif`,
      );
  };
  k.mats.flora = material;
  const geos: T.BufferGeometry[] = [];
  for (let n = 0; n < 4; n++) {
    const planes = n === 2 ? 1 : 3,
      positions: number[] = [],
      uvs: number[] = [],
      normals: number[] = [],
      index: number[] = [];
    for (let i = 0; i < planes; i++) {
      const a = (i * Math.PI) / planes,
        cs = Math.cos(a),
        sn = Math.sin(a),
        base = positions.length / 3;
      for (const [x, y, u, v] of [
        [-0.5, 0, 0, 0],
        [0.5, 0, 1, 0],
        [0.5, 1, 1, 1],
        [-0.5, 1, 0, 1],
      ]) {
        positions.push(x * cs, y, x * sn);
        normals.push(-sn, 0.19, cs);
        uvs.push(((n % 2) + 0.003 + 0.994 * u) / 2, (1 - Math.floor(n / 2) + 0.003 + 0.994 * v) / 2);
      }
      index.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
    const g = new T.BufferGeometry();
    g.setAttribute('position', new T.Float32BufferAttribute(positions, 3));
    g.setAttribute('normal', new T.Float32BufferAttribute(normals, 3));
    g.setAttribute('uv', new T.Float32BufferAttribute(uvs, 2));
    g.setIndex(index);
    geos.push(g);
  }
  const cover = (
    kind: number,
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    angle = 0,
    tint = '#c7cbb3',
  ) => {
    k.put(geos[kind], 'flora', x, y, z, w, h, w, tint, [0, angle, 0]);
    if (kind === 3) treeAnchors.push({ x, z, height: h });
  };
  return { cover, geos, treeAnchors };
}
export type Garden = ReturnType<typeof createReclamation>;

export function seedStreetEdges(k: K, g: Garden, towers: TowerRecord[]) {
  const r = seeded(76491);
  k.cell = 'planting';
  k.owner = -1;
  k.range = 78;
  for (const road of [-128, -68, 0, 68, 128])
    for (const side of [-1, 1])
      for (const axis of [0, 1]) {
        for (let p = -160; p < 165; p += 5 + r() * 8) {
          const x = axis ? p : road + side * (9.7 + r() * 1.16),
            z = axis ? road + side * (9.7 + r() * 1.16) : p;
          if (
            protectedPlaza(x, z, 3) ||
            Math.min(...[-128, -68, 0, 68, 128].map((a) => Math.abs(a - p))) < 12.5
          )
            continue;
          const moist = x > 29 && z < 0 ? 0.83 : x < 0 && z > 0 ? 0.55 : 0.36;
          if (r() > moist) continue;
          for (let j = 0; j < 1 + Math.floor(r() * 4); j++) {
            const px = x + (r() - 0.5) * 2.5,
              pz = z + (r() - 0.5) * 2.5,
              sz = 0.65 + r() * 0.72;
            g.cover(
              0,
              px,
              k.collision.getFloorHeight(px, pz, 0.35, 0.4) + 0.011,
              pz,
              sz,
              sz * (0.33 + r() * 0.29),
              r() * 3.2,
            );
          }
        }
      }
  // Rain runoff and wheel wells are intentional pockets of growth, not a citywide scatter.
  for (const [x, z, rr, n] of [
    [-62.4, -21, 4.2, 22],
    [-92, 72, 3.5, 16],
    [98, -98, 7.4, 33],
    [-99, 39, 8.1, 28],
    [42, -98, 10, 30],
    [111, -75.2, 3.4, 22],
    [-72, -4.5, 2.8, 15],
  ]) {
    for (let i = 0; i < n; i++) {
      const a = r() * Math.PI * 2,
        d = rr * (0.7 + r() * 0.5),
        xx = x + Math.cos(a) * d,
        zz = z + Math.sin(a) * d;
      g.cover(
        i % 7 === 0 ? 1 : 0,
        xx,
        k.collision.getFloorHeight(xx, zz, 0.3, 0.4) + 0.02,
        zz,
        0.71 + r() * 0.8,
        0.31 + r() * 0.78,
        r() * 3.1,
      );
    }
  }
  k.range = 135;
  for (const [x, z, h] of [
    [-109, 49, 3.1],
    [-86, 31, 2.1],
    [111, -110, 3.4],
    [86, -85, 2.8],
    [50, -111, 2.9],
  ]) {
    const sy = k.collision.getFloorHeight(x, z, 0.35, 0.5);
    g.cover(3, x, sy, z, h * 0.68, h, r() * 3.1);
    k.solid('sapling', x, sy + h * 0.32, z, 0.15, h * 0.64, 0.15);
  }
  // Isolated volunteer trees at the transit stop and service-road drains.
  for (const [x, z, h] of [
    [-78.9, -21.6, 3.7],
    [-57.7, -37.4, 4.1],
    [-95.9, 58.5, 3.2],
  ]) {
    const sy = k.collision.getFloorHeight(x, z, 0.3, 0.4);
    g.cover(3, x, sy, z, h * 0.64, h, -0.37);
    k.solid('curb-sapling', x, sy + h * 0.31, z, 0.16, h * 0.62, 0.16);
  }
  towers.forEach((t, i) => {
    if (i % 5 !== 2 && !(t.x > 30 && t.z < 0 && i % 3 === 0)) return;
    k.owner = i;
    k.range = 145;
    const ph = Math.min(10, t.h * 0.18);
    for (const face of [0, 1])
      k.local(t.x, 0, t.z, (face * Math.PI) / 2, () => {
        const w = (face ? t.d : t.w) * 0.84,
          d = (face ? t.w : t.d) * 0.84;
        const ht = ph + 2 + r() * 8,
          spread = 3 + r() * 4;
        const xx = (r() - 0.5) * w * 0.5;
        g.cover(2, xx, ht - spread, d * 0.5 + 0.19, Math.min(w * 0.7, spread), spread, 0, '#b6bfa3');
        if (i % 2 === 0) g.cover(2, xx + 0.6, 1.02, (face ? t.w : t.d) * 0.5 + 0.34, 2.2, 3.3);
      });
  });
  k.owner = -1;
}
