import * as T from 'three';
import { SurfaceKit, protectedPlaza, seeded } from './SurfaceKit';
import { abandonedVehicle, VEHICLE_SITES } from './vehicles';
import { buildingDamage, deteriorateCity, streetDamage } from './structures';
import { createReclamation, seedStreetEdges } from './reclamation';
import { AbandonedSoundscape } from './soundscape';
import type { polishCity } from '../cityPolish';
import type { CollisionWorld } from '../collision';
import type { QualityPreset } from '../types';

export function createAftermath(
  city: T.Group,
  detail: ReturnType<typeof polishCity>,
  collision: CollisionWorld,
) {
  const k = new SurfaceKit(collision, detail.towers),
    r = seeded(182),
    sound = new AbandonedSoundscape();
  const maps = deteriorateCity(city),
    garden = createReclamation(k),
    damage = buildingDamage(k, detail.towers);
  for (const v of VEHICLE_SITES) abandonedVehicle(k, v);
  // Retrofit the original parked fleet. Keep its bodies, wheels, locations,
  // trim, and existing colliders, adding dirt and failed glazing on top.
  const oldFleet: { x: number; z: number; kind: string }[] = [];
  city.children.forEach((m) => {
    if (!(m instanceof T.InstancedMesh)) return;
    const p = (m.geometry as T.BoxGeometry).parameters;
    if (!p || !((p.width === 2 && p.height === 0.85) || (p.width === 2.7 && p.height === 2.8))) return;
    const bus = p.width === 2.7;
    const matrix = new T.Matrix4(),
      pos = new T.Vector3(),
      rotation = new T.Quaternion(),
      size = new T.Vector3(),
      color = new T.Color();
    for (let i = 0; i < m.count; i++) {
      m.getMatrixAt(i, matrix);
      matrix.decompose(pos, rotation, size);
      const yaw = new T.Euler().setFromQuaternion(rotation).y;
      oldFleet.push({ x: pos.x, z: pos.z, kind: bus ? 'bus' : 'sedan' });
      if (m.instanceColor) {
        m.getColorAt(i, color);
        color.lerp(new T.Color('#8e8c7d'), 0.36 + 0.11 * (i % 3));
        m.setColorAt(i, color);
      }
      k.local(pos.x, 0, pos.z, yaw, () => {
        k.cell = 'fleet-refit';
        k.range = 77;
        if (bus) {
          for (const side of [-1, 1]) {
            k.box(0, 1.38, side * 1.385, 9.03, 0.19, 0.027, '#a58a76', 'body');
            for (const [j, zz] of [-2.13, 0.51, 3.15].entries()) {
              k.put(k.plane, 'bay' + (j % 2), side * 1.393, 2.09, zz, 1.11, 0.91, 1, '#a9b5a5', [
                0,
                (side * Math.PI) / 2,
                0,
              ]);
            }
          }
          k.local(0, 0, 4.748, 0, () =>
            k.sign(0, 2.72, 0, 2.18, 0.3, 'NOT IN SERVICE', '', '#c6bb92', '#40473d'),
          );
        } else {
          for (const side of [-1, 1]) {
            k.box(side * 1.002, 0.61, -0.43, 0.017, 0.17, 1.82, '#7b8070', 'body');
            if ((i + side) % 3 === 0) {
              k.put(k.plane, 'bay1', side * 0.922, 1.36, 0.43, 0.66, 0.37, 1, '#9da799', [
                0,
                (side * Math.PI) / 2,
                0,
              ]);
            }
          }
          if (i % 4 === 0) {
            k.box(-0.41, 1.091, 1.52, 0.62, 0.015, 0.52, '#8e8e79', 'body', true);
            k.local(-1.013, 0, 0.91, -0.71, () => {
              k.box(0, 0.82, -0.58, 0.063, 0.51, 1.13, '#899487', 'body', true);
              k.box(-0.044, 0.81, -0.58, 0.035, 0.29, 0.91, '#546156', 'rubber');
              k.rod([0, 1.05, -1.1], [0, 1.52, -1.03], 0.024, '#8d988c');
              k.rod([0, 1.52, -1.03], [0, 1.5, -0.21], 0.024, '#8d988c');
              k.rod([0, 1.5, -0.21], [0, 1.05, -0.035], 0.024, '#8d988c');
              k.solid('original-open-door', 0, 0.9, -0.55, 0.09, 1.09, 1.12);
            });
          }
        }
      });
    }
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
  });
  streetDamage(k, garden);
  seedStreetEdges(k, garden, detail.towers);
  // A damaged lamp base remains at the curb. The bent shaft is a separate asset.
  k.cell = 'fallen-streetlight';
  k.owner = -1;
  k.range = 95;
  k.local(73.6, 0.02, 99.7, -0.42, () => {
    k.cyl(0, 0.19, 0, 0.29, 0.38, '#878b78', 'rust');
    k.rod([0, 0.39, 0], [0.45, 0.92, 0.41], 0.105, '#828d80', 'metal');
    k.rod([0.45, 0.92, 0.41], [4.72, 0.19, 0.52], 0.087, '#737f72', 'metal');
    k.rod([4.72, 0.19, 0.52], [5.58, 0.35, 1.18], 0.061, '#7b8477', 'metal');
    k.box(5.58, 0.28, 1.18, 1.02, 0.18, 0.4, '#8f9587', 'metal', true, [0.2, 0.38, -0.1]);
  });
  k.finish();
  city.add(k.group);
  const loader = new T.TextureLoader(),
    sky = loader.load('/materials/aftermath/overcast-sky.jpg');
  sky.colorSpace = T.SRGBColorSpace;
  const reflection = loader.load('/materials/aftermath/overcast-sky.jpg');
  reflection.mapping = T.EquirectangularReflectionMapping;
  reflection.colorSpace = T.SRGBColorSpace;
  const dustG = new T.BufferGeometry(),
    dustPositions = new Float32Array(28 * 3),
    seeds = Array.from({ length: 28 * 4 }, () => r());
  dustG.setAttribute('position', new T.BufferAttribute(dustPositions, 3).setUsage(T.DynamicDrawUsage));
  const dust = new T.Points(
    dustG,
    new T.PointsMaterial({
      color: '#c2bfb0',
      size: 0.027,
      opacity: 0.47,
      transparent: true,
      depthWrite: false,
    }),
  );
  dust.frustumCulled = false;
  dust.name = 'Localized falling plaster';
  k.group.add(dust);
  const dustSources = detail.towers
    .filter((_, i) => damage.grades[i] === 3)
    .map((t) => ({ x: t.x + t.w * 0.24, y: Math.min(10, t.h * 0.18), z: t.z + t.d * 0.5 + 0.54 }));
  let clock = 0;
  const stats = {
    ...damage,
    addedVehicles: VEHICLE_SITES.length,
    existingFleet: oldFleet.length,
    vegetationBatches: k.chunks.filter((c) => c.mesh instanceof T.InstancedMesh).length,
  };
  const applied = new Set<T.Material>();
  city.traverse((o) => {
    if (o instanceof T.Mesh)
      for (const m of Array.isArray(o.material) ? o.material : [o.material]) applied.add(m);
  });
  const roads = [...applied].filter(
    (m) =>
      m instanceof T.MeshStandardMaterial &&
      (m.map?.image as HTMLImageElement | undefined)?.src?.endsWith('fractured-asphalt.jpg'),
  ) as T.MeshStandardMaterial[];
  // The old pavement's normal scale identifies it even before image decoding finishes.
  if (!roads.length)
    for (const m of applied)
      if (m instanceof T.MeshStandardMaterial && m.normalScale.x === 0.26 && m.roughness === 0.89)
        roads.push(m);
  const wornNormal = loader.load('/materials/aftermath/worn_asphalt-normal.jpg');
  wornNormal.wrapS = wornNormal.wrapT = T.RepeatWrapping;
  let lastQuality = '';
  return {
    group: k.group,
    kit: k,
    stats,
    sound,
    sky,
    reflection,
    sites: VEHICLE_SITES,
    update(dt: number, eye: T.Vector3, yaw: number, q: QualityPreset, effects: boolean) {
      if (eye.y < -0.4) {
        sound.stop();
        dust.visible = false;
        return;
      }
      if (q !== lastQuality) {
        lastQuality = q;
        for (const road of roads) {
          road.normalMap = q === 'mobile' ? null : wornNormal;
          road.needsUpdate = true;
        }
      }
      clock += dt;
      k.update(dt, eye, yaw, q, effects);
      sound.update(dt, eye);
      const source =
        effects && !protectedPlaza(eye.x, eye.z)
          ? dustSources.find((s) => Math.hypot(eye.x - s.x, eye.z - s.z) < 31)
          : null;
      dust.visible = !!source;
      if (source) {
        const total = q === 'mobile' ? 9 : q === 'high' ? 28 : 18;
        dustG.setDrawRange(0, total);
        for (let i = 0; i < total; i++) {
          const life = (clock * 0.16 + seeds[i * 4]) % 1;
          dustPositions[i * 3] = source.x + seeds[i * 4 + 1] * 2.4 + life * 0.64;
          dustPositions[i * 3 + 1] = source.y - life * (source.y - 0.02);
          dustPositions[i * 3 + 2] = source.z + seeds[i * 4 + 2] * 0.31 + life * 0.59;
        }
        dustG.attributes.position.needsUpdate = true;
      }
    },
    setVisible(visible: boolean) {
      k.group.visible = visible;
      if (!visible) sound.stop();
    },
    stop() {
      sound.stop();
      dust.visible = false;
    },
    dispose() {
      sound.dispose();
      reflection.dispose();
      sky.dispose();
      wornNormal.dispose();
      dustG.dispose();
      (dust.material as T.Material).dispose();
      maps.forEach((t) => t.dispose());
      k.dispose();
    },
  };
}
