import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { FacilityKit as K, FLOOR } from './facilityKit';
import { bench, cabinet, kiosk, lightBar, monitor, planter, safety } from './furnishings';
import type { SolidBox, WalkableSurface } from './collision';
import type { Sector } from '../facility';

export interface Gate {
  x: number;
  z: number;
  width: number;
  progress: number;
  leaves: T.Group[];
  collider: SolidBox;
}
export interface Lift {
  x: number;
  z: number;
  height: number;
  target: number;
  platform: T.Group;
  surface: WalkableSurface;
}
const pi = Math.PI;

export function wall(
  k: K,
  x: number,
  z: number,
  w: number,
  d: number,
  h: number,
  mat = 'stone',
  col = '#a39f92',
) {
  k.box(x, h / 2, z, w, h, d, mat, col);
  k.solid(x, h / 2, z, w, h, d);
}
export function utilityRun(k: K, x: number, z: number, len: number, h: number, yaw = 0) {
  k.at(x, 0, z, yaw, () => {
    k.box(0, h, 0, 1.18, 0.5, len, 'steel', '#9c9d8d');
    k.rod([1.03, h - 0.12, -len / 2], [1.03, h - 0.12, len / 2], 0.12, 'steel', '#858c7d');
    k.rod([1.42, h - 0.1, -len / 2], [1.42, h - 0.1, len / 2], 0.064, 'paint', '#9b835d');
    for (let t = -len / 2 + 0.65; t < len / 2; t += 3.25) {
      k.box(0, h, t, 1.22, 0.55, 0.065, 'graphite', '#626b60');
      k.box(0.52, h - 0.37, t, 2.39, 0.06, 0.085, 'steel', '#7e8578');
      k.rod([-0.69, h - 0.35, t], [-0.69, h + 0.55, t], 0.018);
      k.rod([1.6, h - 0.35, t], [1.6, h + 0.55, t], 0.018);
    }
  });
}
export function railing(k: K, x: number, z: number, length: number, height: number, yaw = 0, glass = true) {
  k.at(x, height, z, yaw, () => {
    const n = Math.ceil(length / 1.9);
    k.rod([-length / 2, 1.08, 0], [length / 2, 1.08, 0], 0.042, 'steel', '#a5aa9b');
    k.box(0, 0.12, 0, length, 0.08, 0.11, 'graphite', '#555d52');
    for (let j = 0; j <= n; j++) {
      const xx = -length / 2 + (j * length) / n;
      k.box(xx, 0.55, 0, 0.055, 1.08, 0.065, 'steel', '#888e81');
      k.box(xx, 0.026, 0, 0.16, 0.052, 0.16, 'steel', '#757d70');
    }
    if (glass) k.box(0, 0.6, 0, length - 0.05, 0.84, 0.028, 'glass', '#c7dbd0');
    else k.rod([-length / 2, 0.52, 0], [length / 2, 0.52, 0], 0.028, 'paint', '#b49c65');
    k.solid(0, 0.55, 0, length, 1.1, 0.11);
  });
}

export function buildGate(
  k: K,
  gates: Gate[],
  x: number,
  z: number,
  yaw: number,
  width: number,
  title: string,
  id: string,
  color: string,
  h = 6.5,
) {
  k.at(x, 0, z, yaw, () => {
    const clear = 3.9;
    for (const s of [-1, 1]) {
      k.box(s * (width / 2 + 0.38), clear / 2, 0, 0.8, clear, 0.86, 'graphite', '#50574f', true);
      k.box(s * (width / 2 + 0.32), clear / 2, -0.52, 0.38, clear + 0.12, 0.22, 'steel', '#92988a', true);
      k.box(s * (width / 2 + 0.32), clear / 2, 0.52, 0.38, clear + 0.12, 0.22, 'steel', '#92988a', true);
      for (let j = 0; j < 4; j++)
        k.box(s * (width / 2 + 0.4), 0.5 + j * 0.92, 0.58, 0.55, 0.11, 0.1, 'graphite', '#333b33');
      k.box(s * (width / 2 + 0.74), 1.53, 0.49, 0.27, 0.47, 0.16, 'graphite', '#303b33', true);
      k.box(s * (width / 2 + 0.74), 1.57, 0.58, 0.19, 0.26, 0.015, 'light', '#9cc2a0');
      k.solid(s * (width / 2 + 0.38), clear / 2, 0, 0.8, clear, 0.9);
    }
    k.box(0, (h + clear) / 2, 0, width + 1.8, h - clear, 0.65, 'stone', '#a5a293');
    k.solid(0, (h + clear) / 2, 0, width + 1.8, h - clear, 0.65);
    k.box(0, clear + 0.12, 0, width + 1.8, 0.29, 1.24, 'graphite', '#495147');
    for (const f of [-1, 1]) {
      k.label(
        0,
        clear + 0.76,
        f * 0.36,
        width + 1.1,
        1.02,
        title,
        id + '  /  AUTOMATIC ACCESS',
        color,
        f < 0 ? pi : 0,
      );
      k.box(0, clear + 0.295, f * 0.55, width, 0.035, 0.06, 'light', '#c8d2b8');
    }
    k.box(0, 0.017, 0, width + 0.7, 0.027, 0.45, 'steel', '#8a9083');
    k.box(0, 0.036, 0, width + 0.6, 0.012, 0.055, 'graphite', '#3b443b');
  });
  const root = new T.Group();
  root.position.set(x, 0, z);
  root.rotation.y = yaw;
  k.group.add(root);
  const clinical = id === 'SEC 02',
    academic = id === 'SEC 03',
    industrial = ['SEC 07', 'SEC 08', 'SEC 09', 'SEC 10'].includes(id);
  const metal = new T.MeshStandardMaterial({
    color: clinical ? '#cad5ca' : academic ? '#a39b82' : industrial ? '#7b8476' : '#78837a',
    roughness: 0.43,
    metalness: 0.63,
  });
  const edge = new T.MeshStandardMaterial({ color: '#323e35', roughness: 0.61, metalness: 0.52 });
  const accent = new T.MeshStandardMaterial({ color, roughness: 0.53, metalness: 0.42 });
  const leaves: T.Group[] = [];
  for (const s of [-1, 1]) {
    const leaf = new T.Group();
    const piece = (w: number, h: number, d: number, xx: number, yy: number, zz: number, m: T.Material) => {
      const o = new T.Mesh(new T.BoxGeometry(w, h, d), m);
      o.position.set(xx, yy, zz);
      leaf.add(o);
    };
    piece(width / 2, 3.88, 0.23, 0, 1.94, 0, metal);
    for (const f of [-1, 1]) {
      piece(width * 0.37, 2.79, 0.05, 0, 1.99, f * 0.139, edge);
      piece(width * 0.31, 2.57, 0.06, 0, 2.0, f * 0.17, metal);
      piece(0.055, 1.18, 0.09, -s * width * 0.15, 1.47, f * 0.223, edge);
      for (const yy of [0.48, 3.4]) piece(width * 0.4, 0.065, 0.06, 0, yy, f * 0.15, edge);
    }
    for (const f of [-1, 1]) {
      piece(width * 0.42, 0.095, 0.036, 0, 0.89, f * 0.219, accent);
      if (clinical || academic) {
        piece(width * 0.29, 0.69, 0.043, 0, 2.6, f * 0.222, edge);
        piece(width * 0.265, 0.59, 0.032, 0, 2.6, f * 0.252, accent);
        piece(0.04, 0.6, 0.037, 0, 2.6, f * 0.267, metal);
      } else if (industrial) {
        for (let i = 0; i < 4; i++) {
          piece(width * 0.28, 0.103, 0.047, 0, 1.2 + i * 0.39, f * 0.224, edge);
          leaf.children[leaf.children.length - 1].rotation.z = s * 0.18;
        }
      } else
        for (let i = 0; i < 5; i++) piece(width * 0.21, 0.047, 0.039, 0, 2.5 + i * 0.13, f * 0.219, edge);
    }
    const parts: T.BufferGeometry[] = [];
    for (const o of leaf.children as T.Mesh[]) {
      o.updateMatrix();
      const g = o.geometry.applyMatrix4(o.matrix);
      const c = (o.material as T.MeshStandardMaterial).color;
      const colors = new Float32Array(g.attributes.position.count * 3);
      for (let i = 0; i < colors.length; i += 3) {
        colors[i] = c.r;
        colors[i + 1] = c.g;
        colors[i + 2] = c.b;
      }
      g.setAttribute('color', new T.BufferAttribute(colors, 3));
      parts.push(g);
    }
    const batch = new T.Mesh(
      mergeGeometries(parts)!,
      new T.MeshStandardMaterial({ vertexColors: true, roughness: 0.43, metalness: 0.58 }),
    );
    batch.castShadow = batch.receiveShadow = true;
    leaf.clear();
    leaf.add(batch);
    parts.forEach((p) => p.dispose());
    leaf.position.x = (s * width) / 4;
    root.add(leaf);
    leaves.push(leaf);
  }
  metal.dispose();
  edge.dispose();
  accent.dispose();
  let collider!: SolidBox;
  k.at(x, 0, z, yaw, () => {
    collider = k.solid(0, 1.95, 0, width, 3.9, 0.3);
  });
  collider.id = 'sector-gate-' + id;
  gates.push({ x, z, width, progress: 0, leaves, collider });
}

export function partition(
  k: K,
  gates: Gate[],
  x1: number,
  z1: number,
  x2: number,
  z2: number,
  door: number,
  width: number,
  title: string,
  id: string,
  color: string,
  h = 6.5,
) {
  const isX = Math.abs(x2 - x1) > Math.abs(z2 - z1);
  const start = isX ? x1 : z1,
    end = isX ? x2 : z2;
  for (const [a, b] of [
    [start, door - width / 2 - 0.7],
    [door + width / 2 + 0.7, end],
  ]) {
    if (b <= a) continue;
    const m = (a + b) / 2;
    wall(k, isX ? m : x1, isX ? z1 : m, isX ? b - a : 0.54, isX ? 0.54 : b - a, h);
    for (const f of [-1, 1]) {
      k.box(
        isX ? m : x1 + f * 0.29,
        0.34,
        isX ? z1 + f * 0.29 : m,
        isX ? b - a : 0.07,
        0.68,
        isX ? 0.07 : b - a,
        'graphite',
        '#5a6054',
      );
      k.box(
        isX ? m : x1 + f * 0.29,
        1.16,
        isX ? z1 + f * 0.29 : m,
        isX ? b - a : 0.031,
        0.11,
        isX ? 0.031 : b - a,
        'paint',
        color,
      );
    }
  }
  buildGate(k, gates, isX ? door : x1, isX ? z1 : door, isX ? 0 : pi / 2, width, title, id, color, h);
}

export function shell(k: K, s: Sector) {
  const [xmin, xmax, zmin, zmax] = s.bounds;
  const w = xmax - xmin,
    d = zmax - zmin,
    cx = (xmin + xmax) / 2,
    cz = (zmin + zmax) / 2;
  const h = s.id === 'concourse' ? 10.9 : s.id === 'habitat' ? 8.3 : s.id === 'storage' ? 7.3 : 6.5;
  const floorCol = (
    {
      concourse: '#898b7c',
      medical: '#c3cfc3',
      education: '#ddd9c8',
      habitat: '#878b7b',
      command: '#657575',
      cafeteria: '#aaa28b',
      power: '#899081',
      water: '#8baba1',
      workshop: '#8b8d7a',
      storage: '#969a86',
    } as Record<string, string>
  )[s.id];
  k.walk(cx, cz, w, d, 0);
  k.solid(cx, -0.31, cz, w, 0.6, d);
  const nx = Math.ceil(w / 4),
    nz = Math.ceil(d / 4);
  for (let i = 0; i < nx; i++)
    for (let j = 0; j < nz; j++)
      k.box(
        xmin + ((i + 0.5) * w) / nx,
        -0.121,
        zmin + ((j + 0.5) * d) / nz,
        w / nx,
        0.24,
        d / nz,
        'floor',
        floorCol,
      );
  if (s.id !== 'concourse') {
    k.box(cx, h + 0.14, cz, w + 0.2, 0.28, d + 0.2, 'stone', '#7b8073');
    k.solid(cx, h + 0.14, cz, w, 0.28, d);
  } else {
    for (const [a, b, c, e] of [
      [xmin, xmax, zmin, -10],
      [xmin, xmax, 29, zmax],
      [xmin, -9.6, -10, 29],
      [9.6, xmax, -10, 29],
    ]) {
      k.box((a + b) / 2, h + 0.14, (c + e) / 2, b - a, 0.28, e - c, 'stone', '#929282');
      k.solid((a + b) / 2, h + 0.14, (c + e) / 2, b - a, 0.28, e - c);
    }
  }
  if (s.id === 'concourse' || s.id === 'education') return;
  if (h > 6.5) {
    for (const x of [xmin, xmax]) k.box(x, (h + 6.5) / 2, cz, 0.55, h - 6.5, d, 'stone', '#a7ab9d');
    for (const z of [zmin, zmax]) k.box(cx, (h + 6.5) / 2, z, w, h - 6.5, 0.55, 'stone', '#9ca292');
  }
  for (let z = zmin + 4; z < zmax; z += 10) {
    k.box(cx, h - 0.22, z, w, 0.46, 0.31, 'graphite', '#656e60');
    k.box(cx, h - 0.45, z, w, 0.09, 0.66, 'graphite', '#777e6e');
  }
  for (let x = xmin + 5; x < xmax; x += 14) {
    utilityRun(k, x, zmin + d / 2, d - 1.2, h - 0.7);
    for (let z = zmin + 6; z < zmax; z += 12)
      lightBar(k, x + 3.2, h - 0.7, z, 6.7, 0, ['cafeteria', 'education', 'habitat'].includes(s.id));
  }
  for (let x = xmin + 3; x < xmax - 1; x += 12) {
    k.box(x, h - 0.14, zmin + 0.68, 2, 0.22, 0.82, 'vent', '#5f6b5d');
  }
  k.box(xmin + 2.2, 0.006, cz, 0.11, 0.009, d - 0.7, 'paint', s.color);
  k.box(xmin + 2.45, 0.006, cz, 0.045, 0.009, d - 0.7, 'paint', s.color);
  for (let z = zmin + 4; z < zmax - 1; z += 10) {
    k.box(xmax - 1.62, 0.009, z, 0.32, 0.012, 1.9, 'vent', '#5d685b');
  }
}

export function room(
  k: K,
  x: number,
  z: number,
  w: number,
  d: number,
  title: string,
  color: string,
  glass = false,
) {
  const h = 3.25;
  k.at(x, 0, z, 0, () => {
    wall(k, 0, -d / 2, w, 0.18, h, 'paint', glass ? '#c2c9bc' : '#c1bbab');
    wall(k, -w / 2, 0, 0.18, d, h, 'paint', '#b7beb0');
    if (glass) {
      k.box(w / 2, 0.44, 0, 0.14, 0.88, d, 'paint', '#b6c5b9');
      k.box(w / 2, 1.99, 0, 0.06, 2.21, d, 'glass', '#d1e2d7');
      k.solid(w / 2, h / 2, 0, 0.17, h, d);
      for (let j = -d / 2; j < d / 2; j += 3) k.box(w / 2, 1.95, j, 0.13, 2.27, 0.07, 'steel', '#818f80');
      k.box(w / 2, 3.12, 0, 0.14, 0.1, d, 'steel', '#8d998a');
    } else wall(k, w / 2, 0, 0.16, d, h, 'wood', '#b9ab91');
    const dw = Math.min(3.5, w * 0.45),
      part = (w - dw) / 2;
    for (const a of [-1, 1]) {
      k.box(a * (dw / 2 + part / 2), 0.43, d / 2, part, 0.86, 0.17, 'paint', '#a8b5a9');
      k.box(
        a * (dw / 2 + part / 2),
        2,
        d / 2,
        part,
        2.25,
        0.06,
        glass ? 'glass' : 'wood',
        glass ? '#d1e2d7' : '#9a8d73',
      );
      k.solid(a * (dw / 2 + part / 2), h / 2, d / 2, part, h, 0.17);
      k.box(a * (dw / 2 + 0.045), 1.61, d / 2, 0.1, 3.22, 0.22, 'graphite', '#535e51');
    }
    k.box(0, 3.2, d / 2, w + 0.12, 0.24, 0.24, 'graphite', '#5e685a');
    k.label(0, 3.27, d / 2 + 0.13, Math.min(w * 0.55, 5), 0.49, title, 'B-01  /  FACILITY SERVICES', color);
    k.box(0, 1.04, -d / 2 + 0.105, w - 0.22, 0.12, 0.04, 'paint', color);
    lightBar(k, -w * 0.25, 3.6, 0, d * 0.64, 0, !glass);
    lightBar(k, w * 0.25, 3.6, 0, d * 0.64, 0, !glass);
    for (const sx of [-w * 0.25, w * 0.25])
      for (const sz of [-d * 0.21, d * 0.21])
        k.rod([sx, 3.71, sz], [sx, 6.42, sz], 0.014, 'graphite', '#535d50');
  });
}

export function centralHall(k: K): Lift {
  // Seal the taller atrium above the neighboring single-level sectors.
  for (const x of [-24, 24]) {
    k.box(x, 8.7, 21, 0.58, 4.4, 90, 'stone', '#92948c');
    k.solid(x, 8.7, 21, 0.58, 4.4, 90);
  }
  for (const z of [-24, 66]) {
    k.box(0, 8.7, z, 48.4, 4.4, 0.59, 'stone', '#98998d');
    k.solid(0, 8.7, z, 48.4, 4.4, 0.59);
  }
  for (const s of [-1, 1])
    for (let z = 31; z < 65; z += 3.1) {
      k.box(s * 23.63, 6.8, z, 0.16, 3.18, 2.95, 'graphite', '#566058');
      k.box(s * 23.53, 6.8, z, 0.03, 2.98, 2.76, 'vent', '#777e70');
      k.box(s * 23.5, 5.09, z, 0.08, 0.057, 3.08, 'light', '#f2d5ab');
    }
  for (let x = -22.5; x < 23; x += 3.03) {
    k.box(x, 8.8, 65.65, 2.92, 3.19, 0.19, 'stone', '#9b9c91');
    k.box(x, 6.27, 65.59, 2.94, 1.49, 0.2, 'graphite', '#596059');
  }
  for (const x of [-22.4, -12.3, 12.3, 22.4])
    for (const z of [32, 50, 63]) {
      k.box(x, 5.3, z, 1.35, 10.6, 1.58, 'stone', '#aaa696');
      k.box(x, 0.42, z, 1.48, 0.84, 1.71, 'graphite', '#565c50');
      k.box(x, 0.98, z, 1.37, 0.28, 1.6, 'paint', '#c28448');
      k.solid(x, 5.3, z, 1.4, 10.6, 1.65);
      k.shadow(x, z, 4.5, 4.5);
      if (z === 50) k.stencil(x, 3.14, z - 0.805, 1.03, 2.65, '01', pi);
      for (const h of [2.24, 4.49, 6.74, 8.99]) k.box(x, h, z, 1.357, 0.017, 1.587, 'graphite', '#6c7067');
    }
  for (const z of [30, 40, 50, 60]) {
    k.box(0, 10.32, z, 48, 0.76, 0.46, 'graphite', '#606655');
    k.box(0, 9.91, z, 48, 0.12, 1.14, 'steel', '#8f9382');
  }
  for (const x of [-20, -14, 14, 20]) utilityRun(k, x, 20, 86, 9.75);
  for (const x of [-9.8, -5.8, 5.8, 9.8]) {
    lightBar(k, x, 10.11, 46, 32, 0, true);
    k.box(x, 10.56, 45, 1.9, 0.09, 28, 'light', '#e6e6d1');
    for (let t = 32; t < 59; t += 1.75) k.box(x, 10.48, t, 2, 0.14, 0.08, 'graphite', '#787e6d');
  }
  for (const x of [-1.5, 1.5]) {
    k.box(x, 0.011, 46, 0.09, 0.016, 36, 'paint', '#c49055');
    k.box(x * 1.12, 0.011, 46, 0.03, 0.016, 36, 'paint', '#d7c09b');
  }
  for (const z of [34, 45, 60]) {
    k.label(0, 0.023, z, 2.5, 0.8, '01  /  HUB', 'CENTRAL CONCOURSE', '#c99c65', 0, true);
    k.pool(0, z, 16, 20);
  }
  for (const s of [-1, 1]) {
    const xx = s * 19.2;
    k.box(xx, 4.21, 38.8, 7.9, 0.42, 46.4, 'stone', '#9b9d8b');
    k.walk(xx, 38.8, 7.9, 46.4, 4.42);
    k.solid(xx, 4.21, 38.8, 7.9, 0.42, 46.4);
    railing(k, s * 15.25, 31, 31, 4.42, pi / 2);
    railing(k, s * 15.25, 56.6, 10, 4.42, pi / 2);
    for (let z = 19; z < 57; z += 8) {
      lightBar(k, xx, 3.93, z, 5.6, 0, true);
      k.box(xx, 3.7, z, 7.9, 0.6, 0.22, 'graphite', '#70796a');
    }
    const sx = s * 10.7,
      steps = 24,
      sz = 47.5,
      run = 10.8;
    for (let i = 0; i < steps; i++) {
      const y = ((i + 1) / steps) * 4.42,
        zz = sz + (i * run) / steps;
      k.box(sx, y - 0.1, zz, 4.4, 0.2, run / steps + 0.015, 'stone', '#b6b4a0');
      k.box(sx, y + 0.003, zz - (run / steps) * 0.42, 4.39, 0.012, 0.057, 'graphite', '#646d5e');
    }
    k.collision.addSurface({
      minX: sx - 2.2,
      maxX: sx + 2.2,
      minZ: sz - 0.23,
      maxZ: sz + run - 0.225,
      yStart: FLOOR + 0.18,
      yEnd: FLOOR + 4.42,
      slopeAxis: 'z',
    });
    for (const ss of [-1, 1]) {
      const rx = sx + ss * 2.25;
      k.rod([rx, 1.06, sz - 0.23], [rx, 5.48, sz + run - 0.22], 0.045);
      k.rod([rx, 0.38, sz - 0.23], [rx, 4.8, sz + run - 0.22], 0.027);
      for (let i = 0; i <= 6; i++) {
        const t = i / 6;
        k.cyl(rx, t * 4.42 + 0.53, sz + t * run - 0.23, 0.032, 1.06);
      }
    }
    bench(k, s * 18, 36, pi / 2, 3.3);
    bench(k, s * 18, 42, pi / 2, 3.3);
    k.at(0, 4.42, 0, 0, () => {
      planter(k, s * 19.3, 54, 1.25);
      bench(k, s * 19.1, 28, (-s * pi) / 2, 4.1);
    });
  }
  k.box(0, 4.21, 61.95, 47.6, 0.42, 7.6, 'stone', '#9a9e8b');
  k.walk(0, 61.95, 47.6, 7.6, 4.42);
  k.solid(0, 4.21, 61.95, 47.6, 0.42, 7.6);
  railing(k, -6.8, 58.14, 1.8, 4.42);
  railing(k, 2.59, 58.14, 10.18, 4.42);
  k.label(0, 7.2, 65.46, 15.8, 2.0, 'CENTRAL CONCOURSE', 'LAST FOUR  /  SUBLEVEL 01', '#d7a572', pi);
  for (const s of [-1, 1]) {
    k.box(s * 17, 7.4, 65.53, 4.2, 5.3, 0.22, 'vent', '#727c6d');
    safety(k, s * 20.7, 65.3, pi);
  }
  k.at(-6.6, 0, 44.3, -0.12, () => {
    k.box(0, 0.14, 0, 5.3, 0.28, 1.43, 'graphite', '#414a40', true);
    k.box(0, 0.64, 0, 5.5, 0.88, 1.53, 'stone', '#b6b4a1', true);
    k.box(0, 1.13, 0, 5.61, 0.16, 1.63, 'wood', '#aa9169', true);
    k.box(0, 0.3, -0.771, 5.15, 0.033, 0.019, 'light', '#e9c79a');
    k.label(0, 0.75, -0.77, 2.94, 0.42, 'RECEPTION', 'ARRIVAL SERVICES', '#d7ae80', pi);
    monitor(k, -1.2, 1.21, 0);
    monitor(k, 1.1, 1.21, 0);
    k.solid(0, 0.6, 0, 5.6, 1.2, 1.63);
    k.shadow(0, 0, 6.7, 2.9);
  });
  kiosk(k, 5.1, 42.5, 'DIRECTORY', pi);
  planter(k, 9.4, 35, 1.25);
  planter(k, -13.8, 39, 1.18);
  cabinet(k, -21.6, 58.4, 1.5, 1.89, 0.6, '#798578', pi / 2);
  // The central access shaft remains geometrically and mechanically unchanged.
  for (const s of [-1, 1]) {
    for (const z of [-16, -2, 12, 23]) {
      lightBar(k, s * 16, 6.2, z, 7.4, 0);
      k.box(s * 16, 6.44, z, 12, 0.29, 1.1, 'graphite', '#687464');
      for (const a of [-1, 1]) k.rod([s * 16 + a * 4, 6.54, z], [s * 16 + a * 4, 10.6, z], 0.025);
    }
    k.box(s * 14, 0.012, 1, 0.14, 0.016, 43, 'paint', '#b39462');
    k.label(s * 16, 2.82, -23.64, 7.2, 1.1, 'EDUCATION', 'NORTH PASSAGE  /  SECTOR 03', '#cbb18c');
  }
  // The passenger car shares a moving walk surface with the controller.
  const x = -4.2,
    z = 56.51;
  const platform = new T.Group();
  platform.position.set(x, 0, z);
  k.group.add(platform);
  const body = new T.Mesh(new T.BoxGeometry(3.1, 0.17, 3.35), k.materials.graphite);
  body.position.y = -0.085;
  platform.add(body);
  for (const f of [-1, 1]) {
    k.box(x + f * 1.64, 3.41, z, 0.13, 6.82, 0.22, 'steel', '#989e8c');
    k.box(x + f * 1.71, 3.41, z + 1.5, 0.12, 6.82, 0.12, 'graphite', '#65705e');
    const side = new T.Mesh(new T.BoxGeometry(0.065, 1.15, 3.13), k.materials.glass);
    side.position.set(f * 1.49, 0.62, 0);
    platform.add(side);
  }
  k.label(x, 2.79, z - 1.65, 2.97, 0.44, 'GALLERY LIFT', 'G  /  LEVEL 01', '#c7b995', pi);
  k.box(x, 2.78, z - 1.61, 3.12, 0.56, 0.085, 'graphite', '#596352');
  railing(k, -15.17, 58.14, 3.72, 4.42);
  railing(k, 15.15, 58.14, 3.8, 4.42);
  for (const s of [-1, 1]) k.box(x + s * 1.61, 0.6, z, 0.09, 1.2, 3.18, 'steel', '#a6ac99');
  return { x, z, height: 0, target: 0, platform, surface: k.walk(x, z, 3.12, 3.37, 0) };
}
