import * as T from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { CollisionWorld, type SolidBox } from './collision';
import { SECTORS } from '../facility';

export const FLOOR = -12;
export type V3 = [number, number, number];
type Batch = {
  geometry: T.BufferGeometry;
  material: T.Material;
  transforms: T.Matrix4[];
  colors: T.Color[];
  fine: boolean;
  sector: string;
};

function texture(w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  draw(c.getContext('2d')!);
  const t = new T.CanvasTexture(c);
  t.colorSpace = T.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

function surface(kind: 'stone' | 'floor' | 'wood' | 'mesh' | 'alloy') {
  let seed = 19219;
  const rand = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  return texture(256, 256, (c) => {
    const image = c.createImageData(256, 256);
    for (let y = 0; y < 256; y++)
      for (let x = 0; x < 256; x++) {
        let k = 196 + rand() * 18;
        if (kind === 'stone') k += Math.sin(x / 28 + Math.sin(y / 35)) * 8 + Math.sin(y / 22) * 3;
        if (kind === 'wood')
          k =
            185 +
            Math.sin(y * 1.7 + Math.sin(x / 54) * 1.4) * 18 +
            Math.sin(y * 0.14 + Math.sin(x / 80)) * 23 +
            rand() * 12;
        if (kind === 'mesh') k = x % 8 < 3 && y % 8 < 3 ? 65 : 195 + rand() * 22;
        if (kind === 'alloy') k = 200 + Math.sin(y * 12.6) * 9 + rand() * 10;
        if (kind === 'floor') {
          k = 202 + rand() * 8;
          if (x < 2 || y < 2) k = 119;
          if (x === 2 || y === 2) k = 231;
        }
        const i = 4 * (y * 256 + x);
        image.data[i] = k;
        image.data[i + 1] = k;
        image.data[i + 2] = k;
        image.data[i + 3] = 255;
      }
    c.putImageData(image, 0, 0);
    if (kind === 'stone') {
      c.fillStyle = '#77777733';
      c.fillRect(0, 0, 2, 256);
      c.fillRect(0, 0, 256, 2);
      for (const x of [17, 239])
        for (const y of [18, 239]) {
          c.beginPath();
          c.arc(x, y, 2.4, 0, Math.PI * 2);
          c.fill();
        }
    }
  });
}

export class FacilityKit {
  group = new T.Group();
  sector = 'structure';
  private basis = new T.Matrix4();
  private batches = new Map<string, Batch>();
  readonly materials: Record<string, T.Material> = {};
  private cube = new T.BoxGeometry(1, 1, 1);
  private bevel = new RoundedBoxGeometry(1, 1, 1, 1, 0.075);
  private cylinder = new T.CylinderGeometry(1, 1, 1, 16);
  private ball = new T.SphereGeometry(1, 10, 7);
  private plane = new T.PlaneGeometry(1, 1);
  private temp = new T.Object3D();
  private atlas: {
    c: CanvasRenderingContext2D;
    texture: T.CanvasTexture;
    material: T.MeshBasicMaterial;
    count: number;
  }[] = [];
  private labels = new Map<string, { geo: T.PlaneGeometry; mat: T.Material }>();
  private printMeshes: { geo: T.BufferGeometry; mat: T.Material; matrix: T.Matrix4; sector: string }[] = [];
  private renderBatches: { mesh: T.Object3D; box: T.Box3; fine: boolean; sector: string }[] = [];
  private economyMaterials = new Map<T.Material, T.Material>();
  private seed = 4821;
  private occluders: SolidBox[] = [];
  private fixtures: { x: number; z: number; length: number }[] = [];
  random = () => (this.seed = (this.seed * 16807) % 2147483647) / 2147483647;

  constructor(readonly collision: CollisionWorld) {
    this.group.position.y = FLOOR;
    this.group.name = 'B01 / Underground settlement';
    const pbr = (roughness: number, metalness: number, map?: T.Texture) =>
      new T.MeshStandardMaterial({ color: 0xffffff, roughness, metalness, map: map || null });
    this.materials.paint = pbr(0.58, 0.17);
    this.materials.graphite = pbr(0.53, 0.57, surface('alloy'));
    this.materials.steel = pbr(0.29, 0.83, surface('alloy'));
    this.materials.stone = pbr(0.84, 0.025, surface('stone'));
    this.materials.floor = pbr(0.37, 0.22, surface('floor'));
    this.materials.wood = pbr(0.59, 0.03, surface('wood'));
    this.materials.fabric = pbr(0.94, 0.0, surface('mesh'));
    this.materials.vent = pbr(0.63, 0.55, surface('mesh'));
    this.materials.rubber = pbr(0.92, 0.02);
    this.materials.glass = new T.MeshStandardMaterial({
      color: 0xc1d8d2,
      metalness: 0.22,
      roughness: 0.12,
      transparent: true,
      opacity: 0.27,
      depthWrite: false,
    });
    this.materials.light = new T.MeshBasicMaterial({ color: 0xffffff });
    this.materials.glazing = pbr(
      0.17,
      0.32,
      texture(256, 128, (c) => {
        const gradient = c.createLinearGradient(0, 0, 0, 128);
        gradient.addColorStop(0, '#293536');
        gradient.addColorStop(0.39, '#8b9a95');
        gradient.addColorStop(0.46, '#647570');
        gradient.addColorStop(1, '#314440');
        c.fillStyle = gradient;
        c.fillRect(0, 0, 256, 128);
        c.fillStyle = '#c2c8b829';
        for (let i = -90; i < 290; i += 65) {
          c.beginPath();
          c.moveTo(i, 0);
          c.lineTo(i + 14, 0);
          c.lineTo(i + 97, 87);
          c.lineTo(i + 87, 87);
          c.fill();
        }
      }),
    );
    this.materials.directory = new T.MeshBasicMaterial({
      map: texture(512, 512, (c) => {
        c.fillStyle = '#232e2a';
        c.fillRect(0, 0, 512, 512);
        c.fillStyle = '#dba77a';
        c.font = '16px monospace';
        c.fillText('LAST FOUR   /   SUBLEVEL 01', 23, 34);
        c.fillStyle = '#e5e9d9';
        c.font = 'bold 40px Barlow Condensed, sans-serif';
        c.fillText('FACILITY DIRECTORY', 23, 86);
        for (const s of SECTORS) {
          const [a, b, d, e] = s.bounds;
          const x = 30 + (a + 104) * 1.16,
            y = 123 + (d + 104) * 1.16;
          c.fillStyle = s.color + '33';
          c.fillRect(x, y, (b - a) * 1.16 - 2, (e - d) * 1.16 - 2);
          c.strokeStyle = s.color;
          c.strokeRect(x, y, (b - a) * 1.16 - 2, (e - d) * 1.16 - 2);
          c.fillStyle = s.color;
          c.font = 'bold 14px monospace';
          c.fillText(s.number, x + 5, y + 18);
          const j = Number(s.number) - 1;
          c.font = '13px Barlow, sans-serif';
          c.fillText(s.number + '  ' + s.name.toUpperCase(), 288, 136 + j * 24, 208);
        }
        c.fillStyle = '#d3a16c';
        c.fillRect(28, 400, 454, 2);
        c.font = 'bold 20px Barlow Condensed, sans-serif';
        c.fillText('YOU ARE HERE   /   CENTRAL CONCOURSE', 28, 438);
        c.fillStyle = '#a1b09c';
        c.font = '12px monospace';
        c.fillText('ALL SECTORS CONNECTED   /   ACCESS LEVEL G', 28, 474);
      }),
    });
    const ao = texture(64, 64, (c) => {
      const g = c.createRadialGradient(32, 32, 3, 32, 32, 32);
      g.addColorStop(0, 'rgba(0,0,0,.48)');
      g.addColorStop(0.55, 'rgba(0,0,0,.29)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = g;
      c.fillRect(0, 0, 64, 64);
    });
    this.materials.ao = new T.MeshBasicMaterial({
      map: ao,
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -1,
    });
    const glow = texture(64, 64, (c) => {
      const g = c.createRadialGradient(32, 32, 0, 32, 32, 32);
      g.addColorStop(0, 'rgba(255,234,201,.17)');
      g.addColorStop(0.6, 'rgba(255,234,201,.05)');
      g.addColorStop(1, 'rgba(255,234,201,0)');
      c.fillStyle = g;
      c.fillRect(0, 0, 64, 64);
    });
    this.materials.pool = new T.MeshBasicMaterial({
      map: glow,
      transparent: true,
      blending: T.AdditiveBlending,
      depthWrite: false,
    });
    const loader = new T.TextureLoader();
    for (const [name, file, scale] of [
      ['stone', 'concrete', 0.26],
      ['floor', 'floor', 0.26],
      ['wood', 'timber', 0.52],
    ] as const) {
      const m = this.materials[name] as T.MeshStandardMaterial;
      const load = (suffix: string, srgb = false) => {
        const t = loader.load(`/materials/${file}-${suffix}.jpg`);
        t.colorSpace = srgb ? T.SRGBColorSpace : T.NoColorSpace;
        t.wrapS = t.wrapT = T.RepeatWrapping;
        t.anisotropy = 4;
        return t;
      };
      m.map?.dispose();
      m.map = load('color', true);
      m.normalMap = load('normal');
      m.normalScale.setScalar(name === 'wood' ? 0.23 : 0.54);
      m.roughnessMap = load('rough');
      m.roughness = name === 'floor' ? 0.86 : 0.95;
      // Meter-scaled UVs keep surface scans consistent across different-sized modules.
      m.onBeforeCompile = (shader) => {
        shader.vertexShader = shader.vertexShader.replace(
          '#include <uv_vertex>',
          `#include <uv_vertex>
        #ifdef USE_INSTANCING
        vec3 assetPos=(instanceMatrix*vec4(position,1.0)).xyz;
        vec3 axis=abs(normalize(mat3(instanceMatrix)*normal));
        vec2 tiled=(axis.y>axis.x && axis.y>axis.z?assetPos.xz:(axis.x>axis.z?assetPos.zy:assetPos.xy))*${scale.toFixed(2)};
        vMapUv=tiled;
        #ifdef USE_NORMALMAP
        vNormalMapUv=tiled;
        #endif
        #ifdef USE_ROUGHNESSMAP
        vRoughnessMapUv=tiled;
        #endif
        #endif`,
        );
      };
      m.customProgramCacheKey = () => `facility-scan-${name}`;
      m.userData.detailMaps = [m.normalMap, m.roughnessMap];
    }
    for (let i = 0; i < 5; i++) {
      const map = texture(512, 256, (c) => {
        c.fillStyle = ['#152c32', '#203131', '#172436', '#2d2b20', '#263133'][i];
        c.fillRect(0, 0, 512, 256);
        c.fillStyle = '#a2c7b9';
        c.font = 'bold 16px monospace';
        c.fillText(
          [
            'FACILITY / NETWORK',
            'PATIENT / TELEMETRY',
            'OPERATIONS / LIVE',
            'ENERGY / OUTPUT',
            'LEARNING / MODULE 03',
          ][i],
          16,
          26,
        );
        c.strokeStyle = '#47616b';
        c.lineWidth = 1;
        for (let x = 16; x < 312; x += 16) {
          c.beginPath();
          c.moveTo(x, 50);
          c.lineTo(x, 215);
          c.stroke();
        }
        for (let y = 52; y < 215; y += 16) {
          c.beginPath();
          c.moveTo(16, y);
          c.lineTo(315, y);
          c.stroke();
        }
        c.strokeStyle = '#95c8b8';
        c.lineWidth = 2;
        c.beginPath();
        for (let x = 0; x < 298; x++) {
          const y =
            i === 1
              ? Math.sin(x * 0.09) * 3 - (x % 64 < 6 ? Math.sin(((x % 64) / 6) * Math.PI) * 45 : 0)
              : Math.sin(x * 0.034 + i) * 16 + Math.sin(x * 0.134) * 8;
          c.lineTo(17 + x, 127 + y);
        }
        c.stroke();
        c.fillStyle = '#b8d3cf';
        c.font = '34px monospace';
        c.fillText(['98.6', '72', '04:12', '240', 'L / 03'][i], 343, 92);
        for (let j = 0; j < 6; j++) {
          c.fillStyle = '#4d7175';
          c.fillRect(345, 119 + j * 14, 138, 4);
          c.fillStyle = '#99c3ac';
          c.fillRect(345, 119 + j * 14, 40 + ((j * 31 + i * 13) % 97), 4);
        }
        c.font = '10px monospace';
        c.fillStyle = '#96bab8';
        c.fillText('LF  /  CONTROL SYSTEMS        B-01        LOCAL TELEMETRY', 16, 240);
      });
      this.materials['screen' + i] = new T.MeshBasicMaterial({ map });
    }
  }
  at(x: number, y: number, z: number, angle: number, fn: () => void) {
    const old = this.basis.clone();
    this.temp.position.set(x, y, z);
    this.temp.rotation.set(0, angle, 0);
    this.temp.scale.set(1, 1, 1);
    this.temp.updateMatrix();
    this.basis.multiply(this.temp.matrix);
    fn();
    this.basis.copy(old);
  }
  emit(
    geo: T.BufferGeometry,
    mat: string,
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    color: T.ColorRepresentation = 0xffffff,
    rot: V3 = [0, 0, 0],
  ) {
    this.temp.position.set(x, y, z);
    this.temp.rotation.set(...rot);
    this.temp.scale.set(w, h, d);
    this.temp.updateMatrix();
    const m = this.basis.clone().multiply(this.temp.matrix);
    const fine = Math.max(w, h, d) < 0.7;
    const a = m.elements;
    const sector =
      this.sector === 'auto'
        ? SECTORS.find(
            (s) =>
              a[12] >= s.bounds[0] && a[12] <= s.bounds[1] && a[14] >= s.bounds[2] && a[14] <= s.bounds[3],
          )?.id || 'structure'
        : this.sector;
    if (mat === 'light' && a[13] > 2.6 && Math.max(w, d) > 2)
      this.fixtures.push({ x: a[12], z: a[14], length: Math.max(w, d) });
    const key = `${Math.floor(a[12] / 40)},${Math.floor(a[14] / 40)}:${mat}:${geo.id}:${fine}:${sector}`;
    let batch = this.batches.get(key);
    if (!batch) {
      batch = { geometry: geo, material: this.materials[mat], transforms: [], colors: [], fine, sector };
      this.batches.set(key, batch);
    }
    batch.transforms.push(m);
    batch.colors.push(new T.Color(color));
  }
  box(
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    mat = 'paint',
    color: T.ColorRepresentation = '#737776',
    round = false,
    rot: V3 = [0, 0, 0],
  ) {
    this.emit(round ? this.bevel : this.cube, mat, x, y, z, w, h, d, color, rot);
  }
  cyl(
    x: number,
    y: number,
    z: number,
    r: number,
    h: number,
    mat = 'steel',
    color: T.ColorRepresentation = '#b4b9b4',
    rot: V3 = [0, 0, 0],
  ) {
    this.emit(this.cylinder, mat, x, y, z, r, h, r, color, rot);
  }
  oval(
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    mat: string,
    color: T.ColorRepresentation,
    rot: V3 = [0, 0, 0],
  ) {
    this.emit(this.ball, mat, x, y, z, w, h, d, color, rot);
  }
  rod(a: V3, b: V3, r: number, mat = 'steel', color: T.ColorRepresentation = '#a1a7a3') {
    const av = new T.Vector3(...a),
      bv = new T.Vector3(...b),
      v = bv.clone().sub(av);
    const q = new T.Quaternion().setFromUnitVectors(new T.Vector3(0, 1, 0), v.clone().normalize());
    const e = new T.Euler().setFromQuaternion(q);
    this.cyl((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2, r, v.length(), mat, color, [
      e.x,
      e.y,
      e.z,
    ]);
  }
  solid(x: number, y: number, z: number, w: number, h: number, d: number) {
    const bb = new T.Box3(
      new T.Vector3(x - w / 2, y - h / 2, z - d / 2),
      new T.Vector3(x + w / 2, y + h / 2, z + d / 2),
    ).applyMatrix4(this.basis);
    const s = this.collision.addSolid({
      minX: bb.min.x,
      maxX: bb.max.x,
      minY: bb.min.y + FLOOR,
      maxY: bb.max.y + FLOOR,
      minZ: bb.min.z,
      maxZ: bb.max.z,
    });
    this.occluders.push(s);
    return s;
  }
  walk(x: number, z: number, w: number, d: number, y: number) {
    return this.collision.addSurface({
      minX: x - w / 2,
      maxX: x + w / 2,
      minZ: z - d / 2,
      maxZ: z + d / 2,
      yStart: y + FLOOR,
      yEnd: y + FLOOR,
    });
  }
  shadow(x: number, z: number, w: number, d: number, y = 0.018) {
    this.emit(this.plane, 'ao', x, y, z, w, d, 1, 0xffffff, [-Math.PI / 2, 0, 0]);
  }
  pool(x: number, z: number, w: number, d: number) {
    this.emit(this.plane, 'pool', x, 0.012, z, w, d, 1, 0xffffff, [-Math.PI / 2, 0, 0]);
  }
  label(
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    text: string,
    sub = '',
    accent = '#dc9255',
    yaw = 0,
    floor = false,
  ) {
    const key = text + sub + accent;
    let entry = this.labels.get(key);
    if (!entry) {
      let a = this.atlas[this.atlas.length - 1];
      if (!a || a.count >= 64) {
        const canvas = document.createElement('canvas');
        canvas.width = 2048;
        canvas.height = 2048;
        const t = new T.CanvasTexture(canvas);
        t.colorSpace = T.SRGBColorSpace;
        t.anisotropy = 4;
        a = {
          c: canvas.getContext('2d')!,
          texture: t,
          material: new T.MeshBasicMaterial({ map: t }),
          count: 0,
        };
        this.atlas.push(a);
      }
      const col = a.count % 4,
        row = Math.floor(a.count / 4),
        ox = col * 512,
        oy = row * 128;
      a.count++;
      const c = a.c;
      c.save();
      c.translate(ox, oy);
      c.fillStyle = '#272c2a';
      c.fillRect(0, 0, 512, 128);
      c.fillStyle = accent;
      c.fillRect(0, 0, 6, 128);
      c.font = '600 38px Barlow Condensed, sans-serif';
      c.fillStyle = '#e9ece2';
      c.fillText(text.toUpperCase(), 22, sub ? 68 : 81, 470);
      c.fillStyle = accent;
      c.font = '16px monospace';
      c.fillText(sub.toUpperCase(), 23, 103, 467);
      c.restore();
      a.texture.needsUpdate = true;
      const geo = new T.PlaneGeometry(1, 1);
      const uv = geo.attributes.uv;
      for (let i = 0; i < uv.count; i++)
        uv.setXY(i, (col + uv.getX(i) * 0.998 + 0.001) / 4, 1 - (row + 1 - uv.getY(i) * 0.997 - 0.0015) / 16);
      entry = { geo, mat: a.material };
      this.labels.set(key, entry);
    }
    this.temp.position.set(x, y, z);
    this.temp.rotation.set(floor ? -Math.PI / 2 : 0, yaw, 0);
    this.temp.scale.set(w, h, 1);
    this.temp.updateMatrix();
    this.printMeshes.push({
      geo: entry.geo,
      mat: entry.mat,
      matrix: this.basis.clone().multiply(this.temp.matrix),
      sector: this.sector,
    });
  }
  stencil(x: number, y: number, z: number, w: number, h: number, text: string, yaw = 0, color = '#e3dfcf') {
    const id = 'stencil' + text + color;
    if (!this.materials[id]) {
      const map = texture(256, 256, (c) => {
        c.fillStyle = color;
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        c.font = '700 216px Barlow Condensed, sans-serif';
        c.fillText(text, 128, 122, 245);
      });
      this.materials[id] = new T.MeshBasicMaterial({ map, transparent: true, depthWrite: false });
    }
    this.emit(this.plane, id, x, y, z, w, h, 1, 0xffffff, [0, yaw, 0]);
  }
  finish() {
    // Bake fixture pools and static contact shadows once. The mobile path needs
    // no per-frame shadow pass, including in the furnished clinical rooms.
    const irradiance = texture(1024, 1024, (c) => {
      const u = (v: number) => ((v + 106) / 212) * 1024,
        scale = 1024 / 212;
      c.fillStyle = '#b0b3ab';
      c.fillRect(0, 0, 1024, 1024);
      for (const l of this.fixtures) {
        const rad = (3 + Math.min(9, l.length) * 0.55) * scale;
        const x = u(l.x),
          z = u(l.z);
        const g = c.createRadialGradient(x, z, 0, x, z, rad);
        g.addColorStop(0, 'rgba(255,244,222,.8)');
        g.addColorStop(1, 'rgba(255,246,228,0)');
        c.fillStyle = g;
        c.fillRect(x - rad, z - rad, 2 * rad, 2 * rad);
      }
      for (const s of this.occluders) {
        if (s.minY > FLOOR + 5 || s.maxY < FLOOR + 0.4) continue;
        const width = (s.maxX - s.minX) * scale,
          depth = (s.maxZ - s.minZ) * scale;
        const elevated = s.minY > FLOOR + 2.7;
        c.shadowBlur = elevated ? 12 : 4.5;
        c.shadowOffsetX = elevated ? 4 : 1.7;
        c.shadowOffsetY = elevated ? 5 : 2.2;
        c.shadowColor = elevated ? 'rgba(24,29,26,.46)' : 'rgba(21,26,23,.62)';
        c.fillStyle = elevated ? 'rgba(42,46,42,.25)' : 'rgba(48,53,47,.29)';
        c.fillRect(u(s.minX), u(s.minZ), width, depth);
      }
      c.shadowBlur = 0;
    });
    const floor = this.materials.floor as T.MeshStandardMaterial;
    const oldCompile = floor.onBeforeCompile;
    floor.userData.irradiance = irradiance;
    floor.onBeforeCompile = (shader, renderer) => {
      oldCompile.call(floor, shader, renderer);
      shader.uniforms.facilityIrradiance = { value: irradiance };
      shader.vertexShader =
        'varying vec2 vFacilityUV;\n' +
        shader.vertexShader.replace(
          '#include <begin_vertex>',
          '#include <begin_vertex>\nvec3 architecturalPosition=(instanceMatrix*vec4(position,1.0)).xyz;vFacilityUV=vec2((architecturalPosition.x+106.0)/212.0,1.0-(architecturalPosition.z+106.0)/212.0);',
        );
      shader.fragmentShader =
        'varying vec2 vFacilityUV;uniform sampler2D facilityIrradiance;\n' +
        shader.fragmentShader.replace(
          '#include <opaque_fragment>',
          'outgoingLight*=0.28+texture2D(facilityIrradiance,vFacilityUV).rgb*1.22;\n#include <opaque_fragment>',
        );
    };
    this.occluders = [];
    this.fixtures = [];
    for (const b of this.batches.values()) {
      const mesh = new T.InstancedMesh(b.geometry, b.material, b.transforms.length);
      b.transforms.forEach((m, i) => {
        mesh.setMatrixAt(i, m);
        mesh.setColorAt(i, b.colors[i]);
      });
      mesh.computeBoundingBox();
      mesh.computeBoundingSphere();
      mesh.receiveShadow = true;
      mesh.castShadow =
        !b.fine && !(b.material as T.MeshBasicMaterial).isMeshBasicMaterial && !b.material.transparent;
      this.group.add(mesh);
      this.renderBatches.push({ mesh, box: mesh.boundingBox!, fine: b.fine, sector: b.sector });
    }
    // Printed graphics share atlas pages and spatial batches rather than a texture per sign.
    const signs = new Map<string, { pos: number[]; uv: number[]; mat: T.Material }>();
    for (const p of this.printMeshes) {
      const e = p.matrix.elements;
      const k = `${Math.floor(e[12] / 40)},${Math.floor(e[14] / 40)},${p.mat.id}`;
      let b = signs.get(k);
      if (!b) {
        b = { pos: [], uv: [], mat: p.mat };
        signs.set(k, b);
      }
      const g = p.geo;
      for (const i of [0, 2, 1, 2, 3, 1]) {
        const v = new T.Vector3().fromBufferAttribute(g.attributes.position, i).applyMatrix4(p.matrix);
        b.pos.push(v.x, v.y, v.z);
        b.uv.push(g.attributes.uv.getX(i), g.attributes.uv.getY(i));
      }
    }
    for (const b of signs.values()) {
      const g = new T.BufferGeometry();
      g.setAttribute('position', new T.Float32BufferAttribute(b.pos, 3));
      g.setAttribute('uv', new T.Float32BufferAttribute(b.uv, 2));
      g.computeBoundingSphere();
      const m = new T.Mesh(g, b.mat);
      this.group.add(m);
    }
    this.batches.clear();
    this.printMeshes = [];
  }
  cull(x: number, z: number, mobile: boolean, visible: Set<string>) {
    for (const { mesh, box, fine, sector } of this.renderBatches) {
      if (sector !== 'structure' && !visible.has(sector)) {
        mesh.visible = false;
        continue;
      }
      const dx = Math.max(box.min.x - x, 0, x - box.max.x),
        dz = Math.max(box.min.z - z, 0, z - box.max.z);
      const range = fine ? (mobile ? 24 : 37) : 220;
      mesh.visible = dx * dx + dz * dz < range * range;
    }
  }
  detail(mobile: boolean) {
    this.group.traverse((o) => {
      if (!(o instanceof T.Mesh) || Array.isArray(o.material)) return;
      const original = (o.userData.fullMaterial || o.material) as T.Material;
      if (!(original instanceof T.MeshStandardMaterial)) return;
      o.userData.fullMaterial = original;
      if (!mobile) {
        o.material = original;
        return;
      }
      let cheap = this.economyMaterials.get(original);
      if (!cheap) {
        cheap = new T.MeshLambertMaterial({
          color: original.color,
          map: original.map,
          vertexColors: original.vertexColors,
          transparent: original.transparent,
          opacity: original.opacity,
          depthWrite: original.depthWrite,
          side: original.side,
        });
        cheap.onBeforeCompile = original.onBeforeCompile;
        cheap.customProgramCacheKey = original.customProgramCacheKey;
        this.economyMaterials.set(original, cheap);
      }
      o.material = cheap;
    });
  }
  dispose() {
    this.economyMaterials.forEach((m) => m.dispose());
    this.economyMaterials.clear();
    Object.values(this.materials).forEach((m) => {
      if (m.userData.irradiance) m.userData.irradiance.dispose();
      for (const t of m.userData.detailMaps || []) t.dispose();
      Object.values(m).forEach((v) => {
        if (v instanceof T.Texture) v.dispose();
      });
      m.dispose();
    });
  }
}
