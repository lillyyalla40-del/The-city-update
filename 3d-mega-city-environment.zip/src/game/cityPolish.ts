import * as T from 'three';
import type { TexturePack } from './textures';
import type { CollisionWorld } from './collision';
import type { QualityPreset } from './types';

type Batch = {
  geo: T.BufferGeometry;
  mat: T.Material;
  matrices: T.Matrix4[];
  colors: T.Color[];
  range: number;
};
type Anchor = { x: number; y: number; z: number; heading?: number };
export interface TowerRecord {
  x: number;
  z: number;
  w: number;
  d: number;
  h: number;
  style: number;
}

function drawing(w: number, h: number, paint: (c: CanvasRenderingContext2D) => void) {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  paint(canvas.getContext('2d')!);
  const t = new T.CanvasTexture(canvas);
  t.colorSpace = T.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}
function parameters(m: T.Mesh<T.BufferGeometry>) {
  return (m.geometry as T.BoxGeometry).parameters;
}
function eachInstance(
  m: T.InstancedMesh,
  fn: (p: T.Vector3, s: T.Vector3, q: T.Quaternion, i: number) => void,
) {
  const a = new T.Matrix4(),
    p = new T.Vector3(),
    s = new T.Vector3(),
    q = new T.Quaternion();
  for (let i = 0; i < m.count; i++) {
    m.getMatrixAt(i, a);
    a.decompose(p, q, s);
    fn(p, s, q, i);
  }
}

/** All decorative transforms are derived from the built city, never a second block layout. */
export function polishCity(city: T.Group, pack: TexturePack, collision: CollisionWorld) {
  const group = new T.Group();
  group.name = 'Meridian / architectural finish pass';
  const boxGeo = new T.BoxGeometry(1, 1, 1),
    cylGeo = new T.CylinderGeometry(1, 1, 1, 12),
    plane = new T.PlaneGeometry(1, 1);
  const obj = new T.Object3D(),
    frame = new T.Matrix4(),
    origin = new T.Matrix4(),
    batches = new Map<string, Batch>();
  const paint = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.65, metalness: 0.17 });
  const metal = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.37, metalness: 0.65 });
  const stone = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.78, metalness: 0.04 });
  const glass = new T.MeshStandardMaterial({ color: '#7a9aab', roughness: 0.14, metalness: 0.59 });
  const lit = new T.MeshBasicMaterial({ color: 0xffffff });
  const data: TowerRecord[] = [],
    lamps: Anchor[] = [],
    headlamps: Anchor[] = [],
    signs = new Map<string, T.Material>();
  const loader = new T.TextureLoader();
  const tex = (url: string, color = true) => {
    const t = loader.load(url);
    t.wrapS = t.wrapT = T.RepeatWrapping;
    t.colorSpace = color ? T.SRGBColorSpace : T.NoColorSpace;
    t.anisotropy = 4;
    return t;
  };
  const facadeUrls = ['curtain', 'bronze', 'stone', 'hotel'];
  const facadeMaps = facadeUrls.map((n) => tex('/materials/facade-' + n + '.jpg'));
  const pavement = tex('/materials/avenue-color.jpg'),
    paveNormal = tex('/materials/avenue-normal.jpg', false),
    paveRough = tex('/materials/avenue-rough.jpg', false);
  const soffit = tex('/materials/concrete-color.jpg');
  stone.map = soffit;
  const skyMap = loader.load('/materials/avenue-sky.jpg');
  skyMap.colorSpace = T.SRGBColorSpace;
  skyMap.mapping = T.EquirectangularReflectionMapping;
  const skyDomeMap = loader.load('/materials/avenue-sky.jpg');
  skyDomeMap.colorSpace = T.SRGBColorSpace;
  const originalMaterials = new Set<T.MeshStandardMaterial>();
  const roads: T.Mesh[] = [];
  const put = (
    geo: T.BufferGeometry,
    mat: T.Material,
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    col: T.ColorRepresentation,
    range = 130,
    rx = 0,
    ry = 0,
    rz = 0,
  ) => {
    obj.position.set(x, y, z);
    obj.rotation.set(rx, ry, rz);
    obj.scale.set(w, h, d);
    obj.updateMatrix();
    const m = origin.clone().multiply(obj.matrix),
      v = m.elements;
    const key = [geo.id, mat.id, Math.floor(v[12] / 72), Math.floor(v[14] / 72), range].join('/');
    let b = batches.get(key);
    if (!b) {
      b = { geo, mat, matrices: [], colors: [], range };
      batches.set(key, b);
    }
    b.matrices.push(m);
    b.colors.push(new T.Color(col));
  };
  const box = (
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    col: T.ColorRepresentation,
    mat: T.Material = paint,
    range = 125,
  ) => put(boxGeo, mat, x, y, z, w, h, d, col, range);
  const cylinder = (
    x: number,
    y: number,
    z: number,
    r: number,
    h: number,
    col: T.ColorRepresentation,
    rx = 0,
    rz = 0,
  ) => put(cylGeo, metal, x, y, z, r, h, r, col, 95, rx, 0, rz);
  const local = (x: number, z: number, yaw: number, work: () => void) => {
    const prev = origin.clone();
    frame.makeRotationY(yaw);
    frame.setPosition(x, 0, z);
    origin.multiply(frame);
    work();
    origin.copy(prev);
  };
  const sign = (
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    title: string,
    sub: string,
    bg: string,
    angle = 0,
  ) => {
    const id = title + sub;
    let m = signs.get(id);
    if (!m) {
      const map = drawing(512, 128, (c) => {
        c.fillStyle = bg;
        c.fillRect(0, 0, 512, 128);
        c.fillStyle = '#eae8d8';
        c.textAlign = 'center';
        c.font = '600 40px Barlow Condensed,sans-serif';
        c.fillText(title.toUpperCase(), 256, sub ? 65 : 81, 475);
        if (sub) {
          c.fillStyle = '#c5c9b9';
          c.font = '15px monospace';
          c.fillText(sub, 256, 99, 455);
        }
      });
      m = new T.MeshStandardMaterial({ map, roughness: 0.61, metalness: 0.13 });
      signs.set(id, m);
    }
    put(plane, m, x, y, z, w, h, 1, 0xffffff, 100, 0, angle);
  };
  const shadows = new T.MeshBasicMaterial({
    map: drawing(128, 128, (c) => {
      const g = c.createRadialGradient(64, 64, 18, 64, 64, 63);
      g.addColorStop(0, 'rgba(9,12,12,.63)');
      g.addColorStop(0.6, 'rgba(9,12,12,.39)');
      g.addColorStop(1, 'rgba(9,12,12,0)');
      c.fillStyle = g;
      c.fillRect(0, 0, 128, 128);
    }),
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -2,
  });
  const softShadow = (x: number, y: number, z: number, w: number, d: number) =>
    put(plane, shadows, x, y, z, w, d, 1, 0xffffff, 95, -Math.PI / 2);
  const mats = [pack.glassSkyscraperA, pack.glassSkyscraperB, pack.concreteTower, pack.hotelFacade];
  const originalMeshes: T.Mesh[] = [];
  city.traverse((o) => {
    if (o instanceof T.Mesh) originalMeshes.push(o);
  });
  let podium: T.InstancedMesh | undefined;
  for (const mesh of originalMeshes) {
    const mat = mesh.material as T.MeshStandardMaterial,
      params = parameters(mesh);
    if (mat.isMeshStandardMaterial) originalMaterials.add(mat);
    if (mat.map === pack.concreteTower && params?.width > 200 && params?.height < 2) {
      mesh.material = stone;
      mesh.castShadow = mesh.receiveShadow = true;
    }
    if (mat.map === pack.mallFacade) {
      mat.map = facadeMaps[0];
      mat.roughness = 0.39;
      mat.metalness = 0.34;
      mat.needsUpdate = true;
    }
    const style = mats.indexOf(mat.map as T.CanvasTexture);
    if (mesh instanceof T.InstancedMesh && params?.width === 1 && params?.height === 1 && style >= 0) {
      eachInstance(mesh, (p, s, _, i) => {
        if (p.y - s.y / 2 < 0.1) {
          const colors = ['#d3d8cd', '#a7b9c0', '#dac3a2', '#c7cbd0'];
          mesh.setColorAt(i, new T.Color(colors[i % 4]));
          box(p.x, s.y + 0.6, p.z, s.x * 0.75, 1.2, s.z * 0.78, '#9b9d91', metal, 400);
          if (i % 3 === 0) box(p.x, s.y + 3.3, p.z, s.x * 0.47, 5.4, s.z * 0.45, '#879691', stone, 400);
          return;
        }
        if (i % 2 !== 0) return;
        const ph = p.y - s.y / 2;
        data.push({ x: p.x, z: p.z, w: s.x / 0.84, d: s.z / 0.84, h: s.y / 0.62, style });
        const width = s.x,
          depth = s.z,
          crown = s.y / 0.62,
          trim = ['#94a6a8', '#b5a183', '#c0c2b3', '#b6ac94'][style];
        for (const face of [-1, 1]) {
          if (style === 0 || style === 1) {
            for (let n = 1; n < 6; n++) {
              const xx = p.x - width / 2 + (n * width) / 6;
              box(
                xx,
                p.y,
                p.z + face * (depth / 2 + 0.06),
                style === 1 ? 0.22 : 0.1,
                s.y,
                0.17,
                trim,
                metal,
                220,
              );
            }
            for (let n = 1; n < 5; n++)
              box(
                p.x + face * (width / 2 + 0.06),
                p.y,
                p.z - depth / 2 + (n * depth) / 5,
                0.17,
                s.y,
                0.12,
                trim,
                metal,
                220,
              );
          } else
            for (let yy = ph + 3.3; yy < ph + s.y - 0.5; yy += style === 3 ? 4.45 : 6.6) {
              box(
                p.x,
                yy,
                p.z + (face * depth) / 2,
                width + 0.17,
                0.22,
                style === 3 ? 1.05 : 0.46,
                trim,
                stone,
                185,
              );
              if (style === 3) {
                box(
                  p.x,
                  yy + 0.61,
                  p.z + face * (depth / 2 + 0.43),
                  width - 0.11,
                  0.07,
                  0.052,
                  '#8e9490',
                  metal,
                );
                for (let n = -2; n <= 2; n++)
                  box(
                    p.x + (n * width) / 5,
                    yy + 0.34,
                    p.z + face * (depth / 2 + 0.43),
                    0.045,
                    0.51,
                    0.045,
                    '#84908a',
                    metal,
                  );
              }
            }
        }
        if (style === 0 && i % 4 === 0) {
          for (let t = 0; t < 6; t++)
            box(
              p.x + (t - 2.5) * width * 0.116,
              crown + 2.7,
              p.z,
              width * 0.034,
              5.55,
              depth * 0.72,
              '#b3bbaf',
              metal,
              250,
            );
        }
        if (style === 1) {
          for (let q = 0; q < 3; q++)
            box(
              p.x,
              crown + 1.3 + q * 1.22,
              p.z,
              width * (0.69 - q * 0.105),
              1.25,
              depth * (0.69 - q * 0.105),
              '#a59c84',
              stone,
              280,
            );
        }
        for (const dx of [-0.24, 0.19]) {
          box(p.x + width * dx, crown + 1.94, p.z + depth * 0.15, 2.7, 1.48, 2.3, '#8b9793', metal, 200);
          for (let j = 0; j < 7; j++)
            box(
              p.x + width * dx - 1.08 + j * 0.36,
              crown + 2.699,
              p.z + depth * 0.15,
              0.13,
              0.04,
              1.85,
              '#4f625c',
              paint,
              165,
            );
          cylinder(p.x + width * dx, crown + 3.29, p.z - depth * 0.22, 0.32, 2.6, '#a0a9a0');
        }
        if (i % 4 === 0) {
          box(
            p.x + width * 0.14,
            ph + s.y * 0.53,
            p.z + depth * 0.5 + 0.68,
            3.19,
            0.18,
            0.92,
            '#929d96',
            metal,
            150,
          );
          for (const a of [-1, 1])
            box(
              p.x + width * 0.14 + a * 1.35,
              ph + s.y * 0.765,
              p.z + depth * 0.5 + 0.59,
              0.026,
              s.y * 0.47,
              0.026,
              '#565e58',
              metal,
              115,
            );
        }
      });
      mesh.castShadow = true;
      mesh.receiveShadow = true;
    }
    if (
      mesh instanceof T.InstancedMesh &&
      mat.transparent &&
      mat.isMeshStandardMaterial &&
      params?.width === 1
    )
      podium = mesh;
    if (mat.map === pack.asphaltRoad) {
      roads.push(mesh);
      mesh.receiveShadow = true;
      const positions = mesh.geometry.attributes.position,
        uv = mesh.geometry.attributes.uv;
      for (let i = 0; i < uv.count; i++) uv.setXY(i, positions.getX(i) * 0.22, positions.getZ(i) * 0.22);
      uv.needsUpdate = true;
    }
    if (
      mesh instanceof T.InstancedMesh &&
      params?.width === 0.28 &&
      params?.height === 0.03 &&
      mat instanceof T.MeshBasicMaterial
    ) {
      mat.color.set(mesh.material.color.getHex() === 0xeab308 ? '#b8a46c' : '#c1c1b7');
      const coords = [-128, -68, 0, 68, 128];
      eachInstance(mesh, (p, _, q, i) => {
        if (coords.some((a) => Math.abs(a - p.x) < 9.8) && coords.some((a) => Math.abs(a - p.z) < 9.8)) {
          obj.position.copy(p);
          obj.quaternion.copy(q);
          obj.scale.setScalar(0.00001);
          obj.updateMatrix();
          mesh.setMatrixAt(i, obj.matrix);
        }
      });
      mesh.instanceMatrix.needsUpdate = true;
    }
    if (mat.map === pack.sidewalkConcrete && params?.height === 0.3) {
      const { x, z } = mesh.position,
        w = params.width,
        d = params.depth;
      for (const a of [-1, 1]) {
        box(x + (a * w) / 2, 0.105, z, 0.29, 0.21, d + 0.1, '#aaa99c', stone);
        box(x, 0.105, z + (a * d) / 2, w + 0.12, 0.21, 0.29, '#aaa99c', stone);
        for (let ss = -w / 2 + 1.5; ss < w / 2; ss += 2.4)
          box(x + ss, 0.214, z + (a * d) / 2, 0.024, 0.012, 0.28, '#666d64');
      }
    }
    if (mat.map === pack.concreteTower && params?.width > 200 && params?.height < 2) {
      mat.roughness = 0.8;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
    }
    if (mesh instanceof T.InstancedMesh && params?.width === 1.4 && params?.height === 0.25) {
      eachInstance(mesh, (p) => lamps.push({ x: p.x, y: p.y, z: p.z }));
    }
    if (
      mesh instanceof T.InstancedMesh &&
      Math.abs((params?.width || 0) - 2) < 0.01 &&
      params?.height === 0.85
    ) {
      eachInstance(mesh, (p, _, q, i) => {
        const yaw = new T.Euler().setFromQuaternion(q).y;
        local(p.x, p.z, yaw, () => {
          for (const side of [-1, 1]) {
            for (const zz of [-1.26, 1.26]) {
              cylinder(side * 0.983, 0.391, zz, 0.38, 0.19, '#262d2e', 0, Math.PI / 2);
              cylinder(side * 1.088, 0.391, zz, 0.217, 0.031, '#a4aca7', 0, Math.PI / 2);
            }
            box(side * 0.89, 1.37, 0, 0.045, 0.38, 1.68, '#7c929a', glass);
            box(side * 0.92, 1.36, -0.11, 0.042, 0.4, 0.06, '#51646d', metal);
            box(side * 0.977, 0.93, 0.39, 0.04, 0.035, 0.22, '#b5bbb2', metal);
            box(
              side * 0.7,
              0.78,
              2.16,
              0.39,
              0.17,
              0.073,
              i % 5 === 0 ? '#ffe3a7' : '#bcc8bf',
              i % 5 === 0 ? lit : metal,
            );
            box(side * 0.72, 0.83, -2.156, 0.36, 0.15, 0.06, '#a45c49');
          }
          box(0, 0.57, 2.17, 0.86, 0.23, 0.035, '#3c4947');
          box(0, 0.39, 2.17, 1.93, 0.13, 0.13, '#8e9a95', metal);
          softShadow(0, 0.017, 0, 3.25, 6.4);
          put(boxGeo, glass, 0, 1.34, 1.27, 1.64, 0.7, 0.055, '#a4b4b7', 90, -0.42);
          if (i % 5 === 0) {
            const v = new T.Vector3(0, 0.8, 2.18).applyMatrix4(origin);
            headlamps.push({ x: v.x, y: v.y, z: v.z, heading: yaw });
          }
        });
      });
    }
    if (mesh instanceof T.InstancedMesh && params?.width === 2.7 && params?.height === 2.8) {
      eachInstance(mesh, (p, _, q) =>
        local(p.x, p.z, new T.Euler().setFromQuaternion(q).y, () => {
          for (const s of [-1, 1]) {
            for (let j = 0; j < 6; j++)
              box(s * 1.365, 2.09, -3.45 + j * 1.32, 0.045, 1.01, 1.17, '#627d80', glass);
            for (const z of [-3, 3]) cylinder(s * 1.3, 0.54, z, 0.52, 0.21, '#29332d', 0, Math.PI / 2);
          }
          box(0, 2.09, 4.716, 2.37, 1.15, 0.035, '#789397', glass);
          box(0, 3.12, 0, 1.49, 0.32, 2.93, '#9ea89b', metal);
        }),
      );
    }
  }
  for (const mat of originalMaterials) {
    const style = mats.indexOf(mat.map as T.CanvasTexture);
    if (style >= 0) {
      mat.map = facadeMaps[style];
      mat.color.setHex(0xffffff);
      mat.roughness = [0.24, 0.33, 0.72, 0.54][style];
      mat.metalness = [0.46, 0.46, 0.12, 0.22][style];
      mat.envMapIntensity = 0.72;
      mat.emissiveIntensity = 0.12;
      mat.onBeforeCompile = (shader) => {
        shader.vertexShader = shader.vertexShader.replace(
          '#include <uv_vertex>',
          `#include <uv_vertex>\n#ifdef USE_INSTANCING\nvec3 facadeSize=vec3(length(instanceMatrix[0].xyz),length(instanceMatrix[1].xyz),length(instanceMatrix[2].xyz));\nvec2 physicalSize=abs(normal.x)>.5?facadeSize.zy:facadeSize.xy;\nvMapUv=uv*max(vec2(1.0),floor(physicalSize/vec2(16.0,20.0)+0.5));\n#endif`,
        );
      };
      mat.customProgramCacheKey = () => `meridian-facade-${style}`;
      mat.needsUpdate = true;
    }
    if (mat.map === pack.asphaltRoad) {
      mat.map = pavement;
      mat.normalMap = paveNormal;
      mat.normalScale.setScalar(0.26);
      mat.roughnessMap = paveRough;
      mat.roughness = 0.82;
      mat.metalness = 0.11;
      mat.color.set('#656c70');
      mat.needsUpdate = true;
    }
  }
  const shopNames = [
    'Northline Works',
    'Meridian Exchange',
    'Atlas House',
    'Common Ground',
    'Orion Studio',
    'Westbridge Bank',
    'Civic Press',
    'Arcade Books',
  ];
  if (podium)
    eachInstance(podium, (p, s, _, i) => {
      const w = s.x - 0.15,
        d = s.z - 0.15,
        col = ['#b9b7a9', '#a7997f', '#c2c2b0', '#8d9992'][i % 4];
      for (const [a, span, depth] of [
        [0, w, d],
        [Math.PI, w, d],
        [Math.PI / 2, d, w],
        [-Math.PI / 2, d, w],
      ])
        local(p.x, p.z, a, () => {
          const front = depth / 2 + 0.13;
          box(0, 0.36, front, span + 0.11, 0.72, 0.26, col, stone);
          box(0, 4.11, front, span + 0.31, 0.33, 0.58, col, stone);
          const n = Math.max(2, Math.round(span / 4.3));
          for (let j = 0; j < n; j++) {
            const x = -span / 2 + ((j + 0.5) * span) / n;
            box(x, 2.28, front, span / n - 0.31, 2.75, 0.044, '#748991', glass);
            box(x, 3.37, front + 0.029, span / n - 0.27, 0.061, 0.053, '#bac0b4', metal);
            box(x - (span / n) * 0.47, 2.19, front + 0.03, 0.22, 3.92, 0.31, col, stone);
            box(x, 2.13, front + 0.045, 0.051, 2.63, 0.074, '#8b978f', metal);
          }
          if (a === 0 || a === Math.PI) {
            box(0, 3.87, front + 0.42, Math.min(w * 0.57, 9), 0.16, 1.28, '#6e7974', metal);
            box(0, 3.775, front + 0.84, w * 0.43, 0.016, 0.086, '#f5e2b8', lit);
            box(0, 2.03, front + 0.073, 2.87, 3.72, 0.08, '#3b5257', metal);
            for (const c of [-1, 1]) {
              box(c * 0.68, 1.86, front + 0.137, 1.26, 3.25, 0.035, '#849b9b', glass);
              box(c * 0.14, 1.43, front + 0.19, 0.032, 0.59, 0.045, '#cdcebc', metal);
            }
            sign(
              0,
              4.96,
              front + 0.039,
              Math.min(8.3, span * 0.61),
              1.15,
              shopNames[(i + (a === 0 ? 0 : 2)) % shopNames.length],
              'MERIDIAN  /  COMMERCIAL',
              '#343c3b',
            );
          }
        });
      softShadow(p.x, 0.17, p.z, w * 1.59, d * 1.59);
    });
  const coverMap = drawing(256, 256, (c) => {
    c.fillStyle = '#57605c';
    c.fillRect(0, 0, 256, 256);
    c.strokeStyle = '#8f958a';
    c.lineWidth = 4;
    for (const r of [118, 107, 38]) {
      c.beginPath();
      c.arc(128, 128, r, 0, Math.PI * 2);
      c.stroke();
    }
    c.strokeStyle = '#303b39';
    c.lineWidth = 6;
    for (let i = 0; i < 24; i++) {
      const a = (i * Math.PI) / 12;
      c.beginPath();
      c.moveTo(128 + Math.cos(a) * 47, 128 + Math.sin(a) * 47);
      c.lineTo(128 + Math.cos(a) * 99, 128 + Math.sin(a) * 99);
      c.stroke();
    }
    c.font = '18px sans-serif';
    c.fillStyle = '#bdc2b3';
    c.textAlign = 'center';
    c.fillText('MC', 128, 135);
  });
  const covers = new T.MeshStandardMaterial({ map: coverMap, roughness: 0.55, metalness: 0.61 });
  const disc = new T.CircleGeometry(1, 24);
  const grid = [-128, -68, 0, 68, 128];
  for (const x of grid)
    for (const z of grid) {
      if (x === 0 && z === 0) continue;
      for (const side of [-1, 1]) {
        for (let lane = -7.9; lane < 8.2; lane += 1.37) {
          box(x + lane, 0.053, z + side * 11, 0.58, 0.013, 3.45, '#b9bdac', paint, 130);
          box(x + side * 11, 0.053, z + lane, 3.45, 0.013, 0.58, '#b9bdac', paint, 130);
        }
        box(x + side * 4.15, 0.051, z + side * 14.1, 7.83, 0.013, 0.19, '#d0d0bc');
      }
      put(disc, covers, x + 3.38, 0.028, z + 5.7, 0.59, 0.59, 1, 0xffffff, 62, -Math.PI / 2);
      for (const side of [-1, 1]) {
        box(x + side * 9.6, 0.031, z + 14, 0.45, 0.025, 1.16, '#4d5954', metal);
        for (let j = 0; j < 9; j++)
          box(x + side * 9.6, 0.049, z + 13.53 + 0.112 * j, 0.38, 0.016, 0.034, '#9b9d8f', metal, 64);
      }
      if (Math.abs(x) === 68 && Math.abs(z) === 68) {
        const ax = x - 9,
          az = z - 9;
        cylinder(ax, 5.6, az, 0.13, 0.33, '#637a71');
        box(ax + 3.8, 5.51, az, 7.6, 0.16, 0.2, '#64726b', metal);
        for (const off of [1.54, 6.73]) {
          box(ax + off, 5.08, az, 0.49, 1.19, 0.39, '#5d645a');
          for (let j = 0; j < 3; j++)
            put(
              cylGeo,
              lit,
              ax + off,
              5.42 - j * 0.36,
              az + 0.211,
              0.129,
              0.049,
              0.129,
              j === 0 ? '#d27b59' : '#455047',
              95,
              Math.PI / 2,
            );
        }
        sign(ax + 4.3, 5.86, az + 0.12, 3.9, 0.59, x < 0 ? 'FINANCIAL AVE' : 'MERIDIAN BLVD', '', '#344e46');
      }
    }
  // The viaduct remains the original deck; these are bearing bands and edge details.
  for (const side of [-1, 1]) {
    box(0, 5.63, -128 + side * 6.52, 271.9, 0.32, 0.14, '#8b9695', metal, 250);
    for (let x = -132; x < 136; x += 5.8)
      box(x, 6.8, -128 + side * 6.36, 0.1, 0.8, 0.12, '#87938a', metal, 185);
  }
  for (let x = -135; x < 134; x += 9)
    for (const z of [-130.6, -125.4]) box(x, 6.487, z, 3.95, 0.012, 0.13, '#c5c7b1', paint, 190);
  for (const l of lamps) {
    box(l.x, l.y + 0.16, l.z, 1.79, 0.12, 0.57, '#55635e', metal);
    box(l.x, l.y - 0.144, l.z, 1.19, 0.033, 0.3, '#ffedbd', lit);
  }
  for (const x of [-110, -102, -94, -86])
    for (const z of [31.5, 45]) {
      box(x, 0.189, z, 0.11, 0.015, 6.7, '#c5c4a8');
      box(x + 1.4, 0.27, z - 3, 2.31, 0.19, 0.3, '#949a8a', stone);
    }
  for (const s of [-1, 1])
    for (const a of [-1, 1]) {
      const x = s * 29.2,
        z = a * 5.7;
      box(x, 0.37, z, 3.67, 0.14, 0.77, '#9d8668', paint);
      for (const f of [-1, 1]) box(x + f * 1.31, 0.218, z, 0.16, 0.44, 0.68, '#6b7770', metal);
      box(x, 0.72, z + a * 0.33, 3.68, 0.42, 0.095, '#a38b6d');
      collision.addCenteredBox(x, 0.5, z, 3.69, 0.85, 0.8);
      softShadow(x, 0.167, z, 4.99, 1.56);
    }
  const drawChunks: { mesh: T.InstancedMesh; bounds: T.Box3; range: number }[] = [];
  box(-77, 1.06, -77, 0.63, 0.94, 0.41, '#63716b', metal);
  box(-77, 1.15, -76.78, 0.41, 0.58, 0.038, '#384641');
  put(boxGeo, metal, -77.34, 1.12, -76.61, 0.38, 0.79, 0.045, '#819088', 60, 0, -0.8);
  collision.addCenteredBox(-77, 1.06, -77, 0.67, 0.97, 0.45);
  // Complete the original Galleria clerestory and bridge abutments without changing their openings.
  for (const side of [-1, 1]) {
    for (let i = 0; i < 8; i++) {
      box(-98 + side * 19.18, 8.1, 80.5 + i * 5, 0.24, 12.0, 0.19, '#a5b0ad', metal, 150);
      box(-115.5 + i * 5, 11.7, 98 + side * 19.18, 0.19, 4.7, 0.25, '#a5b0ad', metal, 150);
    }
    box(-98, 14.68, 98 + side * 19.2, 38.7, 0.32, 0.52, '#b4b8a8', stone, 200);
    box(-98 + side * 19.2, 14.68, 98, 0.52, 0.32, 38.7, '#acae9f', stone, 200);
  }
  for (const x of [-108, -88]) {
    box(x, 4.6, 116.7, 8.9, 0.27, 3.4, '#9f9e8a', metal);
    for (const dx of [-3.8, 3.8]) {
      cylinder(x + dx, 2.24, 117.9, 0.15, 4.48, '#8f9388');
      collision.addCenteredBox(x + dx, 2.24, 117.9, 0.31, 4.48, 0.31);
    }
  }
  for (const b of batches.values()) {
    const m = new T.InstancedMesh(b.geo, b.mat, b.matrices.length);
    b.matrices.forEach((mx, i) => {
      m.setMatrixAt(i, mx);
      m.setColorAt(i, b.colors[i]);
    });
    m.computeBoundingSphere();
    m.computeBoundingBox();
    m.receiveShadow = true;
    m.castShadow =
      b.range >= 125 && !b.mat.transparent && !(b.mat as T.MeshBasicMaterial).isMeshBasicMaterial;
    group.add(m);
    drawChunks.push({ mesh: m, bounds: m.boundingBox!, range: b.range });
  }
  city.add(group);
  batches.clear();
  let lx = Infinity,
    lz = Infinity,
    lastQ = '';
  return {
    group,
    towers: data,
    lamps,
    headlamps,
    skyMap,
    skyDomeMap,
    update(x: number, z: number, quality: QualityPreset) {
      if (Math.hypot(lx - x, lz - z) < 5 && quality === lastQ) return;
      lx = x;
      lz = z;
      lastQ = quality;
      const factor = quality === 'mobile' ? 0.6 : quality === 'balanced' ? 0.87 : 1;
      for (const { mesh, bounds, range } of drawChunks) {
        const dx = Math.max(bounds.min.x - x, 0, x - bounds.max.x),
          dz = Math.max(bounds.min.z - z, 0, z - bounds.max.z);
        mesh.visible = dx * dx + dz * dz < (range * factor) ** 2;
      }
    },
    setDetail(q: QualityPreset) {
      for (const m of roads) {
        const mat = m.material as T.MeshStandardMaterial;
        mat.normalMap = q === 'mobile' ? null : paveNormal;
        mat.roughnessMap = q === 'mobile' ? null : paveRough;
        mat.needsUpdate = true;
      }
    },
    dispose() {
      skyDomeMap.dispose();
      skyMap.dispose();
      paveNormal.dispose();
      paveRough.dispose();
    },
  };
}
