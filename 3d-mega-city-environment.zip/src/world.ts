import { SECTORS, sectorImage, sectorPoint } from './facility';
import type { FastTravelPoint } from './game/types';

export interface Destination {
  id: string;
  name: string;
  title: [string, string];
  classification: string;
  code: string;
  description: string;
  image: string;
  point: FastTravelPoint;
  features: string[];
  sectorIndex: number;
}

const city: Destination = {
  id: 'meridian',
  name: 'Meridian City',
  title: ['Meridian', 'City'],
  classification: 'Metropolitan core',
  code: 'S-01',
  description:
    'Six months after the outbreak, the skyline still stands. Explore a silent city slowly reclaimed by nature.',
  image: '/media/meridian-aftermath.jpg',
  point: { id: 'meridian', label: 'Meridian City', group: 'Surface City', x: -68, y: 0, z: 12, yaw: 0.06 },
  features: ['Commercial boulevards', 'Elevated expressway', 'Central Meridian Plaza', 'Surface hatch'],
  sectorIndex: -1,
};
const bunkerLocation = (index: number): Destination => {
  const s = SECTORS[index];
  return {
    id: s.id,
    name: s.name,
    title: [s.name.split(' ').slice(0, -1).join(' '), s.name.split(' ').at(-1)!],
    classification: 'Bunker sector',
    code: `B-${s.number}`,
    description: s.description,
    image: sectorImage(s),
    point: sectorPoint(s),
    features: s.rooms,
    sectorIndex: index,
  };
};
export const DESTINATIONS: Destination[] = [
  city,
  {
    ...city,
    id: 'financial',
    name: 'Financial District',
    title: ['Financial', 'District'],
    classification: 'Financial sector',
    code: 'S-02',
    description:
      'Dark office towers overlook stalled traffic. Follow Financial Avenue past the last evacuation checkpoint.',
    image: '/media/apex-aftermath.jpg',
    point: {
      id: 'financial',
      label: 'Apex Financial District',
      group: 'Surface City',
      x: -68,
      y: 0,
      z: -67,
      yaw: 0.59,
    },
    features: ['Apex towers', 'Commercial arcades', 'Financial Avenue', 'Transit viaduct'],
  },
  {
    ...city,
    id: 'park',
    name: 'Northgate Commons',
    title: ['Northgate', 'Commons'],
    classification: 'Civic gardens',
    code: 'S-03',
    description:
      'The fountain has fallen silent. Grass threads through the plaza, and young trees take root beside abandoned cars.',
    image: '/media/northgate-aftermath.jpg',
    point: { id: 'park', label: 'Northgate Commons', group: 'Surface City', x: 98, y: 0.15, z: -87, yaw: 0 },
    features: ['Dry civic fountain', 'Reclaimed curbs', 'Abandoned parking bays'],
  },
  {
    ...city,
    id: 'mall',
    name: 'Metro Galleria',
    title: ['Metro', 'Galleria'],
    classification: 'Retail district',
    code: 'S-04',
    description:
      'A delivery that never arrived. Walk beneath fractured canopies and past the shuttered shops of the western arcade.',
    image: '/media/galleria-aftermath.jpg',
    point: { id: 'mall', label: 'Metro Galleria', group: 'Surface City', x: -84, y: 0.15, z: 72, yaw: 2.6 },
    features: ['Stranded delivery truck', 'Vacant shopping concourse', 'Damaged transit shelter'],
  },
  {
    ...bunkerLocation(0),
    name: 'Central Concourse',
    title: ['Central', 'Concourse'],
    classification: 'Underground hub',
  },
  {
    ...bunkerLocation(2),
    name: 'Meridian Academy',
    title: ['Meridian', 'Academy'],
    classification: 'Education sector',
    image: '/media/meridian-academy.jpg',
  },
  ...[1, 3, 4, 5, 6, 7, 8, 9].map(bunkerLocation),
];
export const destinationById = (id: string) => DESTINATIONS.find((d) => d.id === id) || city;
