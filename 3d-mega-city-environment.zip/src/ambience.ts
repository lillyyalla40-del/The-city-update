export type SoundCue =
  | 'door-open'
  | 'door-close'
  | 'hatch-open'
  | 'hatch-close'
  | 'lift'
  | 'arrival'
  | 'terminal'
  | 'switch'
  | 'machine-on'
  | 'machine-off'
  | 'spark'
  | 'metal'
  | 'concrete'
  | 'tile'
  | 'asphalt'
  | 'wood'
  | 'beep'
  | 'water'
  | 'creak'
  | 'rattle'
  | 'impact';
type Profile = { hz: number; air: number; flow: number; hum: number; sparkle: number; spacing: number };
const voices: Record<string, Profile> = {
  surface: { hz: 37, air: 510, flow: 0.29, hum: 0.032, sparkle: 720, spacing: 13 },
  concourse: { hz: 53, air: 340, flow: 0.19, hum: 0.073, sparkle: 410, spacing: 17 },
  medical: { hz: 61, air: 680, flow: 0.105, hum: 0.042, sparkle: 960, spacing: 8.6 },
  education: { hz: 49.8, air: 390, flow: 0.095, hum: 0.029, sparkle: 660, spacing: 23 },
  habitat: { hz: 46, air: 290, flow: 0.19, hum: 0.068, sparkle: 510, spacing: 22 },
  command: { hz: 83, air: 1030, flow: 0.17, hum: 0.059, sparkle: 1260, spacing: 11 },
  cafeteria: { hz: 68, air: 810, flow: 0.16, hum: 0.051, sparkle: 550, spacing: 19 },
  power: { hz: 38, air: 240, flow: 0.24, hum: 0.16, sparkle: 330, spacing: 10 },
  water: { hz: 57, air: 1680, flow: 0.25, hum: 0.083, sparkle: 720, spacing: 3.5 },
  workshop: { hz: 63, air: 710, flow: 0.15, hum: 0.085, sparkle: 590, spacing: 14 },
  storage: { hz: 44, air: 210, flow: 0.16, hum: 0.058, sparkle: 460, spacing: 21 },
};
type XYZ = { x: number; y: number; z: number };
const anchors: Record<string, [number, number, number]> = {
  concourse: [-4.2, -8, 56.51],
  medical: [-64, -10.5, 50],
  education: [-38, -7.9, -55],
  habitat: [45, -10.8, 32],
  command: [18.9, -10.8, 84],
  cafeteria: [-86, -8.8, 78.4],
  power: [85, -9.7, -81],
  water: [39.03, -9.3, -98],
  workshop: [54, -10.9, -48],
  storage: [32.5, -10.6, 94],
};
class EnvironmentalAudio {
  context: AudioContext | null = null;
  enabled = false;
  volume = 0.65;
  zone = 'surface';
  paused = false;
  private output: GainNode | null = null;
  private bus: GainNode | null = null;
  private wet: GainNode | null = null;
  private humidity: GainNode | null = null;
  private wind: BiquadFilterNode | null = null;
  private hum: OscillatorNode | null = null;
  private harmonic: OscillatorNode | null = null;
  private humGain: GainNode | null = null;
  private source: PannerNode | null = null;
  private noise: AudioBuffer | null = null;
  private timer = 2;
  private listenerTimer = 0;
  private profileTimer = 0;
  private stride = 0;
  private last: XYZ | null = null;
  private count = 0;
  private mutedTimer = 0;
  private machinery = false;
  readonly statistics = { cues: 0, steps: 0, lastCue: '' };
  private nodes() {
    const C =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!C) return;
    const c = (this.context = new C());
    this.output = c.createGain();
    this.output.gain.value = 0;
    const limit = c.createDynamicsCompressor();
    limit.threshold.value = -17;
    limit.ratio.value = 5;
    this.output.connect(limit);
    limit.connect(c.destination);
    this.bus = c.createGain();
    this.bus.gain.value = 1;
    this.bus.connect(this.output);
    this.noise = c.createBuffer(1, Math.floor(c.sampleRate * 7.13), c.sampleRate);
    const data = this.noise.getChannelData(0);
    let smooth = 0;
    for (let i = 0; i < data.length; i++) {
      smooth = 0.95 * smooth + 0.05 * (Math.random() * 2 - 1);
      data[i] = smooth * 2.1 + (Math.random() * 2 - 1) * 0.21;
    }
    this.wind = c.createBiquadFilter();
    this.wind.type = 'lowpass';
    this.wind.Q.value = 0.37;
    this.humidity = c.createGain();
    this.humidity.gain.value = 0.16;
    for (let i = 0; i < 2; i++) {
      const player = c.createBufferSource();
      player.buffer = this.noise;
      player.loop = true;
      player.playbackRate.value = i ? 0.83 : 1.07;
      const pan = c.createStereoPanner();
      pan.pan.value = i ? -0.55 : 0.57;
      player.connect(pan);
      pan.connect(this.wind);
      player.start(0, i * 2.37);
    }
    this.wind.connect(this.humidity);
    this.humidity.connect(this.bus);
    this.source = this.panner(4, 0, -12, 4.8);
    this.hum = c.createOscillator();
    this.hum.type = 'sine';
    this.harmonic = c.createOscillator();
    this.harmonic.type = 'triangle';
    const h2 = c.createGain();
    h2.gain.value = 0.12;
    this.humGain = c.createGain();
    this.humGain.gain.value = 0.04;
    this.hum.connect(this.humGain);
    this.harmonic.connect(h2);
    h2.connect(this.humGain);
    this.humGain.connect(this.source);
    this.hum.start();
    this.harmonic.start();
    const impulse = c.createBuffer(2, Math.floor(c.sampleRate * 0.62), c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const a = impulse.getChannelData(ch);
      for (let i = 0; i < a.length; i++)
        a[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / a.length, 3.1) * 0.35;
    }
    const reverb = c.createConvolver();
    reverb.buffer = impulse;
    this.wet = c.createGain();
    this.wet.gain.value = 0.04;
    this.bus.connect(reverb);
    reverb.connect(this.wet);
    this.wet.connect(this.output);
    this.applyProfile();
  }
  private panner(x: number, y: number, z: number, reference = 2) {
    const c = this.context!,
      p = c.createPanner();
    p.panningModel = 'equalpower';
    p.distanceModel = 'inverse';
    p.refDistance = reference;
    p.rolloffFactor = 0.88;
    p.maxDistance = 90;
    this.moveSource(p, x, y, z);
    p.connect(this.bus!);
    return p;
  }
  private moveSource(p: PannerNode, x: number, y: number, z: number) {
    if (p.positionX) {
      p.positionX.value = x;
      p.positionY.value = y;
      p.positionZ.value = z;
    } else p.setPosition(x, y, z);
  }
  private gain() {
    if (!this.context || !this.output) return;
    const c = this.context;
    this.output.gain.setTargetAtTime(
      this.enabled && !document.hidden ? this.volume * (this.paused ? 0.13 : 0.64) : 0,
      c.currentTime,
      0.09,
    );
  }
  enable(on: boolean) {
    window.clearTimeout(this.mutedTimer);
    this.enabled = on;
    if (!on && !this.context) return;
    try {
      if (!this.context) this.nodes();
      if (!this.context) return;
      if (on) void this.context.resume().catch(() => {});
      this.gain();
      if (!on)
        this.mutedTimer = window.setTimeout(() => {
          if (!this.enabled) void this.context?.suspend().catch(() => {});
        }, 650);
    } catch {
      this.enabled = false;
    }
  }
  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v));
    this.gain();
  }
  setPaused(v: boolean) {
    this.paused = v;
    this.gain();
  }
  setZone(zone: string) {
    const id = voices[zone]
      ? zone
      : zone === 'bunker_shaft' || zone === 'bunker_corridor'
        ? 'concourse'
        : 'surface';
    if (id === this.zone) return;
    this.zone = id;
    this.timer = 2.8 + Math.random() * 4;
    this.stride = 0;
    this.applyProfile();
  }
  private applyProfile() {
    if (!this.context) return;
    const p = voices[this.zone],
      t = this.context.currentTime;
    this.wind!.frequency.setTargetAtTime(p.air, t, 0.8);
    this.hum!.frequency.setTargetAtTime(p.hz, t, 0.6);
    this.harmonic!.frequency.setTargetAtTime(p.hz * 2.014, t, 0.65);
    this.humidity!.gain.setTargetAtTime(p.flow, t, 0.8);
    this.humGain!.gain.setTargetAtTime(p.hum, t, 0.66);
    this.wet!.gain.setTargetAtTime(
      this.zone === 'surface' ? 0.022 : this.zone === 'education' ? 0.077 : 0.14,
      t,
      0.7,
    );
    const pos = anchors[this.zone] || [-70, 4, -73];
    this.moveSource(this.source!, ...(pos as [number, number, number]));
  }
  setMachine(on: boolean) {
    this.machinery = on;
  }
  resetTravel() {
    this.last = null;
    this.stride = 0;
  }
  update(dt: number, p: XYZ, yaw: number, running: boolean, grounded: boolean, zone: string) {
    this.setZone(zone);
    if (!this.enabled || !this.context || this.paused || document.hidden) {
      this.last = null;
      return;
    }
    this.listenerTimer += dt;
    this.profileTimer += dt;
    this.timer -= dt;
    const t = this.context.currentTime;
    if (this.listenerTimer > 0.035) {
      this.listenerTimer = 0;
      const l = this.context.listener;
      if (l.positionX) {
        l.positionX.value = p.x;
        l.positionY.value = p.y + 1.55;
        l.positionZ.value = p.z;
        l.forwardX.value = -Math.sin(yaw);
        l.forwardY.value = 0;
        l.forwardZ.value = -Math.cos(yaw);
        l.upY.value = 1;
      } else {
        l.setPosition(p.x, p.y + 1.55, p.z);
        l.setOrientation(-Math.sin(yaw), 0, -Math.cos(yaw), 0, 1, 0);
      }
    }
    if (this.profileTimer > 0.6) {
      this.profileTimer = 0;
      const v = voices[this.zone],
        sway = 0.91 + Math.sin(t * 0.193) * 0.08 + Math.sin(t * 0.081) * 0.075;
      this.humidity!.gain.setTargetAtTime(v.flow * sway, t, 0.5);
      this.wind!.frequency.setTargetAtTime(
        v.air * (0.79 + 0.22 * Math.sin(t * 0.123) + 0.17 * Math.sin(t * 0.058)),
        t,
        0.6,
      );
      this.humGain!.gain.setTargetAtTime(
        v.hum * (this.zone === 'power' && this.machinery ? 1.8 : 1) * (0.96 + 0.04 * Math.sin(t * 0.61)),
        t,
        0.39,
      );
    }
    if (grounded && this.last) {
      const travelled = Math.hypot(p.x - this.last.x, p.z - this.last.z);
      if (travelled < 2) this.stride += travelled;
      const step = running ? 2.54 : 1.95;
      if (this.stride >= step) {
        this.stride %= step;
        this.cue(
          this.zone === 'surface'
            ? Math.abs(p.x) < 9 && Math.abs(p.z) < 9
              ? 'metal'
              : 'asphalt'
            : this.zone === 'water' || this.zone === 'power' || this.zone === 'command'
              ? 'metal'
              : this.zone === 'medical' || this.zone === 'education'
                ? 'tile'
                : this.zone === 'cafeteria'
                  ? 'wood'
                  : 'concrete',
          p.x,
          p.y + 0.09,
          p.z,
        );
        this.statistics.steps++;
      }
    }
    if (!this.last) this.last = { ...p };
    else Object.assign(this.last, p);
    if (this.timer <= 0) {
      const v = voices[this.zone];
      this.timer = v.spacing * (0.7 + Math.random() * 0.9);
      const a = anchors[this.zone];
      if (this.zone === 'surface') {
        const ang = Math.random() * Math.PI * 2,
          dist = 9 + Math.random() * 28;
        this.cue(
          (['creak', 'impact', 'rattle'] as const)[Math.floor(Math.random() * 3)],
          p.x + Math.cos(ang) * dist,
          p.y + 2,
          p.z + Math.sin(ang) * dist,
        );
      } else if (this.zone === 'medical' || this.zone === 'command') this.cue('beep', a[0], a[1], a[2]);
      else if (this.zone === 'water') this.cue('water', a[0], a[1], a[2]);
      else if (this.zone !== 'education') this.cue('rattle', a[0], a[1], a[2]);
    }
  }
  cue(type: SoundCue, x?: number, y?: number, z?: number) {
    const c = this.context;
    if (!this.enabled || !c || c.state !== 'running' || this.count >= 16 || document.hidden) return;
    const pos =
      x !== undefined && y !== undefined && z !== undefined
        ? this.panner(x, y, z, type === 'metal' || type === 'tile' ? 1.4 : 3.8)
        : null;
    const out = pos || this.bus!,
      t = c.currentTime,
      variation = 0.91 + Math.random() * 0.18;
    let end = 0.1;
    const tone = (
      freq: number,
      last: number,
      dur: number,
      amount: number,
      kind: OscillatorType = 'sine',
      delay = 0,
    ) => {
      const s = c.createOscillator(),
        g = c.createGain();
      s.type = kind;
      const at = t + delay;
      s.frequency.setValueAtTime(freq * variation, at);
      s.frequency.exponentialRampToValueAtTime(Math.max(6, last * variation), at + dur);
      g.gain.setValueAtTime(0.00001, at);
      g.gain.exponentialRampToValueAtTime(amount, at + Math.min(0.02, dur * 0.12));
      g.gain.exponentialRampToValueAtTime(0.00001, at + dur);
      s.connect(g);
      g.connect(out);
      s.start(at);
      s.stop(at + dur + 0.015);
      s.onended = () => {
        s.disconnect();
        g.disconnect();
      };
      end = Math.max(end, dur + delay);
    };
    const rush = (freq: number, dur: number, level: number, q = 0.7, delay = 0) => {
      const s = c.createBufferSource(),
        f = c.createBiquadFilter(),
        g = c.createGain();
      s.buffer = this.noise;
      s.loop = true;
      s.playbackRate.value = variation;
      f.type = 'bandpass';
      f.frequency.value = freq * variation;
      f.Q.value = q;
      const at = t + delay;
      g.gain.setValueAtTime(0.00001, at);
      g.gain.exponentialRampToValueAtTime(level, at + Math.min(0.06, dur * 0.2));
      g.gain.exponentialRampToValueAtTime(0.00001, at + dur);
      s.connect(f);
      f.connect(g);
      g.connect(out);
      s.start(at, Math.random() * 4);
      s.stop(at + dur + 0.01);
      s.onended = () => {
        s.disconnect();
        f.disconnect();
        g.disconnect();
      };
      end = Math.max(end, dur + delay);
    };
    if (['asphalt', 'concrete', 'metal', 'tile', 'wood'].includes(type)) {
      tone(type === 'metal' ? 147 : 101, 48, 0.098, 0.12);
      rush(type === 'asphalt' ? 1700 : type === 'tile' ? 2980 : 1050, 0.16, type === 'wood' ? 0.22 : 0.34);
      if (type === 'metal' || type === 'tile')
        tone(type === 'metal' ? 639 : 897, type === 'metal' ? 587 : 857, 0.11, 0.037, 'triangle');
      if (type === 'wood') tone(246, 176, 0.12, 0.043, 'triangle');
    } else if (type.startsWith('door') || type.startsWith('hatch')) {
      const heavy = type.startsWith('hatch'),
        open = type.endsWith('open'),
        dur = heavy ? 2.15 : 0.78;
      tone(heavy ? 43 : 68, open ? 96 : 46, dur, 0.09, 'triangle');
      rush(heavy ? 610 : 1060, dur, 0.23);
      tone(143, 51, 0.13, 0.17, 'sine', dur - 0.09);
      rush(2400, 0.071, 0.26, 1.1, dur - 0.04);
    } else if (type === 'lift') {
      tone(59, 122, 3.3, 0.12);
      rush(540, 3.3, 0.23);
    } else if (type === 'arrival') {
      tone(660, 660, 0.33, 0.067);
      tone(880, 880, 0.41, 0.048, 'sine', 0.15);
    } else if (type === 'terminal' || type === 'beep') {
      tone(
        type === 'terminal' ? 740 : voices[this.zone].sparkle,
        type === 'terminal' ? 900 : voices[this.zone].sparkle,
        0.095,
        type === 'terminal' ? 0.075 : 0.08,
      );
      if (type === 'terminal') tone(1080, 1080, 0.11, 0.044, 'sine', 0.085);
    } else if (type === 'switch') {
      rush(2450, 0.044, 0.43);
      tone(260, 119, 0.055, 0.05, 'triangle');
    } else if (type === 'machine-on' || type === 'machine-off') {
      tone(type === 'machine-on' ? 34 : 107, type === 'machine-on' ? 107 : 34, 1.78, 0.17, 'triangle');
      rush(670, 1.5, 0.2);
    } else if (type === 'spark') {
      rush(4300, 0.054, 0.53, 1.7);
      rush(3700, 0.041, 0.29, 1.2, 0.09);
    } else if (type === 'water') {
      tone(980, 260, 0.12, 0.11);
      rush(1550, 0.33, 0.23);
    } else if (type === 'creak') {
      tone(240, 180, 0.69, 0.09, 'triangle');
      rush(930, 0.5, 0.14, 3.3);
    } else if (type === 'rattle') {
      for (let i = 0; i < 3; i++) tone(493 - i * 41, 399 - i * 27, 0.075, 0.067, 'triangle', i * 0.068);
    } else {
      tone(89, 32, 0.45, 0.26);
      rush(496, 0.31, 0.27);
    }
    this.count++;
    this.statistics.cues++;
    this.statistics.lastCue = type;
    window.setTimeout(
      () => {
        pos?.disconnect();
        this.count = Math.max(0, this.count - 1);
      },
      (end + 0.15) * 1000,
    );
  }
}
export const worldAudio = new EnvironmentalAudio();
export const setAmbience = (on: boolean) => worldAudio.enable(on);
