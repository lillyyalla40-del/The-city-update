import type { FastTravelPoint, QualityPreset } from './game/types';

export interface Sector {
  id: string;
  number: string;
  name: string;
  category: string;
  color: string;
  description: string;
  rooms: string[];
  bounds: [number, number, number, number];
  spawn: [number, number, number];
}

export const SECTORS: Sector[] = [
  {
    id: 'concourse',
    number: '01',
    name: 'Central concourse',
    category: 'Arrival & circulation',
    color: '#ed9658',
    description:
      'The meeting point of every route. A two-level arrival hall connects the surface hatch to the entire settlement.',
    rooms: ['Arrival hall', 'Security reception', 'Observation gallery', 'Passenger lift'],
    bounds: [-24, 24, -24, 66],
    spawn: [-6, 33, -2.94],
  },
  {
    id: 'medical',
    number: '02',
    name: 'Medical wing',
    category: 'Health & recovery',
    color: '#8bc7bc',
    description: 'A complete clinical wing, from emergency care and surgical suites to quiet recovery wards.',
    rooms: [
      'Emergency treatment',
      'Patient wards',
      'Operating theatre',
      'Examination suite',
      'Laboratory',
      'Pharmacy',
      'Consultation',
      'Clean utility',
    ],
    bounds: [-104, -24, -24, 66],
    spawn: [-65.8, 58.4, 0.03],
  },
  {
    id: 'education',
    number: '03',
    name: 'Meridian Academy',
    category: 'Learning & research',
    color: '#c9a67b',
    description:
      'A quieter world below the city. Follow the academy corridor from its welcoming reception to classrooms, laboratories, and the library.',
    rooms: [
      'Reception',
      'Classrooms 101-103',
      'Science studio',
      'Computer lab',
      'Library',
      'Assembly hall',
      "Principal's office",
      'Staff room',
      'Administration',
      'School stores',
      'Washrooms',
    ],
    bounds: [-104, 24, -104, -24],
    spawn: [15.1, -29.8, 0.13],
  },
  {
    id: 'habitat',
    number: '04',
    name: 'RV settlement',
    category: 'Community & habitation',
    color: '#d7b568',
    description:
      'Four individual motorhomes share a sheltered residential hall with dedicated service bays and a communal garden.',
    rooms: ['Four residential bays', 'Utility hookups', 'Community lounge', 'Notice station'],
    bounds: [24, 104, -24, 66],
    spawn: [58, 39, 1.08],
  },
  {
    id: 'command',
    number: '05',
    name: 'Command centre',
    category: 'Operations & communications',
    color: '#83aecb',
    description:
      'The operational heart of the facility. Integrated control stations oversee the settlement from a tiered operations floor.',
    rooms: ['Operations floor', 'Communications', 'Planning room', 'Server aisle', 'Equipment store'],
    bounds: [-24, 24, 66, 104],
    spawn: [-2, 71, -3.06],
  },
  {
    id: 'cafeteria',
    number: '06',
    name: 'Cafeteria',
    category: 'Dining & provisions',
    color: '#d4936c',
    description:
      'A warm communal dining hall with a full stainless-steel production kitchen and temperature-controlled food storage.',
    rooms: ['Dining hall', 'Serving counter', 'Industrial kitchen', 'Cold store', 'Tray return'],
    bounds: [-104, -24, 66, 104],
    spawn: [-49, 71, 2.86],
  },
  {
    id: 'power',
    number: '07',
    name: 'Power generation',
    category: 'Energy infrastructure',
    color: '#d1b266',
    description:
      'Parallel generator sets, backup systems, and a supervised distribution gallery supply every sector.',
    rooms: ['Generator hall', 'Backup power', 'Distribution gallery', 'Service walkway'],
    bounds: [64, 104, -104, -60],
    spawn: [70, -66, -0.55],
  },
  {
    id: 'water',
    number: '08',
    name: 'Water treatment',
    category: 'Water infrastructure',
    color: '#77b5be',
    description:
      'Stainless processing tanks, organized pipework, and inspection platforms form the water recovery plant.',
    rooms: ['Filtration line', 'Reservoirs', 'Pump station', 'Inspection gallery'],
    bounds: [24, 64, -104, -60],
    spawn: [31, -66, -0.5],
  },
  {
    id: 'workshop',
    number: '09',
    name: 'Maintenance',
    category: 'Engineering & repair',
    color: '#d49163',
    description:
      'Purpose-built repair benches, fitted tool walls, and organized parts storage support the facility workshop.',
    rooms: ['Repair benches', 'Tool library', 'Service bay', 'Parts counter'],
    bounds: [24, 104, -60, -24],
    spawn: [60, -30, 0.36],
  },
  {
    id: 'storage',
    number: '10',
    name: 'Supply storage',
    category: 'Inventory & logistics',
    color: '#a8b397',
    description:
      'A carefully ordered logistics depot with specialist supply racks, refrigerated storage, and an inventory control station.',
    rooms: ['Supply aisles', 'Medical reserves', 'Cold storage', 'Loading bay', 'Inventory desk'],
    bounds: [24, 104, 66, 104],
    spawn: [32, 72, -2.75],
  },
];

export const sectorPoint = (s: Sector): FastTravelPoint => ({
  id: s.id,
  label: s.name,
  group: 'Underground Bunker',
  x: s.spawn[0],
  y: -12,
  z: s.spawn[1],
  yaw: s.spawn[2],
});
export const SURFACE_POINT: FastTravelPoint = {
  id: 'plaza',
  label: 'Surface hatch',
  group: 'Surface City',
  x: 0,
  y: 0.15,
  z: -24,
  yaw: Math.PI,
};
export const sectorImage = (s: Sector) =>
  `/media/${s.id === 'concourse' ? 'concourse.jpg' : s.id === 'education' ? 'meridian-academy.jpg' : `${s.id}.webp`}`;

export interface Preferences {
  quality: QualityPreset;
  sensitivity: number;
  sound: boolean;
  firstPerson: boolean;
  effects: boolean;
  volume: number;
}
export function readPreferences(): Preferences {
  const defaults: Preferences = {
    quality: navigator.maxTouchPoints > 0 ? 'mobile' : 'balanced',
    sensitivity: 1,
    sound: false,
    firstPerson: true,
    effects: !matchMedia('(prefers-reduced-motion: reduce)').matches,
    volume: 0.65,
  };
  try {
    const v = JSON.parse(localStorage.getItem('lf3-preferences') || '{}');
    return {
      quality: ['mobile', 'balanced', 'high'].includes(v.quality) ? v.quality : defaults.quality,
      sensitivity: Math.min(2, Math.max(0.4, Number(v.sensitivity) || 1)),
      sound: v.sound === true,
      firstPerson: v.firstPerson !== false,
      effects: typeof v.effects === 'boolean' ? v.effects : defaults.effects,
      volume: Number.isFinite(v.volume) ? Math.max(0, Math.min(1, v.volume)) : defaults.volume,
    };
  } catch {
    return defaults;
  }
}
