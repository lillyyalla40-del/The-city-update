import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { chromium } from 'playwright';

const browser = await chromium.launch({
  args: ['--no-sandbox', '--enable-unsafe-swiftshader', '--use-angle=swiftshader'],
});
try {
  const page = await browser.newPage({
    viewport: { width: 740, height: 390 },
    hasTouch: true,
    isMobile: true,
    deviceScaleFactor: 1,
  });
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(process.env.APP_URL || 'http://localhost:5173', { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: 'Preview Central Concourse', exact: true }).tap();
  await page.getByRole('button', { name: 'Enter bunker', exact: true }).tap();
  await page.waitForSelector('.game-hud[data-position]', { timeout: 90000 });
  const cdp = await page.context().newCDPSession(page);
  const rect = await page.locator('.joystick').boundingBox();
  const hud = page.locator('.game-hud');
  const point = async () => (await hud.getAttribute('data-position')).split(',').map(Number);
  const state = async () => ({ p: await point(), yaw: Number(await hud.getAttribute('data-heading')) });
  const start = await state();
  const a = { id: 1, x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 - 27 },
    b = { id: 2, x: 450, y: 165 };
  const touch = (type, points) =>
    cdp.send('Input.dispatchTouchEvent', {
      type,
      touchPoints: points.map((t) => ({ ...t, radiusX: 5, radiusY: 5, force: 0.6 })),
    });
  await touch('touchStart', [a]);
  await page.waitForTimeout(600);
  await touch('touchStart', [a, b]);
  for (let i = 1; i <= 5; i++) {
    b.x = 450 + i * 25;
    b.y = 165 + i;
    await touch('touchMove', [a, b]);
    await page.waitForTimeout(80);
  }
  await page.waitForTimeout(450);
  const moving = await state();
  await touch('touchEnd', []);
  await page.waitForTimeout(750);
  const released = await state();
  await page.waitForTimeout(500);
  const stopped = await state();
  assert.ok(
    Math.hypot(moving.p[0] - start.p[0], moving.p[2] - start.p[2]) > 0.08,
    'Joystick moved the player',
  );
  assert.ok(Math.abs(moving.yaw - start.yaw) > 10, 'Second thumb turned the camera while moving');
  assert.ok(
    Math.hypot(stopped.p[0] - released.p[0], stopped.p[2] - released.p[2]) < 0.01,
    'Releasing touch stops movement',
  );
  assert.ok(stopped.p[1] >= -12.01, 'Floor remains beneath the player');
  await page.getByRole('button', { name: 'Toggle sprint', exact: true }).tap();
  assert.equal(
    await page.getByRole('button', { name: 'Toggle sprint', exact: true }).getAttribute('aria-pressed'),
    'true',
  );
  await page.getByRole('button', { name: 'Toggle headlamp', exact: true }).tap();
  await page.waitForFunction(
    () => document.querySelector('[aria-label="Toggle headlamp"]').getAttribute('aria-pressed') === 'true',
  );
  await page.getByRole('button', { name: 'Pause and settings', exact: true }).tap();
  await page.getByRole('combobox', { name: 'Camera perspective' }).selectOption('third');
  await page.getByRole('button', { name: 'Close dialog' }).tap();
  await page.getByRole('button', { name: 'World map', exact: true }).tap();
  await page.getByRole('button', { name: 'Select RV settlement', exact: true }).tap();
  await page.getByRole('button', { name: 'Explore sector', exact: true }).tap();
  await page.waitForFunction(
    () => document.querySelector('.hud-location strong')?.textContent === 'RV settlement',
  );
  await page.waitForTimeout(600);
  await page.screenshot({ path: 'artifacts/rv-mobile.png', timeout: 90000 });
  assert.deepEqual(errors, []);
  const report = {
    start,
    moving,
    released,
    stopped,
    controls: 'passed',
    tested: 'Chromium touch emulation (software WebGL)',
  };
  await writeFile('artifacts/touch-report.json', JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
} finally {
  await browser.close();
}
