import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { chromium } from 'playwright';

const protectedCount = execFileSync('sha256sum', ['-c', 'tests/aftermath-preserved.sha256'], {
  encoding: 'utf8',
})
  .trim()
  .split('\n').length;
const browser = await chromium.launch({
  args: [
    '--no-sandbox',
    '--enable-unsafe-swiftshader',
    '--use-angle=swiftshader',
    '--autoplay-policy=no-user-gesture-required',
  ],
});
const page = await browser.newPage({
  viewport: { width: 740, height: 390 },
  hasTouch: true,
  isMobile: true,
  deviceScaleFactor: 1,
});
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
page.on('console', (m) => {
  if (m.type() === 'error') errors.push(m.text());
});
try {
  await page.goto(process.env.APP_URL || 'http://localhost:5173', { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: 'Preview Northgate Commons', exact: true }).tap();
  await page.getByRole('button', { name: 'View world map' }).tap();
  assert.equal(await page.getByLabel('Choose city arrival').inputValue(), '2');
  await page.getByRole('button', { name: 'Close dialog' }).tap();
  await page.getByRole('button', { name: 'Last Four explorer home' }).tap();
  await page.getByRole('button', { name: 'Enable world ambience' }).tap();
  await page.getByRole('button', { name: 'Explorer settings' }).tap();
  await page.getByLabel('Camera perspective').selectOption('third');
  await page.getByRole('button', { name: 'Performance', exact: true }).tap();
  await page.getByRole('button', { name: 'Close dialog' }).tap();
  await page.getByRole('button', { name: 'Enter city', exact: true }).tap();
  await page.waitForSelector('.game-hud[data-position]', { timeout: 90000 });
  await page.evaluate(() => {
    const o = document.querySelector('.game-hud');
    let f = o[Object.keys(o).find((k) => k.startsWith('__reactFiber'))];
    while (f && !f.memoizedProps?.engine) f = f.return;
    window.afTest = f.memoizedProps.engine;
  });
  const joy = await page.locator('.joystick').boundingBox(),
    cdp = await page.context().newCDPSession(page);
  const state = () =>
    page.evaluate(() => ({
      x: afTest.player.position.x,
      y: afTest.player.position.y,
      z: afTest.player.position.z,
      yaw: afTest.player.yaw,
    }));
  const start = await state();
  const left = { id: 1, x: joy.x + joy.width * 0.5, y: joy.y + joy.height * 0.23 },
    right = { id: 2, x: 410, y: 165 };
  const touch = (type, points) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: points });
  await touch('touchStart', [left]);
  await page.waitForTimeout(450);
  await touch('touchStart', [left, right]);
  for (let i = 1; i <= 4; i++) {
    right.x = 410 + i * 23;
    await touch('touchMove', [left, right]);
    await page.waitForTimeout(100);
  }
  await touch('touchEnd', []);
  await page.waitForTimeout(500);
  const moved = await state();
  await page.waitForTimeout(400);
  const released = await state();
  assert.ok(Math.hypot(moved.x - start.x, moved.z - start.z) > 0.15);
  assert.ok(Math.abs(moved.yaw - start.yaw) > 0.1);
  assert.ok(Math.hypot(released.x - moved.x, released.z - moved.z) < 0.02);
  const results = await page.evaluate(async () => {
    const e = window.afTest,
      a = e.aftermath;
    e.setPaused(true);
    let importUrl =
      performance.getEntriesByType('resource').find((v) => new URL(v.name).pathname === '/src/ambience.ts')
        ?.name || '/src/ambience.ts';
    const { worldAudio } = await import(importUrl);
    worldAudio.setPaused(false);
    const out = {
      ...a.stats,
      sourceAboveGround: a.kit.solids.every((b) => b.minY >= 0),
      protectedHatchClear: a.kit.solids.every(
        (b) => !(b.minX < 25 && b.maxX > -25 && b.minZ < 25 && b.maxZ > -25),
      ),
      vehicleTypes: [...new Set(a.sites.map((v) => v.kind))],
      thirdPerson: !e.player.firstPerson,
      profiles: [...new Set(a.stats.grades)],
      streetRoutes: [],
      highwayClear: true,
      hatchCycle: [],
      audioEvents: 0,
      qualityDraws: [],
    };
    delete out.grades;
    // Radius-aware flood fill across the actual street collision grid, including wrecks.
    const size = 345,
      half = 172,
      key = (x, z) => (z + half) * size + x + half;
    const allowed = new Uint8Array(size * size),
      seen = new Uint8Array(size * size);
    for (let z = -half; z <= half; z++)
      for (let x = -half; x <= half; x++) {
        const floor = e.collision.getFloorHeight(x, z, 0.2, 0.5);
        const p = e.collision.resolveHorizontal(x, floor, z, 0.42, 1.75);
        if (Math.hypot(p.x - x, p.z - z) < 0.017) allowed[key(x, z)] = 1;
      }
    const queue = [[-68, 12]];
    seen[key(-68, 12)] = 1;
    for (let i = 0; i < queue.length; i++) {
      const [x, z] = queue[i];
      for (const [dx, dz] of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        const xx = x + dx,
          zz = z + dz;
        if (Math.abs(xx) > half || Math.abs(zz) > half) continue;
        const idx = key(xx, zz);
        if (allowed[idx] && !seen[idx]) {
          seen[idx] = 1;
          queue.push([xx, zz]);
        }
      }
    }
    for (const [name, x, z] of [
      ['Meridian Avenue', -68, 12],
      ['Financial District', -68, -67],
      ['Northgate Commons', 98, -87],
      ['Metro Galleria', -84, 72],
      ['Grand Meridian Hotel', 68, 74],
      ['Central hatch', 0, -24],
      ['Western expressway ramp', -172, -128],
      ['Eastern expressway ramp', 172, -128],
    ])
      out.streetRoutes.push({ name, reachable: !!seen[key(x, z)] });
    for (let x = -135; x <= 135; x += 0.75) {
      const p = e.collision.resolveHorizontal(x, 6.47, -124, 0.42, 1.75);
      if (Math.hypot(p.x - x, p.z + 124) > 0.02) {
        out.highwayClear = false;
        break;
      }
    }
    for (const quality of ['mobile', 'balanced', 'high']) {
      a.kit.update(0.4, e.player.position, e.player.yaw, quality, true);
      out.qualityDraws.push({ quality, chunks: a.kit.chunks.filter((c) => c.mesh.visible).length });
    }
    a.sound.update(0.5, { x: -77, y: 0, z: -76 });
    out.audioEvents = a.sound.statistics.events;
    out.audioAtSource = a.sound.active;
    out.voiceLimit = a.sound.statistics.voices <= 3;
    e.hatch.setOpenImmediate(false);
    e.hatch.toggle();
    for (let i = 0; i < 180; i++) e.hatch.update(1 / 60, i / 60);
    out.hatchCycle.push(e.hatch.getState());
    e.hatch.toggle();
    for (let i = 0; i < 180; i++) e.hatch.update(1 / 60, 3 + i / 60);
    out.hatchCycle.push(e.hatch.getState());
    e.fastTravel({
      id: 'concourse',
      label: 'Central concourse',
      group: 'Underground Bunker',
      x: -6,
      y: -12,
      z: 33,
      yaw: -2.94,
    });
    e.setPaused(false);
    return out;
  });
  await page.waitForFunction(() => window.afTest.aftermath.group.visible === false, { timeout: 20000 });
  results.undergroundIsolated = await page.evaluate(
    () =>
      !afTest.aftermath.group.visible &&
      !afTest.aftermath.sound.active &&
      afTest.player.position.y === -12 &&
      afTest.bunkerGroup.visible,
  );
  assert.ok(
    results.sourceAboveGround &&
      results.protectedHatchClear &&
      results.thirdPerson &&
      results.undergroundIsolated,
  );
  assert.equal(results.vehicleTypes.length, 7);
  assert.equal(results.existingFleet, 18);
  assert.ok(results.addedVehicles === 10 && results.bays > 0 && results.shops > 0);
  assert.ok(results.streetRoutes.every((r) => r.reachable));
  assert.ok(results.highwayClear);
  assert.deepEqual(results.hatchCycle, ['open', 'closed']);
  assert.ok(results.audioAtSource && results.audioEvents > 0 && results.voiceLimit);
  assert.ok(results.qualityDraws[0].chunks <= results.qualityDraws[2].chunks);
  assert.deepEqual(errors, []);
  const report = {
    ...results,
    unchangedFiles: protectedCount,
    touchMoveAndLook: 'passed',
    releaseStopsMovement: true,
    device: 'Chromium mobile emulation / software WebGL',
  };
  await writeFile('artifacts/aftermath-verification.json', JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
  await page.getByRole('button', { name: 'Explorer', exact: true }).tap();
  assert.equal(await page.locator('canvas').count(), 0);
  console.log(
    'PASS: surface navigation, third-person dual-touch, surface audio isolation, and protected bunker.',
  );
} finally {
  await browser.close();
}
