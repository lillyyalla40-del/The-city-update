import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { chromium } from 'playwright';

const browser = await chromium.launch({
  args: [
    '--no-sandbox',
    '--enable-unsafe-swiftshader',
    '--use-angle=swiftshader',
    '--autoplay-policy=no-user-gesture-required',
  ],
});
const page = await browser.newPage({ viewport: { width: 900, height: 570 } });
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
page.on('console', (m) => {
  if (m.type() === 'error') errors.push(m.text());
});
try {
  await page.goto(process.env.APP_URL || 'http://localhost:5173', { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: 'Enable world ambience' }).click();
  await page.getByRole('button', { name: 'Explorer settings' }).click();
  await page.getByRole('button', { name: 'Performance', exact: true }).click();
  await page.getByRole('slider', { name: 'Audio level' }).fill('46');
  await page.getByRole('button', { name: 'Close dialog' }).click();
  await page.getByRole('button', { name: 'Enter city', exact: true }).click();
  await page.waitForSelector('.game-hud[data-position]', { timeout: 90000 });
  await page.evaluate(() => {
    const o = document.querySelector('.game-hud');
    let f = o[Object.keys(o).find((k) => k.startsWith('__reactFiber'))];
    while (f && !f.memoizedProps?.engine) f = f.return;
    window.polishGame = f.memoizedProps.engine;
  });
  const before = await page.getAttribute('.game-hud', 'data-position');
  await page.keyboard.down('w');
  await page.waitForTimeout(2100);
  await page.keyboard.up('w');
  await page.waitForTimeout(300);
  assert.notEqual(await page.getAttribute('.game-hud', 'data-position'), before);
  const report = await page.evaluate(async () => {
    const e = window.polishGame;
    const audioModule=performance.getEntriesByType('resource').find(v=>new URL(v.name).pathname==='/src/ambience.ts');
    const { worldAudio: a } = await import(audioModule?.name || '/src/ambience.ts');
    const { SECTORS, sectorPoint } = await import('/src/facility.ts');
    e.setPaused(true);
    a.setPaused(false);
    const stats = {
      audioContext: a.context.state,
      volume: a.volume,
      steps: a.statistics.steps,
      towers: e.cityDetail.towers.length,
      originalFacadeFit: [],
      qualityBudgets: [],
      profiles: [],
      interactions: [],
      schoolThresholds: [],
      visuals: {},
    };
    for (const t of e.cityDetail.towers) {
      const hit = e.collision.solids.find(
        (s) =>
          Math.abs((s.maxX + s.minX) / 2 - t.x) < 0.03 &&
          Math.abs((s.maxZ + s.minZ) / 2 - t.z) < 0.03 &&
          Math.abs(s.maxX - s.minX - t.w) < 0.03 &&
          s.maxY > t.h - 0.01,
      );
      stats.originalFacadeFit.push(!!hit);
    }
    const p = e.player.position.clone();
    p.set(-76, 0, -76);
    for (const quality of ['mobile', 'balanced', 'high']) {
      e.atmosphere.quality = quality;
      e.atmosphere.update(0.03, p, e.camera, false, 'financial_nw');
      stats.qualityBudgets.push(e.atmosphere.particle.geometry.drawRange.count);
    }
    e.atmosphere.nextSpark = 0;
    e.atmosphere.update(0.025, p, e.camera, false, 'financial_nw');
    stats.visuals.localizedSparks = e.atmosphere.sparks.visible;
    e.atmosphere.update(0.1, { x: 39, y: -12, z: -98 }, e.camera, true, 'water');
    stats.visuals.waterSteam = e.atmosphere.sheets.filter((s) => s.mesh.visible && s.type === 'steam').length;
    e.atmosphere.update(0.1, { x: 16, y: -12, z: -35 }, e.camera, true, 'education');
    stats.visuals.cleanSchool =
      !e.atmosphere.sheets.some((s) => s.mesh.visible) && !e.atmosphere.sparks.visible;
    e.setEffects(false);
    stats.visuals.effectToggle = !e.atmosphere.group.visible;
    e.setEffects(true);
    for (const s of SECTORS) {
      a.setZone(s.id);
      stats.profiles.push(a.zone);
    }
    const { SCHOOL_ROOMS } = await import('/src/schoolPlan.ts');
    for (const r of SCHOOL_ROOMS) {
      let x = r.x1 + Math.min(3.2, (r.x2 - r.x1) * 0.21),
        z = (r.entry === 'south' ? r.z2 : r.z1) + (r.entry === 'south' ? 1.7 : -1.7);
      const t = e.collision.resolveHorizontal(x, -12, z, 0.42, 1.75);
      stats.schoolThresholds.push({ room: r.code, clear: Math.hypot(x - t.x, z - t.z) < 0.012 });
    }
    e.player.teleport(71, -12, -84.3, 0, e.camera);
    a.setZone('power');
    e.interact();
    stats.interactions.push(a.statistics.lastCue);
    const machine = e.machineTest;
    e.interact();
    stats.interactions.push(a.statistics.lastCue);
    stats.machineToggled = machine && !e.machineTest;
    e.player.teleport(-4.2, -12, 56.51, 3.14, e.camera);
    e.interact();
    stats.interactions.push(a.statistics.lastCue);
    await new Promise((r) => setTimeout(r, 120));
    e.toggleFlashlight();
    stats.interactions.push(a.statistics.lastCue);
    const analyser = a.context.createAnalyser();
    analyser.fftSize = 1024;
    a.output.connect(analyser);
    await new Promise((r) => setTimeout(r, 150));
    const buffer = new Float32Array(1024);
    analyser.getFloatTimeDomainData(buffer);
    stats.audioRms = Math.sqrt(buffer.reduce((n, v) => n + v * v, 0) / buffer.length);
    a.output.disconnect(analyser);
    analyser.disconnect();
    e.fastTravel(sectorPoint(SECTORS[2]));
    e.setPaused(false);
    return stats;
  });
  assert.equal(report.audioContext, 'running');
  assert.equal(report.volume, 0.46);
  assert.ok(report.audioRms > 0.000001);
  assert.ok(report.steps > 0);
  assert.equal(report.towers, 36);
  assert.ok(report.originalFacadeFit.every(Boolean));
  assert.deepEqual(report.qualityBudgets, [20, 48, 78]);
  assert.ok(
    report.visuals.localizedSparks &&
      report.visuals.waterSteam === 5 &&
      report.visuals.cleanSchool &&
      report.visuals.effectToggle,
  );
  assert.ok(report.machineToggled);
  assert.deepEqual(report.interactions, ['machine-on', 'machine-off', 'lift', 'switch']);
  assert.ok(report.schoolThresholds.every((v) => v.clear));
  await page.getByRole('button', { name: 'World map', exact: true }).click();
  await page.getByRole('tab', { name: 'Academy', exact: true }).click();
  await page.getByLabel('Choose school room').selectOption('8');
  await page.getByRole('button', { name: 'Enter academy', exact: true }).click();
  await page.waitForFunction(
    () => document.querySelector('.hud-location strong')?.textContent === 'Meridian Academy',
  );
  await page.evaluate(() => {
    const e = window.polishGame;
    e.player.teleport(12.1, -12, -41.3, Math.PI / 2, e.camera);
  });
  await page.getByRole('button', { name: /Open academy directory/ }).click();
  await page.getByRole('dialog', { name: 'World map' }).waitFor();
  assert.equal(
    await page.getByRole('tab', { name: 'Academy', exact: true }).getAttribute('aria-selected'),
    'true',
  );
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'Explorer', exact: true }).click();
  await page.setViewportSize({ width: 320, height: 700 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth), 0);
  assert.deepEqual(errors, []);
  await writeFile('artifacts/environment-polish-report.json', JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
  console.log(
    'PASS: city fit, spatial audio, footsteps, effects budgets, school deployment, and terminal interaction.',
  );
} finally {
  await browser.close();
}
