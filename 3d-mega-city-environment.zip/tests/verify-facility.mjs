import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { chromium } from 'playwright';

const root = process.env.APP_URL || 'http://localhost:5173';
await mkdir('artifacts', { recursive: true });
const browser = await chromium.launch({
  args: ['--no-sandbox', '--enable-unsafe-swiftshader', '--use-angle=swiftshader'],
});
const page = await browser.newPage({ viewport: { width: 920, height: 580 } });
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
page.on('console', (m) => {
  if (m.type() === 'error') errors.push(m.text());
});
try {
  await page.goto(root, { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: 'Preview Medical wing', exact: true }).click();
  assert.match(await page.locator('h1').innerText(), /MEDICAL/i);
  await page.getByRole('button', { name: 'Next locations', exact: true }).click();
  await page.waitForTimeout(650);
  assert.ok((await page.locator('.sector-rail').evaluate((e) => e.scrollLeft)) > 0);
  await page.getByRole('button', { name: 'Last Four explorer home' }).click();
  await page.getByRole('button', { name: 'Field manual', exact: true }).click();
  await page.getByRole('button', { name: 'Touch controls', exact: true }).click();
  assert.match(await page.locator('.key-list').innerText(), /Use both thumbs/);
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'Explorer settings' }).click();
  await page.getByRole('button', { name: 'Performance', exact: true }).click();
  await page.getByRole('slider', { name: 'Look sensitivity' }).fill('1.2');
  await page.keyboard.press('Escape');
  await page.reload({ waitUntil: 'networkidle' });
  assert.equal(
    await page.evaluate(() => JSON.parse(localStorage.getItem('lf3-preferences')).sensitivity),
    1.2,
  );
  await page.getByRole('button', { name: 'Preview Central Concourse', exact: true }).click();
  await page.getByRole('button', { name: 'Enter bunker', exact: true }).click();
  await page.waitForSelector('.game-hud', { timeout: 90000 });
  await page.waitForTimeout(2000);
  await page.evaluate(() => {
    const host = document.querySelector('.game-hud');
    let fiber = host[Object.keys(host).find((k) => k.startsWith('__reactFiber'))];
    while (fiber && !fiber.memoizedProps?.engine) fiber = fiber.return;
    window.testEngine = fiber.memoizedProps.engine;
  });
  await page.screenshot({ path: 'artifacts/concourse-upgraded.png', timeout: 90000 });
  const report = await page.evaluate(async () => {
    const e = window.testEngine;
    e.setPaused(true);
    const { SECTORS, sectorPoint } = await import('/src/facility.ts');
    const c = e.collision,
      p = e.player,
      cam = e.camera;
    const out = {
      spawnChecks: [],
      reachability: [],
      routes: {},
      render: { ...e.renderer.info.render },
      rooms: [],
      school: [],
      gates: [],
    };
    const zero = { moveX: 0, moveY: 0, sprint: false, jumpRequested: false };
    for (const s of SECTORS) {
      e.fastTravel(sectorPoint(s));
      const { x, y, z } = p.position;
      const r = c.resolveHorizontal(x, y, z, 0.42, 1.75);
      out.spawnChecks.push({ sector: s.name, level: y, obstacleOverlap: Math.hypot(x - r.x, z - r.z) });
    }
    const gates = c.solids.filter((b) => b.id?.startsWith('sector-gate'));
    for (const g of gates) {
      const x = (g.minX + g.maxX) / 2,
        z = (g.minZ + g.maxZ) / 2;
      for (let i = 0; i < 90; i++) e.interior.update(1 / 60, x, z, -12, true);
      out.gates.push(!g.enabled);
    }
    const prior = gates.map((g) => g.enabled);
    gates.forEach((g) => (g.enabled = false));
    const n = 207,
      blocked = new Uint8Array(n * n),
      seen = new Uint8Array(n * n),
      index = (x, z) => (z + 103) * n + x + 103;
    for (let z = -103; z <= 103; z++)
      for (let x = -103; x <= 103; x++) {
        const a = c.resolveHorizontal(x, -12, z, 0.42, 1.75);
        if (Math.hypot(a.x - x, a.z - z) > 0.015) blocked[index(x, z)] = 1;
      }
    const queue = [[-6, 33]];
    seen[index(-6, 33)] = 1;
    for (let i = 0; i < queue.length; i++) {
      const [x, z] = queue[i];
      for (const [dx, dz] of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        const a = x + dx,
          b = z + dz;
        if (Math.abs(a) > 103 || Math.abs(b) > 103) continue;
        const key = index(a, b);
        if (!seen[key] && !blocked[key]) {
          seen[key] = 1;
          queue.push([a, b]);
        }
      }
    }
    for (const s of SECTORS)
      out.reachability.push({
        sector: s.name,
        connected: !!seen[index(Math.round(s.spawn[0]), Math.round(s.spawn[1]))],
      });
    for (const x of [-89, -64, -38])
      for (const z of [-10, 17, 50])
        out.rooms.push({ room: `Medical ${x}/${z}`, connected: !!seen[index(x, z + 8)] });
    const { SCHOOL_ROOMS } = await import('/src/game/academy.ts');
    for (const r of SCHOOL_ROOMS) {
      const x = Math.round(r.x1 + Math.min(3.2, (r.x2 - r.x1) * 0.21));
      const z = r.entry === 'south' ? r.z2 : r.z1;
      out.school.push({
        room: r.code + ' / ' + r.name,
        inside: !!seen[index(x, z + (r.entry === 'south' ? -2 : 2))],
        outside: !!seen[index(x, z + (r.entry === 'south' ? 2 : -2))],
      });
    }
    gates.forEach((g, i) => (g.enabled = prior[i]));
    e.hatch.setOpenImmediate(true);
    p.teleport(0, 0.15, -16, Math.PI, cam);
    for (let i = 0; i < 490; i++) p.update(1 / 60, { ...zero, moveY: 1 }, cam);
    out.routes.descend = { x: p.position.x, y: p.position.y, z: p.position.z };
    p.teleport(0, -12, 31, 0, cam);
    for (let i = 0; i < 465; i++) p.update(1 / 60, { ...zero, moveY: 1 }, cam);
    out.routes.ascend = { x: p.position.x, y: p.position.y, z: p.position.z };
    p.teleport(10.7, -12, 46, Math.PI, cam);
    for (let i = 0; i < 143; i++) p.update(1 / 60, { ...zero, moveY: 1 }, cam);
    out.routes.stairs = { y: p.position.y, z: p.position.z };
    p.teleport(-4.2, -12, 56.51, Math.PI, cam);
    e.interior.useLift(p.position.x, p.position.y, p.position.z);
    for (let i = 0; i < 240; i++) {
      e.interior.update(1 / 60, p.position.x, p.position.z, p.position.y, true);
      p.update(1 / 60, zero, cam);
    }
    out.routes.liftHeight = p.position.y;
    for (let i = 0; i < 35; i++) p.update(1 / 60, { ...zero, moveY: 1 }, cam);
    out.routes.liftExit = { y: p.position.y, z: p.position.z };
    e.fastTravel(sectorPoint(SECTORS[0]));
    e.setPaused(false);
    return out;
  });
  console.log(JSON.stringify(report, null, 2));
  await writeFile('artifacts/navigation-report.json', JSON.stringify(report, null, 2));
  assert.ok(
    report.spawnChecks.every((s) => s.level >= -12.01 && s.obstacleOverlap < 0.01),
    'All sector spawns must be supported and unobstructed',
  );
  assert.ok(
    report.reachability.every((s) => s.connected),
    'All sectors must connect on foot',
  );
  assert.ok(
    report.rooms.every((s) => s.connected),
    'Medical subrooms must connect to the concourse',
  );
  assert.ok(report.gates.every(Boolean), 'Every automatic sector gate must open');
  assert.ok(
    report.school.length === 12 && report.school.every((r) => r.inside && r.outside),
    'Every school room must be reachable from the original concourse',
  );
  assert.ok(
    report.routes.descend.y < -11.9 && report.routes.descend.z > 28,
    'Physical descent from the existing hatch',
  );
  assert.ok(report.routes.ascend.y >= 0 && report.routes.ascend.z < -9, 'Physical return to the city');
  assert.ok(report.routes.stairs.y > -7.65, 'Stairway to the upper gallery');
  assert.ok(
    report.routes.liftHeight > -7.65 && report.routes.liftExit.z > 58.6,
    'Moving lift and landing are accessible',
  );
  await page.keyboard.press('m');
  await page.getByRole('button', { name: 'Select RV settlement', exact: true }).click();
  await page.getByRole('button', { name: 'Explore sector', exact: true }).click();
  await page.waitForFunction(
    () => document.querySelector('.hud-location strong')?.textContent === 'RV settlement',
  );
  await page.screenshot({ path: 'artifacts/rv-settlement.png', timeout: 90000 });
  await page.getByRole('button', { name: 'Explorer', exact: true }).click();
  assert.equal(await page.locator('canvas').count(), 0);
  assert.deepEqual(errors, []);
  console.log('PASS: explorer, preferences, sector map, physical routes, lift, and renderer cleanup.');
} finally {
  await browser.close();
}
